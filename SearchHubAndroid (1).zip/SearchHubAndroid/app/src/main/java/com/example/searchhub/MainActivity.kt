package com.example.searchhub

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import java.io.IOException
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {

    private val engines = linkedMapOf(
        "百度" to "https://www.baidu.com/s?wd=",
        "Google" to "https://www.google.com/search?q=",
        "Bing" to "https://www.bing.com/search?q=",
        "DuckDuckGo" to "https://duckduckgo.com/?q=",
        "搜狗" to "https://www.sogou.com/web?query=",
        "360" to "https://www.so.com/s?q=",
        "Yandex" to "https://yandex.com/search/?text=",
        "Brave" to "https://search.brave.com/search?q=",
        "Yahoo" to "https://search.yahoo.com/search?p="
    )
    // 嗅探规则：按 URL 扩展名识别媒体（思路同猫抓 / MediaGo）
    private val mediaRe = Regex("\\.(m3u8|mpd|mp4|flv|webm|mkv|mov|mp3|m4a|aac|ogg|f4v)$", RegexOption.IGNORE_CASE)
    private val hlsRe = Regex("\\.m3u8$", RegexOption.IGNORE_CASE)
    private val mpdRe = Regex("\\.mpd$", RegexOption.IGNORE_CASE)

    private val items = mutableListOf<String>()
    private lateinit var web: WebView
    private lateinit var input: EditText
    private lateinit var spinner: Spinner
    private lateinit var sniffBtn: Button
    private lateinit var panel: ListView
    private lateinit var listAdapter: ArrayAdapter<String>
    private lateinit var root: FrameLayout
    // 网页内置播放器（<video>）的全屏画面
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density

        spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, engines.keys.toList())
        }
        input = EditText(this).apply {
            hint = "搜索或输入网址"
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setOnEditorActionListener { _, _, _ -> go(); true }
        }
        val goBtn = Button(this).apply { text = "搜索"; minWidth = 0; setOnClickListener { go() } }
        sniffBtn = Button(this).apply {
            text = "嗅探 0"; minWidth = 0
            setOnClickListener { panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(spinner)
            addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(goBtn)
            addView(sniffBtn)
        }

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            settings.userAgentString = settings.userAgentString.replace("; wv", "")
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    hideCustomView()
                    items.clear(); refresh()
                }
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    val uri = request?.url ?: return null
                    if (mediaRe.containsMatchIn(uri.path ?: "")) {
                        val u = uri.toString()
                        runOnUiThread { if (u !in items) { items.add(u); refresh() } }
                    }
                    return null // 不拦截，正常加载
                }
            }
            // 没有 WebChromeClient 时，网页播放器的全屏按钮点了没反应
            webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                    if (view == null || customView != null) { callback?.onCustomViewHidden(); return }
                    customView = view
                    customCallback = callback
                    view.setBackgroundColor(0xFF000000.toInt())
                    root.addView(view, FrameLayout.LayoutParams(-1, -1))
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    setImmersive(true)
                }
                override fun onHideCustomView() = hideCustomView()
            }
        }

        listAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf<String>())
        panel = ListView(this).apply {
            visibility = View.GONE
            adapter = listAdapter
            setOnItemClickListener { _, _, i, _ -> menu(items[i]) }
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bar)
            addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(panel, LinearLayout.LayoutParams(-1, (220 * dp).toInt()))
        }
        // 外层 FrameLayout：网页全屏播放时，把视频画面盖在整个界面之上
        root = FrameLayout(this).apply { addView(content, FrameLayout.LayoutParams(-1, -1)) }
        setContentView(root)
        refresh()
    }

    /** 退出网页内置播放器的全屏，恢复界面与屏幕方向。 */
    private fun hideCustomView() {
        val v = customView ?: return
        root.removeView(v)
        customView = null
        customCallback?.onCustomViewHidden()
        customCallback = null
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        setImmersive(false)
    }

    private fun go() {
        val v = input.text.toString().trim()
        if (v.isEmpty()) return
        val url = when {
            Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(v) -> v
            Regex("^[\\w-]+(\\.[\\w-]+)+(/\\S*)?$").matches(v) -> "https://$v"
            else -> engines.getValue(spinner.selectedItem as String) + Uri.encode(v)
        }
        web.loadUrl(url)
    }

    private fun ext(u: String) = (Uri.parse(u).path ?: "").substringAfterLast('.', "").uppercase()

    private fun refresh() {
        sniffBtn.text = "嗅探 ${items.size}"
        listAdapter.clear()
        listAdapter.addAll(items.map { "${ext(it)}  $it" })
        if (items.size == 1) panel.visibility = View.VISIBLE
    }

    private fun menu(u: String) {
        AlertDialog.Builder(this)
            .setTitle(ext(u))
            .setItems(arrayOf("全屏播放", "复制链接", "下载", "用外部播放器打开")) { _, which ->
                when (which) {
                    0 -> play(u)
                    1 -> {
                        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                            .setPrimaryClip(ClipData.newPlainText("url", u))
                        toast("已复制")
                    }
                    2 -> download(u)
                    3 -> try {
                        startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(u), "video/*"))
                    } catch (e: ActivityNotFoundException) { toast("没有可用的播放器") }
                }
            }.show()
    }

    /** 全屏播放：交给 PlayerActivity，并带上网页的 UA / Referer / Cookie 以通过防盗链。 */
    private fun play(u: String) {
        // 先暂停网页自己的音视频，避免和全屏播放器同时出声
        web.evaluateJavascript("document.querySelectorAll('video,audio').forEach(function(m){m.pause()})", null)
        startActivity(Intent(this, PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_URL, u)
            putExtra(PlayerActivity.EXTRA_UA, web.settings.userAgentString)
            web.url?.let { putExtra(PlayerActivity.EXTRA_REFERER, it) }
            CookieManager.getInstance().getCookie(u)?.let { putExtra(PlayerActivity.EXTRA_COOKIE, it) }
        })
    }

    private fun download(u: String) {
        val path = Uri.parse(u).path ?: ""
        if (hlsRe.containsMatchIn(path)) { downloadHls(u); return }
        if (mpdRe.containsMatchIn(path)) {
            toast("DASH(mpd) 暂不支持下载，请复制链接用 1DM 等应用下载")
            return
        }
        val req = DownloadManager.Request(Uri.parse(u))
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, Uri.parse(u).lastPathSegment ?: "video.mp4")
            .addRequestHeader("User-Agent", web.settings.userAgentString)
        web.url?.let { req.addRequestHeader("Referer", it) }
        CookieManager.getInstance().getCookie(u)?.let { req.addRequestHeader("Cookie", it) }
        (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
        toast("已开始下载，见通知栏")
    }

    /**
     * m3u8 下载：解析后顺序下载并拼接所有分片（TS 存为 .ts，fMP4 存为 .mp4），
     * 通过 MediaStore 写入「下载」目录（Android 10+ 无需存储权限）。下载期间请保持应用在前台。
     */
    private fun downloadHls(u: String) {
        // WebView / 页面信息必须在主线程读取，后台线程只用这些拷贝
        val ua = web.settings.userAgentString
        val referer = web.url
        val name = safeName(web.title ?: "").ifEmpty { Uri.parse(u).host ?: "video" }
        val cancel = AtomicBoolean(false)

        val msg = TextView(this).apply { text = "正在解析 m3u8…" }
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { isIndeterminate = true }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (20 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, 0)
            addView(msg)
            addView(bar, LinearLayout.LayoutParams(-1, -2))
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle("下载 m3u8")
            .setView(box)
            .setCancelable(false)
            .setNegativeButton("取消") { _, _ -> cancel.set(true) }
            .setNeutralButton("转后台", null)
            .show()

        Thread {
            var created: Uri? = null
            try {
                val dl = HlsDownloader { url ->
                    val h = HashMap<String, String>()
                    h["User-Agent"] = ua
                    if (referer != null) h["Referer"] = referer
                    runCatching { CookieManager.getInstance().getCookie(url) }.getOrNull()?.let { h["Cookie"] = it }
                    h
                }
                val pl = dl.load(u)
                val fileName = "$name.${pl.ext}"
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, pl.mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IOException("无法在「下载」目录创建文件")
                created = uri
                val total = pl.segments.size
                runOnUiThread {
                    bar.isIndeterminate = false
                    bar.max = total
                    msg.text = "0 / $total 个分片"
                    if (pl.live) toast("疑似直播流，只会下载当前列表里的片段")
                }
                val os = contentResolver.openOutputStream(uri) ?: throw IOException("无法写入文件")
                os.buffered().use { w ->
                    dl.writeTo(pl, w, { done, all ->
                        runOnUiThread { bar.progress = done; msg.text = "$done / $all 个分片" }
                    }, { cancel.get() })
                }
                contentResolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
                runOnUiThread { closeQuietly(dlg); toast("已保存到「下载」：$fileName") }
            } catch (e: Throwable) {
                created?.let { runCatching { contentResolver.delete(it, null, null) } }
                runOnUiThread {
                    closeQuietly(dlg)
                    toast(if (e is HlsDownloader.Cancelled) "已取消下载" else "下载失败：${e.message ?: e.javaClass.simpleName}")
                }
            }
        }.start()
    }

    private fun closeQuietly(d: AlertDialog) {
        try { if (d.isShowing) d.dismiss() } catch (e: Exception) { /* Activity 已销毁，忽略 */ }
    }

    /** 去掉文件名里的非法字符并限制长度。 */
    private fun safeName(s: String) =
        s.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").trim().take(60).trim('.', ' ')

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when {
            customView != null -> hideCustomView() // 先退出全屏，再谈网页后退
            web.canGoBack() -> web.goBack()
            else -> super.onBackPressed()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // 全屏中系统栏被临时唤出后失去焦点再回来时，重新隐藏
        if (hasFocus && customView != null) setImmersive(true)
    }
}
