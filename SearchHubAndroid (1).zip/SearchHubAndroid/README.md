# SearchHub (Android)
极简多引擎搜索 + 网页视频嗅探。无第三方依赖，纯系统 WebView。
构建：GitHub Actions，`gradle :app:assembleDebug`（Gradle 8.9 / AGP 8.7.3 / JDK 17）。

## 网页内置播放器全屏
网页里 `<video>` 的全屏按钮可用：横屏沉浸式，返回键先退出全屏（`WebChromeClient.onShowCustomView`）。

## 嗅探列表（点击条目）
- **全屏播放**：`PlayerActivity`，系统 VideoView，横屏沉浸式；竖屏视频自动转竖屏；自动带上网页的 UA / Referer / Cookie。
  系统播放器不支持的格式（如 mpd / flv）会提示并可转外部播放器。
- **下载**
  - 直链（mp4 / webm / mp3 …）：系统 DownloadManager，通知栏显示进度。
  - m3u8：`HlsDownloader` 解析后顺序下载并拼接分片，存到「下载」目录（TS → `.ts`，fMP4 → `.mp4`）。
    支持主列表选最高码率、AES-128、重定向；不支持 SAMPLE-AES/DRM、BYTERANGE、独立音轨。下载期间需保持应用在前台。
  - mpd(DASH)：暂不支持，请复制链接用其他应用。
