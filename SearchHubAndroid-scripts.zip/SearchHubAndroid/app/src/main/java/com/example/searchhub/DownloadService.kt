package com.example.searchhub

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder

/**
 * 前台服务：有 m3u8 下载在跑时常驻一条通知，防止应用切到后台后进程被系统回收、下载中断。
 * 下载线程仍在 [DownloadCenter] 里，这个服务只负责「保活 + 通知」；没有任务时自动停止。
 */
class DownloadService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        DownloadCenter.init(this)
        val n = DownloadCenter.hlsActiveCount()
        if (n <= 0) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIF_ID, buildNotification(this, n), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        return START_NOT_STICKY
    }

    companion object {
        private const val CHANNEL = "downloads"
        private const val NOTIF_ID = 1001

        private fun buildNotification(ctx: Context, n: Int): Notification {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL, "下载", NotificationManager.IMPORTANCE_LOW)
                )
            }
            val open = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, DownloadsActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            return Notification.Builder(ctx, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("SearchHub 正在下载")
                .setContentText("$n 个视频下载中，点击查看进度")
                .setContentIntent(open)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .build()
        }

        /** 任务数量变化时调用：有任务就（重新）启动 / 刷新通知，没有就停止服务。 */
        fun sync(ctx: Context) {
            val app = ctx.applicationContext
            try {
                if (DownloadCenter.hlsActiveCount() > 0) {
                    app.startForegroundService(Intent(app, DownloadService::class.java))
                } else {
                    app.stopService(Intent(app, DownloadService::class.java))
                }
            } catch (e: Exception) {
                // 例如应用在后台时系统不允许启动前台服务：忽略，下载仍照常进行，只是失去保活
            }
        }
    }
}
