package com.example.searchhub

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import android.widget.FrameLayout
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** 全部用 Canvas 画的线性图标（24x24 网格），不依赖任何图片资源。 */
class IconView(ctx: Context, kind: Kind, tint: Int = Ui.ICON) : View(ctx) {

    enum class Kind {
        BACK, FORWARD, HOME, REFRESH, STOP, MENU, DOWNLOAD, STAR, STAR_FILL, SEARCH, CLEAR, LOCK,
        BOOKMARK, HISTORY, SHARE, LINK, DESKTOP, TRASH, UP, DOWN, GLOBE, PLUS, TABS, REOPEN, WARN, CODE
    }

    var kind: Kind = kind
        set(v) { field = v; invalidate() }
    var tint: Int = tint
        set(v) { field = v; invalidate() }

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.8f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()
    private val rect = RectF()

    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) = c.drawLine(x1, y1, x2, y2, stroke)

    private fun poly(c: Canvas, close: Boolean, vararg p: Float) {
        path.reset()
        path.moveTo(p[0], p[1])
        var i = 2
        while (i < p.size) { path.lineTo(p[i], p[i + 1]); i += 2 }
        if (close) path.close()
        c.drawPath(path, stroke)
    }

    override fun onDraw(canvas: Canvas) {
        stroke.color = tint
        fill.color = tint
        canvas.save()
        canvas.scale(width / 24f, height / 24f)
        when (kind) {
            Kind.BACK -> { line(canvas, 19f, 12f, 5f, 12f); poly(canvas, false, 11f, 6f, 5f, 12f, 11f, 18f) }
            Kind.FORWARD -> { line(canvas, 5f, 12f, 19f, 12f); poly(canvas, false, 13f, 6f, 19f, 12f, 13f, 18f) }
            Kind.HOME -> {
                poly(canvas, false, 3.5f, 11f, 12f, 4f, 20.5f, 11f)
                poly(canvas, false, 6f, 9.5f, 6f, 20f, 18f, 20f, 18f, 9.5f)
            }
            Kind.REFRESH -> {
                rect.set(5f, 5f, 19f, 19f)
                canvas.drawArc(rect, -60f, 290f, false, stroke)
                // 箭头画在圆弧末端（顺时针方向）
                val endDeg = 230.0
                val rad = endDeg * PI / 180.0
                val ex = (12 + 7 * cos(rad)).toFloat()
                val ey = (12 + 7 * sin(rad)).toFloat()
                val dx = (-sin(rad)).toFloat()
                val dy = cos(rad).toFloat()
                val nx = -dy
                val ny = dx
                path.reset()
                path.moveTo(ex + dx * 3.2f, ey + dy * 3.2f)
                path.lineTo(ex - dx * 1.2f + nx * 3f, ey - dy * 1.2f + ny * 3f)
                path.lineTo(ex - dx * 1.2f - nx * 3f, ey - dy * 1.2f - ny * 3f)
                path.close()
                canvas.drawPath(path, fill)
            }
            Kind.STOP, Kind.CLEAR -> { line(canvas, 6.5f, 6.5f, 17.5f, 17.5f); line(canvas, 17.5f, 6.5f, 6.5f, 17.5f) }
            Kind.MENU -> {
                canvas.drawCircle(12f, 5f, 1.9f, fill)
                canvas.drawCircle(12f, 12f, 1.9f, fill)
                canvas.drawCircle(12f, 19f, 1.9f, fill)
            }
            Kind.DOWNLOAD -> {
                line(canvas, 12f, 4f, 12f, 15f)
                poly(canvas, false, 7f, 10.5f, 12f, 15.5f, 17f, 10.5f)
                line(canvas, 5f, 20f, 19f, 20f)
            }
            Kind.STAR, Kind.STAR_FILL -> {
                path.reset()
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) 9f else 4.0f
                    val a = -PI / 2 + i * PI / 5
                    val x = (12 + r * cos(a)).toFloat()
                    val y = (12.5 + r * sin(a)).toFloat()
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
                if (kind == Kind.STAR_FILL) {
                    fill.color = 0xFFF5A623.toInt()
                    canvas.drawPath(path, fill)
                } else {
                    canvas.drawPath(path, stroke)
                }
            }
            Kind.SEARCH -> {
                canvas.drawCircle(10.5f, 10.5f, 6f, stroke)
                line(canvas, 15f, 15f, 20f, 20f)
            }
            Kind.LOCK -> {
                rect.set(5.5f, 10.5f, 18.5f, 20.5f)
                canvas.drawRoundRect(rect, 2.5f, 2.5f, stroke)
                rect.set(8f, 3.5f, 16f, 12f)
                canvas.drawArc(rect, 180f, 180f, false, stroke)
                line(canvas, 8f, 7.75f, 8f, 10.5f)
                line(canvas, 16f, 7.75f, 16f, 10.5f)
            }
            Kind.BOOKMARK -> poly(canvas, true, 7f, 4f, 17f, 4f, 17f, 20f, 12f, 16f, 7f, 20f)
            Kind.HISTORY -> {
                canvas.drawCircle(12f, 12f, 8.5f, stroke)
                poly(canvas, false, 12f, 7f, 12f, 12f, 15.5f, 14f)
            }
            Kind.SHARE -> {
                canvas.drawCircle(18f, 5.5f, 2.6f, stroke)
                canvas.drawCircle(6f, 12f, 2.6f, stroke)
                canvas.drawCircle(18f, 18.5f, 2.6f, stroke)
                line(canvas, 8.2f, 10.8f, 15.8f, 6.7f)
                line(canvas, 8.2f, 13.2f, 15.8f, 17.3f)
            }
            Kind.LINK -> {
                canvas.save()
                canvas.rotate(-45f, 12f, 12f)
                rect.set(2.5f, 8.5f, 13.5f, 15.5f)
                canvas.drawRoundRect(rect, 3.5f, 3.5f, stroke)
                rect.set(10.5f, 8.5f, 21.5f, 15.5f)
                canvas.drawRoundRect(rect, 3.5f, 3.5f, stroke)
                canvas.restore()
            }
            Kind.DESKTOP -> {
                rect.set(3f, 4.5f, 21f, 16f)
                canvas.drawRoundRect(rect, 2f, 2f, stroke)
                line(canvas, 12f, 16f, 12f, 20f)
                line(canvas, 8f, 20f, 16f, 20f)
            }
            Kind.TRASH -> {
                line(canvas, 4.5f, 7f, 19.5f, 7f)
                line(canvas, 10f, 4f, 14f, 4f)
                rect.set(6.5f, 7f, 17.5f, 20.5f)
                canvas.drawRoundRect(rect, 2f, 2f, stroke)
            }
            Kind.UP -> poly(canvas, false, 6f, 15f, 12f, 9f, 18f, 15f)
            Kind.DOWN -> poly(canvas, false, 6f, 9f, 12f, 15f, 18f, 9f)
            Kind.GLOBE -> {
                canvas.drawCircle(12f, 12f, 9f, stroke)
                rect.set(7.5f, 3f, 16.5f, 21f)
                canvas.drawOval(rect, stroke)
                line(canvas, 3f, 12f, 21f, 12f)
            }
            Kind.PLUS -> { line(canvas, 12f, 5f, 12f, 19f); line(canvas, 5f, 12f, 19f, 12f) }
            Kind.TABS -> {
                rect.set(4f, 4f, 20f, 20f)
                canvas.drawRoundRect(rect, 4f, 4f, stroke)
            }
            Kind.REOPEN -> {
                rect.set(5f, 5f, 19f, 19f)
                canvas.drawArc(rect, 40f, 280f, false, stroke)
                poly(canvas, false, 4f, 4.5f, 5.5f, 9.5f, 10.5f, 8f)
            }
            Kind.WARN -> {
                poly(canvas, true, 12f, 3.5f, 21f, 19.5f, 3f, 19.5f)
                line(canvas, 12f, 9.5f, 12f, 14f)
                canvas.drawCircle(12f, 16.8f, 1f, fill)
            }
            Kind.CODE -> {
                poly(canvas, false, 8.5f, 7f, 3.5f, 12f, 8.5f, 17f)
                poly(canvas, false, 15.5f, 7f, 20.5f, 12f, 15.5f, 17f)
                line(canvas, 13.5f, 5f, 10.5f, 19f)
            }
        }
        canvas.restore()
    }
}

/** 带圆形涟漪 + 轻微缩放反馈的图标按钮。 */
fun Context.iconButton(kind: IconView.Kind, sizeDp: Int = 44, iconDp: Int = 22, tint: Int = Ui.ICON, onClick: () -> Unit): FrameLayout {
    val box = FrameLayout(this)
    val icon = IconView(this, kind, tint)
    box.addView(icon, FrameLayout.LayoutParams(dp(iconDp), dp(iconDp), android.view.Gravity.CENTER))
    box.minimumWidth = dp(sizeDp)
    box.minimumHeight = dp(sizeDp)
    box.isClickable = true
    box.background = rippleOf(null, dp(sizeDp) / 2f)
    box.pressFeedback(0.88f)
    box.setOnClickListener { onClick() }
    box.tag = icon
    return box
}

val FrameLayout.iconView: IconView get() = tag as IconView
