package com.example.searchhub

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * 「下载此文件」底部面板（参考主流下载类浏览器）：
 * 下载链接（可改）/ 文件名（可改）/ 大小 / 下载目录（可改子文件夹），
 * 「其他下载器」可选的应用（已安装的外部下载器 / 浏览器），
 * 底部「取消」「立即下载」。点外部应用只是把链接交给它，不会触发内置下载。
 */
class DownloadSheet(
    private val act: Activity,
    private val host: FrameLayout,
    private val ua: () -> String,
    private val pageUrl: () -> String?,
    private val baseName: (SniffItem) -> String,
    private val onStarted: () -> Unit
) {

    /** 限制最大高度的纵向容器：内容少时贴合内容，内容多时让中间的 ScrollView 收缩。 */
    private class CappedLayout(ctx: Context) : LinearLayout(ctx) {
        var maxHeightPx = Int.MAX_VALUE
        override fun onMeasure(widthSpec: Int, heightSpec: Int) {
            val size = View.MeasureSpec.getSize(heightSpec)
            val cap = View.MeasureSpec.makeMeasureSpec(minOf(size, maxHeightPx), View.MeasureSpec.AT_MOST)
            super.onMeasure(widthSpec, cap)
        }
    }

    private class Tile(val label: String, val icon: View, val onClick: () -> Unit)

    private val prefs = act.getSharedPreferences("sniff_ui", Context.MODE_PRIVATE)

    val layer = FrameLayout(act)
    private val sheet = CappedLayout(act)
    private val urlEdit = EditText(act)
    private val nameEdit = EditText(act)
    private val sizeText = TextView(act)
    private val mpdHint = TextView(act)
    private val dirText = TextView(act)
    private val dlBody = LinearLayout(act)
    private val confirm = TextView(act)

    private var item: SniffItem? = null
    private var nameEdited = false
    private var updating = false

    val isShowing: Boolean get() = layer.visibility == View.VISIBLE

    private fun dp(v: Int) = act.dp(v)

    init {
        buildUi()
    }

    // ---------- 界面 ----------

    private fun fieldBg() = roundRect(0xFFF5F6F9.toInt(), dp(14).toFloat())

    private fun label(t: String) = TextView(act).apply {
        text = t
        textSize = 13f
        setTextColor(Ui.TEXT_SUB)
        setPadding(dp(4), 0, 0, dp(6))
    }

    private fun lp(w: Int, h: Int, weight: Float = 0f, top: Int = 0, left: Int = 0) =
        LinearLayout.LayoutParams(w, h, weight).apply {
            topMargin = dp(top)
            leftMargin = dp(left)
        }

    private fun buildUi() {
        // 标题栏
        val title = TextView(act).apply {
            text = "下载此文件"
            textSize = 20f
            setTextColor(Ui.TEXT)
            typeface = Typeface.DEFAULT_BOLD
        }
        val menuBtn = FrameLayout(act).apply {
            background = roundRect(0xFFEDEEF4.toInt(), dp(20).toFloat())
            addView(Glyph(act, Glyph.DOTS, Ui.TEXT_SUB), FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
            setOnClickListener { showMenu() }
        }
        val header = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(14), dp(16), dp(12))
            addView(title, lp(0, -2, 1f))
            addView(menuBtn, lp(dp(40), dp(40)))
        }

        // 下载链接
        urlEdit.apply {
            background = null
            isSingleLine = true
            ellipsize = TextUtils.TruncateAt.END
            textSize = 14f
            setTextColor(Ui.TEXT)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setPadding(0, dp(14), dp(8), dp(14))
            addTextChangedListener(simpleWatcher { onUrlChanged() })
        }
        val clearBtn = FrameLayout(act).apply {
            background = roundRect(0xFFE6E8EE.toInt(), dp(12).toFloat())
            addView(Glyph(act, Glyph.CLOSE, Ui.TEXT_SUB), FrameLayout.LayoutParams(dp(14), dp(14), Gravity.CENTER))
            setOnClickListener { urlEdit.setText(""); urlEdit.requestFocus() }
        }
        val urlRow = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = fieldBg()
            setPadding(dp(16), 0, dp(12), 0)
            addView(urlEdit, lp(0, -2, 1f))
            addView(clearBtn, lp(dp(24), dp(24)))
        }

        // 文件名 / 大小
        nameEdit.apply {
            background = null
            isSingleLine = true
            ellipsize = TextUtils.TruncateAt.MIDDLE
            textSize = 15f
            setTextColor(Ui.TEXT)
            setPadding(0, dp(14), 0, dp(14))
            addTextChangedListener(simpleWatcher { if (!updating) nameEdited = true })
        }
        val nameBox = LinearLayout(act).apply {
            background = fieldBg()
            setPadding(dp(16), 0, dp(12), 0)
            addView(nameEdit, lp(-1, -2))
        }
        sizeText.apply {
            textSize = 13f
            setTextColor(Ui.TEXT_SUB)
            gravity = Gravity.CENTER
            background = fieldBg()
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val nameCol = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            addView(label("文件名"))
            addView(nameBox, lp(-1, dp(52)))
        }
        val sizeCol = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            addView(label("大小"))
            addView(sizeText, lp(-1, dp(52)))
        }
        val nameRow = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(nameCol, lp(0, -2, 1.6f))
            addView(sizeCol, lp(0, -2, 1f, left = 12))
        }

        mpdHint.apply {
            text = "DASH(mpd) 暂不支持内置下载，请在下方选择其他下载器。"
            textSize = 12f
            setTextColor(Ui.ORANGE)
            visibility = View.GONE
        }

        // 下载目录
        val folderIcon = FrameLayout(act).apply {
            background = roundRect(0xFFFFF1B8.toInt(), dp(18).toFloat())
            addView(Glyph(act, Glyph.FOLDER, 0xFFD39B00.toInt()), FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        }
        dirText.apply {
            textSize = 14f
            setTextColor(Ui.TEXT)
            isSingleLine = true
            ellipsize = TextUtils.TruncateAt.MIDDLE
        }
        val changeBtn = TextView(act).apply {
            text = "更改"
            textSize = 14f
            setTextColor(Ui.PRIMARY)
            gravity = Gravity.CENTER
            background = roundRect(Ui.PRIMARY_LIGHT, dp(12).toFloat())
            setPadding(dp(14), dp(7), dp(14), dp(7))
            setOnClickListener { changeDir() }
        }
        val dirRow = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = fieldBg()
            setPadding(dp(12), dp(10), dp(12), dp(10))
            addView(folderIcon, lp(dp(36), dp(36)))
            addView(dirText, lp(0, -2, 1f, left = 12))
            addView(changeBtn, lp(-2, -2, left = 8))
        }

        val content = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(12))
            addView(label("下载链接"))
            addView(urlRow, lp(-1, dp(52)))
            addView(nameRow, lp(-1, -2, top = 16))
            addView(mpdHint, lp(-1, -2, top = 8))
            addView(label("下载目录").apply { setPadding(dp(4), 0, 0, dp(6)) }, lp(-2, -2, top = 16))
            addView(dirRow, lp(-1, -2))
            addView(group("其他下载器", Glyph.DOWNLOAD, dlBody), lp(-1, -2, top = 20))
        }
        val scroll = ScrollView(act).apply {
            isVerticalScrollBarEnabled = false
            addView(content, FrameLayout.LayoutParams(-1, -2))
        }

        // 底部按钮
        val cancel = TextView(act).apply {
            text = "取消"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Ui.TEXT)
            gravity = Gravity.CENTER
            background = roundRect(0xFFF0F1F4.toInt(), dp(26).toFloat())
            setOnClickListener { hide() }
        }
        confirm.apply {
            text = "立即下载"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Ui.WHITE)
            gravity = Gravity.CENTER
            background = roundRect(Ui.PRIMARY, dp(26).toFloat())
            setOnClickListener { startDownload() }
        }
        val bar = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(20), dp(8), dp(20), dp(16))
            addView(cancel, lp(0, dp(52), 1f))
            addView(confirm, lp(0, dp(52), 2f, left = 12))
        }

        sheet.apply {
            orientation = LinearLayout.VERTICAL
            background = roundRect(Ui.WHITE, dp(24).toFloat(), topOnly = true)
            elevation = dp(16).toFloat()
            isClickable = true   // 吞掉点击，避免落到下面的遮罩上把面板关掉
            addView(header)
            addView(View(act).apply { setBackgroundColor(Ui.DIVIDER) }, lp(-1, dp(1)))
            addView(scroll, lp(-1, 0, 1f))
            addView(bar)
        }
        val scrim = View(act).apply {
            setBackgroundColor(0x66000000)
            setOnClickListener { hide() }
        }
        layer.apply {
            visibility = View.GONE
            addView(scrim, FrameLayout.LayoutParams(-1, -1))
            addView(sheet, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        }
    }

    /** 可折叠的分组卡片：左图标 + 标题 + 箭头，点标题栏展开 / 收起。 */
    private fun group(titleText: String, icon: Int, body: LinearLayout): View {
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(8), dp(14), dp(8), dp(14))
        val iconBox = FrameLayout(act).apply {
            background = roundRect(Ui.WHITE, dp(18).toFloat())
            addView(Glyph(act, icon, Ui.TEXT), FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
        }
        val chevron = Glyph(act, Glyph.CHEVRON, Ui.TEXT_SUB).apply { rotation = 180f }  // 展开状态朝上
        val head = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            addView(iconBox, lp(dp(36), dp(36)))
            addView(TextView(act).apply {
                text = titleText
                textSize = 16f
                setTextColor(Ui.TEXT)
                typeface = Typeface.DEFAULT_BOLD
            }, lp(0, -2, 1f, left = 12))
            addView(chevron, lp(dp(22), dp(22)))
            setOnClickListener {
                val open = body.visibility != View.VISIBLE
                body.visibility = if (open) View.VISIBLE else View.GONE
                chevron.rotation = if (open) 180f else 0f
            }
        }
        return LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = roundRect(0xFFF7F8FA.toInt(), dp(18).toFloat())
            addView(head)
            addView(View(act).apply { setBackgroundColor(Ui.DIVIDER) }, lp(-1, dp(1)))
            addView(body)
        }
    }

    private fun simpleWatcher(f: () -> Unit) = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
        override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        override fun afterTextChanged(s: Editable?) = f()
    }

    // ---------- 显示 / 隐藏 ----------

    fun show(si: SniffItem) {
        item = si
        nameEdited = false
        updating = true
        urlEdit.setText(si.url)
        nameEdit.setText(defaultName(si))
        updating = false
        dirText.text = dirLabel()
        updateState()
        fillApps(si)
        sheet.maxHeightPx = (host.height * 0.9f).toInt()
        sheet.animate().cancel()
        sheet.translationY = host.height.toFloat()
        layer.visibility = View.VISIBLE
        sheet.animate().translationY(0f).setDuration(220).start()
    }

    fun hide() {
        if (!isShowing) return
        val imm = act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(layer.windowToken, 0)
        urlEdit.clearFocus()
        nameEdit.clearFocus()
        layer.visibility = View.GONE
    }

    /** 后台探测到新信息（大小、HLS 输出格式…）时由外部调用。 */
    fun refresh() {
        val si = item ?: return
        if (!isShowing) return
        if (!nameEdited) {
            val n = defaultName(si)
            if (nameEdit.text.toString() != n) {
                updating = true
                nameEdit.setText(n)
                updating = false
            }
        }
        updateState()
    }

    // ---------- 状态 ----------

    private fun currentUrl() = urlEdit.text.toString().trim()

    private fun pathOf(u: String) = Uri.parse(u).path ?: ""

    private fun defaultName(si: SniffItem): String {
        val base = baseName(si)
        val ext = if (si.isHls) (si.outExt ?: "ts") else si.ext.lowercase()
        return if (ext.isEmpty()) base else "$base.$ext"
    }

    private fun onUrlChanged() {
        if (item != null) updateState()
    }

    /** 根据当前链接刷新「大小」文字和「立即下载」是否可用。 */
    private fun updateState() {
        val si = item ?: return
        val u = currentUrl()
        sizeText.text = when {
            u != si.url -> "下载结束才可统计"
            si.size > 0 -> (if (si.sizeEstimated) "约 " else "") + formatSize(si.size)
            si.state != 2 -> "读取中…"
            else -> "下载结束才可统计"
        }
        val mpd = pathOf(u).endsWith(".mpd", ignoreCase = true)
        mpdHint.visibility = if (mpd) View.VISIBLE else View.GONE
        confirm.isEnabled = !mpd
        confirm.alpha = if (mpd) 0.4f else 1f
    }

    // ---------- 下载目录 ----------

    private fun subDir(): String = prefs.getString("sub_dir", "") ?: ""

    private fun dirLabel(): String {
        val s = subDir()
        return if (s.isEmpty()) "手机存储/Download" else "手机存储/Download/$s"
    }

    /** 只保留合法的子文件夹路径：最多 3 层，去掉 . / .. 和非法字符。 */
    private fun cleanSubDir(raw: String): String =
        raw.split('/', '\\').map { safeName(it, 40) }.filter { it.isNotEmpty() && it != "." && it != ".." }.take(3).joinToString("/")

    private fun changeDir() {
        val et = EditText(act).apply {
            setText(subDir())
            hint = "留空 = 直接保存在 Download"
            isSingleLine = true
            setSelection(text.length)
        }
        val box = FrameLayout(act).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(et, FrameLayout.LayoutParams(-1, -2))
        }
        AlertDialog.Builder(act)
            .setTitle("保存到 Download 下的文件夹")
            .setView(box)
            .setPositiveButton("确定") { _, _ ->
                prefs.edit().putString("sub_dir", cleanSubDir(et.text.toString())).apply()
                dirText.text = dirLabel()
            }
            .setNeutralButton("恢复默认") { _, _ ->
                prefs.edit().putString("sub_dir", "").apply()
                dirText.text = dirLabel()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    // ---------- 应用选择 ----------

    private fun fillApps(si: SniffItem) {
        val audio = si.isAudio
        val hls = si.isHls

        // 下载器：已安装的常见下载器 + 浏览器 + 更多…
        val dls = ArrayList<Tile>()
        val known = ExternalApps.downloaders(act)
        for (app in known) {
            dls.add(Tile(app.label, appIcon(app)) {
                ExternalApps.launchDownloader(act, app, currentUrl(), nameEdit.text.toString().trim(), ua(), pageUrl())
            })
        }
        for (app in ExternalApps.browsers(act)) {
            dls.add(Tile(app.label, appIcon(app)) { ExternalApps.launchBrowser(act, app, currentUrl()) })
        }
        dls.add(Tile("更多…", iconBox(Glyph.DOTS, Ui.TEXT_SUB, 0xFFE9EBF0.toInt())) {
            ExternalApps.shareLink(act, currentUrl())
        })
        fillGrid(dlBody, dls)
        if (known.isEmpty()) {
            dlBody.addView(TextView(act).apply {
                text = "安装 ADM、1DM、迅雷等下载器后，会自动出现在这里。"
                textSize = 11f
                setTextColor(0xFFA0A5B3.toInt())
                gravity = Gravity.CENTER
            }, lp(-1, -2, top = 12))
        }
    }

    private fun titleOf(): String = nameEdit.text.toString().trim().ifEmpty { item?.let { baseName(it) } ?: "video" }

    private fun appIcon(app: ExternalApps.App): View = ImageView(act).apply {
        setImageDrawable(app.icon)
        scaleType = ImageView.ScaleType.FIT_CENTER
    }

    private fun iconBox(glyph: Int, fg: Int, bg: Int): View = FrameLayout(act).apply {
        background = roundRect(bg, dp(12).toFloat())
        addView(Glyph(act, glyph, fg), FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
    }

    private fun tileView(t: Tile): View = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(2), dp(4), dp(2), dp(4))
        addView(t.icon, LinearLayout.LayoutParams(dp(44), dp(44)))
        addView(TextView(act).apply {
            text = t.label
            textSize = 11f
            setTextColor(Ui.TEXT)
            gravity = Gravity.CENTER
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }, lp(-1, -2, top = 6))
        setOnClickListener { t.onClick() }
    }

    /** 每行 4 个，最后一行用空白补齐，保证每个格子等宽。 */
    private fun fillGrid(body: LinearLayout, tiles: List<Tile>) {
        body.removeAllViews()
        val cols = 4
        var i = 0
        while (i < tiles.size) {
            val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until cols) {
                val t = tiles.getOrNull(i + c)
                if (t != null) row.addView(tileView(t), lp(0, -2, 1f))
                else row.addView(View(act), lp(0, 1, 1f))
            }
            body.addView(row, lp(-1, -2, top = if (i > 0) 12 else 0))
            i += cols
        }
    }

    // ---------- 菜单 / 下载 ----------

    private fun showMenu() {
        AlertDialog.Builder(act)
            .setItems(arrayOf("复制链接", "分享链接")) { _, which ->
                val u = currentUrl()
                if (which == 0) {
                    (act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("url", u))
                    toast("已复制")
                } else {
                    ExternalApps.shareLink(act, u)
                }
            }.show()
    }

    private fun startDownload() {
        val si = item ?: return
        val url = currentUrl()
        if (!Regex("^https?://\\S+$", RegexOption.IGNORE_CASE).matches(url)) {
            toast("链接无效，需要以 http:// 或 https:// 开头")
            return
        }
        val path = pathOf(url)
        if (path.endsWith(".mpd", ignoreCase = true)) {
            toast("DASH(mpd) 暂不支持内置下载，请选择其他下载器")
            return
        }
        val typed = safeName(nameEdit.text.toString(), 120)
        val sub = cleanSubDir(subDir())
        if (path.endsWith(".m3u8", ignoreCase = true)) {
            // m3u8 会被合并成 .ts / .mp4，扩展名由下载器决定，这里只取名字部分
            val base = typed.replace(Regex("(?i)\\.(m3u8|ts|mp4)$"), "").ifEmpty { safeName(baseName(si)) }.ifEmpty { "video" }
            DownloadCenter.startHls(url, base, ua(), pageUrl(), sub)
        } else {
            val ext = path.substringAfterLast('.', "").lowercase()
            val fallback = safeName(baseName(si), 120).ifEmpty { "video" }
            var name = typed.ifEmpty { fallback }
            val hasExt = Regex("\\.[A-Za-z0-9]{1,5}$").containsMatchIn(name)
            if (!hasExt && Regex("^[a-z0-9]{1,5}$").matches(ext)) name = "$name.$ext"
            DownloadCenter.startDirect(url, name, ua(), pageUrl(), sub)
        }
        toast("已加入下载，点右上角「下载」查看进度")
        hide()
        onStarted()
    }

    private fun toast(s: String) = Toast.makeText(act, s, Toast.LENGTH_SHORT).show()
}
