package com.example.searchhub

import java.io.ByteArrayOutputStream
import java.net.URL
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max

/**
 * 嗅探到的往往只是网页「当前正在播」的那一档（比如 480p 的子列表 / 480p 的 mp4）。
 * 这里在后台尽力去找同一个视频的更高画质，找到就返回新地址，找不到返回 null（不影响原资源）。
 *
 * - m3u8 子列表：先在同目录 / 上两级目录里找主列表（master / index / playlist / main .m3u8），
 *   再试把 URL 里的清晰度数字（480p → 1080p …）换成更高档。
 *   候选必须是有效的 m3u8，且总时长和原资源基本一致（防止找到别的视频），否则丢弃。
 * - mp4 / flv 等直链：只试把 URL 里的清晰度数字换成更高档，候选必须是视频类型且文件更大。
 * - 已经是主列表的 m3u8、直播、mpd：不处理（主列表本来就会自动选最高码率）。
 *
 * 只是按常见的命名规律猜，没有通用办法保证一定能找到；带签名 / 鉴权的地址猜出来多半会 403，那就保持原样。
 */
class QualityFinder(private val headers: (String) -> Map<String, String>) {

    private val dl = HlsDownloader(headers)
    private val pool = Executors.newFixedThreadPool(2) { r -> Thread(r).apply { isDaemon = true } }

    /** 在后台查找；只有找到更高画质时才回调 [done]（回调在后台线程）。 */
    fun findAsync(url: String, ext: String, done: (String) -> Unit) {
        pool.execute {
            val better = try { find(url, ext) } catch (e: Throwable) { null }
            if (better != null && better != url) done(better)
        }
    }

    private fun find(url: String, ext: String): String? = when (ext) {
        "M3U8" -> findHls(url)
        "MP4", "FLV", "WEBM", "MKV", "MOV", "M4V", "F4V" -> findFile(url)
        else -> null
    }

    // ---------- m3u8 ----------

    private fun findHls(url: String): String? {
        val text = fetchPlaylist(url) ?: return null
        if (text.contains("#EXT-X-STREAM-INF")) return null // 已经是主列表
        val orig = try { dl.load(url) } catch (e: Exception) { return null }
        if (orig.live || orig.durationSec <= 0) return null

        // 1) 找主列表
        for (m in masterCandidates(url)) {
            val t = fetchPlaylist(m) ?: continue
            if (!t.contains("#EXT-X-STREAM-INF")) continue
            val pl = try { dl.load(m) } catch (e: Exception) { continue }
            if (sameDuration(orig.durationSec, pl.durationSec)) return m
        }
        // 2) URL 里有清晰度数字：从高到低试，第一个有效的就是最高档
        for (c in tokenCandidates(url)) {
            val t = fetchPlaylist(c) ?: continue
            if (t == text) continue // 服务器对任何路径都返回同一份内容
            val pl = try { dl.load(c) } catch (e: Exception) { continue }
            if (!pl.live && sameDuration(orig.durationSec, pl.durationSec)) return c
        }
        return null
    }

    private fun sameDuration(a: Double, b: Double) = abs(a - b) <= max(3.0, a * 0.03)

    private fun masterCandidates(url: String): List<String> {
        val u = URL(url)
        val query = if (u.query != null) "?" + u.query else ""
        val origin = "${u.protocol}://${u.authority}"
        val names = listOf("master.m3u8", "index.m3u8", "playlist.m3u8", "main.m3u8")
        val out = LinkedHashSet<String>()
        var dir = u.path.substringBeforeLast('/', "")
        for (level in 0..2) {
            if (level > 0 && dir.isEmpty()) break
            for (n in names) out.add("$origin$dir/$n$query")
            dir = dir.substringBeforeLast('/', "")
        }
        out.remove(url)
        return out.toList()
    }

    /** 取 m3u8 文本（最多 512KB）；不是有效的 m3u8 返回 null。 */
    private fun fetchPlaylist(url: String): String? = try {
        val c = dl.openConnection(url)
        try {
            val out = ByteArrayOutputStream()
            val buf = ByteArray(8192)
            c.inputStream.use { ins ->
                while (out.size() < 512 * 1024) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                }
            }
            val s = String(out.toByteArray(), Charsets.UTF_8).removePrefix("\uFEFF")
            if (s.trimStart().startsWith("#EXTM3U")) s else null
        } finally {
            c.disconnect()
        }
    } catch (e: Exception) {
        null
    }

    // ---------- 直链 ----------

    private fun findFile(url: String): String? {
        val origLen = try { dl.contentLength(url) } catch (e: Exception) { -1L }
        for (c in tokenCandidates(url)) {
            val len = videoLength(c)
            if (len > 100_000 && (origLen <= 0 || len > origLen)) return c
        }
        return null
    }

    /** 用 Range 请求探测候选地址：是视频类型就返回文件大小，否则 -1。 */
    private fun videoLength(url: String): Long = try {
        val c = dl.openConnection(url, mapOf("Range" to "bytes=0-0"))
        try {
            val type = (c.contentType ?: "").lowercase()
            if (type.startsWith("text/") || type.contains("html") || type.contains("json")) {
                -1L
            } else if (c.responseCode == 206) {
                c.getHeaderField("Content-Range")?.substringAfterLast('/')?.trim()?.toLongOrNull() ?: -1L
            } else {
                c.contentLengthLong
            }
        } finally {
            c.disconnect()
        }
    } catch (e: Exception) {
        -1L
    }

    // ---------- 清晰度数字替换 ----------

    /** 把 URL（不含域名部分）里的清晰度数字换成更高档，从最高档开始排。 */
    private fun tokenCandidates(url: String): List<String> {
        val start = url.indexOf("://") + 3
        val i = url.indexOf('/', start)
        if (start < 3 || i < 0) return emptyList()
        val head = url.substring(0, i)
        val rest = url.substring(i)
        val m = TOKEN.find(rest) ?: return emptyList()
        val tok = m.groupValues[1]
        val cur = tok.toInt()
        return LADDER.filter { it > cur }.map { h ->
            head + TOKEN.replace(rest) { r ->
                if (r.groupValues[1] == tok) h.toString() + r.groupValues[2] else r.value
            }
        }
    }

    companion object {
        private val LADDER = listOf(2160, 1440, 1080, 720, 540, 480, 360, 240)
        // 前后不能紧挨字母 / 数字，避免误伤 "abc480def"、"2480"、"480x270"
        private val TOKEN = Regex("(?<![0-9A-Za-z])(2160|1440|1080|720|540|480|360|240)([pP]?)(?![0-9A-Za-z])")
    }
}
