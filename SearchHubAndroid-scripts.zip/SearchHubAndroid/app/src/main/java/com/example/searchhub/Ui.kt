package com.example.searchhub

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.os.Build
import android.view.WindowInsetsController
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.TextView
import java.util.Locale

/** 界面用到的颜色与小工具（全部用代码绘制，不依赖资源文件）。 */
object Ui {
    // 靛青为主色：只出现在进度条、选中态和主按钮上；文字用墨色，界面其余部分保持安静的冷灰白
    val PRIMARY: Int = 0xFF4256E0.toInt()
    val PRIMARY_LIGHT: Int = 0xFFE9ECFC.toInt()
    val GREEN: Int = 0xFF1E9E57.toInt()
    val GREEN_LIGHT: Int = 0xFFE3F5EA.toInt()
    val RED: Int = 0xFFD93025.toInt()
    val RED_LIGHT: Int = 0xFFFDE8E7.toInt()
    val ORANGE: Int = 0xFFF28B1C.toInt()
    val TEXT: Int = 0xFF14161C.toInt()
    val TEXT_SUB: Int = 0xFF6E7383.toInt()
    val DIVIDER: Int = 0xFFEDEEF3.toInt()
    val WHITE: Int = 0xFFFFFFFF.toInt()
    val SURFACE: Int = 0xFFEEF0F6.toInt()
    /** 浏览器外框（地址栏 / 工具栏 / 起始页）的底色。 */
    val CHROME: Int = 0xFFF5F6FA.toInt()
    val ICON: Int = 0xFF2C303B.toInt()
    val ICON_DIM: Int = 0xFFA3A8B6.toInt()
    /** 按压涟漪：墨色 12%。 */
    val RIPPLE: Int = 0x1F2C303B

    /** 中等字重（500），比 bold 轻、比 regular 稳，做标题和按钮文字。 */
    val MEDIUM: Typeface = Typeface.create(Typeface.DEFAULT, 500, false)
    /** 衬线体，只用在起始页的问候语上。 */
    val DISPLAY: Typeface = Typeface.create(Typeface.SERIF, 600, false)

    /** 站点徽标用的渐变色对（亮 → 深），按域名取，同一个站点颜色永远一样。 */
    val BADGES: List<Pair<Int, Int>> = listOf(
        0xFF8CA0FF.toInt() to 0xFF4256E0.toInt(),
        0xFF5ED6B0.toInt() to 0xFF1C9C86.toInt(),
        0xFFFFA59A.toInt() to 0xFFE5546B.toInt(),
        0xFFFFCB78.toInt() to 0xFFF08A1C.toInt(),
        0xFFBE98FF.toInt() to 0xFF7B4DFF.toInt(),
        0xFF6CCBEA.toInt() to 0xFF2B8FD0.toInt()
    )
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun roundRect(color: Int, radius: Float, topOnly: Boolean = false): GradientDrawable {
    val d = GradientDrawable()
    d.setColor(color)
    if (topOnly) d.setCornerRadii(floatArrayOf(radius, radius, radius, radius, 0f, 0f, 0f, 0f))
    else d.setCornerRadius(radius)
    return d
}

/** 带按压涟漪的背景。[content] 为底色（可空），[radius] 为涟漪边界的圆角。 */
fun rippleOf(content: Drawable?, radius: Float = 0f): RippleDrawable =
    RippleDrawable(ColorStateList.valueOf(Ui.RIPPLE), content, roundRect(0xFF000000.toInt(), radius))

/** 站点徽标底：按 [key]（域名）挑一组渐变色，斜向渲染的圆角方块。 */
fun Context.badge(key: String, radiusDp: Int): GradientDrawable {
    val p = Ui.BADGES[(key.hashCode() and 0x7fffffff) % Ui.BADGES.size]
    val d = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(p.first, p.second))
    d.setCornerRadius(dp(radiusDp).toFloat())
    return d
}

private val pressIn = DecelerateInterpolator()
private val pressOut = OvershootInterpolator(2.4f)

/** 按下时轻轻缩一点，松手时带一点回弹。不拦截触摸，点击 / 长按照常工作。 */
@SuppressLint("ClickableViewAccessibility")
fun View.pressFeedback(scale: Float = 0.95f) {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                v.animate().scaleX(scale).scaleY(scale).setDuration(90).setInterpolator(pressIn).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(pressOut).start()
        }
        false
    }
}

/** 圆角小按钮（文字 + 底色）。 */
fun Context.pill(text: String, fg: Int, bg: Int, onClick: () -> Unit): TextView {
    val t = TextView(this)
    t.text = text
    t.setTextColor(fg)
    t.textSize = 13f
    t.typeface = Ui.MEDIUM
    t.gravity = Gravity.CENTER
    t.setPadding(dp(16), dp(7), dp(16), dp(7))
    t.background = rippleOf(roundRect(bg, dp(16).toFloat()), dp(16).toFloat())
    t.pressFeedback(0.94f)
    t.setOnClickListener { onClick() }
    return t
}

/** 去掉文件名里的非法字符并限制长度。 */
fun safeName(s: String, max: Int = 60): String =
    s.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").trim().take(max).trim('.', ' ')

fun formatSize(b: Long): String {
    if (b < 0) return "未知大小"
    val k = 1024.0
    return when {
        b < 1024 -> "$b B"
        b < 1024L * 1024 -> String.format(Locale.US, "%.1f KB", b / k)
        b < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", b / k / k)
        else -> String.format(Locale.US, "%.2f GB", b / k / k / k)
    }
}

fun formatDuration(sec: Double): String {
    val s = sec.toLong()
    val h = s / 3600
    val m = s % 3600 / 60
    val ss = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, ss)
    else String.format(Locale.US, "%02d:%02d", m, ss)
}

/** 细进度条。fraction < 0 表示进度未知（画一条半透明满条）。 */
class ProgressLine(ctx: Context) : View(ctx) {
    var fraction: Float = 0f
    var color: Int = Ui.PRIMARY
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f
        paint.color = 0xFFE6E8EE.toInt()
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, r, r, paint)
        paint.color = color
        if (fraction < 0f) {
            paint.alpha = 90
            canvas.drawRoundRect(rect, r, r, paint)
            paint.alpha = 255
        } else if (fraction > 0f) {
            rect.set(0f, 0f, maxOf(h, w * minOf(fraction, 1f)), h)
            canvas.drawRoundRect(rect, r, r, paint)
        }
    }
}

/** 状态栏 / 导航栏改成浅底深色图标（需在 setContentView 之后调用）。[color] 默认白色。 */
@Suppress("DEPRECATION")
fun Activity.lightBars(color: Int = Ui.WHITE) {
    window.statusBarColor = color
    window.navigationBarColor = color
    if (Build.VERSION.SDK_INT >= 30) {
        val m = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        window.insetsController?.setSystemBarsAppearance(m, m)
    } else {
        val d = window.decorView
        d.systemUiVisibility = d.systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
    }
}
