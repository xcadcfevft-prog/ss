package com.example.searchhub

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayOutputStream

/**
 * 脚本管理页：列表 + 开关；右上角「＋」可新建 / 粘贴代码、导入脚本文件、从剪贴板导入；
 * 点一条编辑，长按 编辑 / 复制代码 / 删除。脚本在网页加载时由 MainActivity 注入，改动后刷新网页生效。
 */
class ScriptsActivity : Activity() {

    companion object {
        private const val REQ_PICK = 21
        private const val MAX_BYTES = 2_000_000        // 单个文件读取上限
        private const val MAX_EDIT_CHARS = 300_000     // 超过这个长度不在应用内编辑（EditText 会很卡）
    }

    private var data: List<Scripts.Script> = emptyList()
    private lateinit var adapter: BaseAdapter
    private lateinit var empty: TextView
    private lateinit var sheet: SheetLayer
    private lateinit var editor: LinearLayout
    private lateinit var editorTitle: TextView
    private lateinit var nameInput: EditText
    private lateinit var codeInput: EditText
    private var editingId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Scripts.init(this)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        sheet = SheetLayer(this)

        // ---- 顶栏 ----
        val back = iconButton(IconView.Kind.BACK) { finish() }
        val add = iconButton(IconView.Kind.PLUS) { showAddSheet() }
        val title = TextView(this).apply {
            text = "脚本"
            textSize = 17f
            typeface = Ui.MEDIUM
            setTextColor(Ui.TEXT)
        }
        val header = FrameLayout(this).apply {
            setBackgroundColor(Ui.CHROME)
            addView(back, FrameLayout.LayoutParams(-2, dp(52), Gravity.START or Gravity.CENTER_VERTICAL).apply { leftMargin = dp(4) })
            addView(title, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            addView(add, FrameLayout.LayoutParams(-2, dp(52), Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(4) })
        }

        // ---- 总开关 ----
        val masterSwitch = newSwitch().apply { isChecked = Scripts.enabledAll }
        masterSwitch.setOnCheckedChangeListener { _, on ->
            Scripts.enabledAll = on
            toast(if (on) "脚本已开启，刷新网页后生效" else "脚本已全部关闭")
        }
        val masterText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@ScriptsActivity).apply {
                text = "启用脚本"
                textSize = 15f
                setTextColor(Ui.TEXT)
            })
            addView(TextView(this@ScriptsActivity).apply {
                text = "关闭后所有网页都不运行脚本"
                textSize = 12f
                setTextColor(Ui.TEXT_SUB)
            }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(2) })
        }
        val master = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = roundRect(Ui.WHITE, dp(16).toFloat())
            setPadding(dp(16), dp(12), dp(16), dp(12))
            addView(masterText, LinearLayout.LayoutParams(0, -2, 1f))
            addView(masterSwitch, LinearLayout.LayoutParams(-2, -2))
        }

        // ---- 列表 ----
        adapter = object : BaseAdapter() {
            override fun getCount() = data.size
            override fun getItem(position: Int): Any = data[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val row = (convertView?.tag as? Row) ?: Row().also { it.root.tag = it }
                row.bind(data[position])
                return row.root
            }
        }
        val list = ListView(this).apply {
            divider = ColorDrawable(0x00000000)
            dividerHeight = 0
            setAdapter(this@ScriptsActivity.adapter)
            setOnItemClickListener { _, _, i, _ -> if (i < data.size) openEditor(data[i]) }
            setOnItemLongClickListener { _, _, i, _ -> if (i < data.size) showActions(data[i]); true }
        }
        empty = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 14f
            setTextColor(Ui.TEXT_SUB)
            setLineSpacing(0f, 1.25f)
            text = "还没有脚本\n点右上角「＋」导入脚本文件或粘贴脚本代码"
        }
        val body = FrameLayout(this).apply {
            background = roundRect(Ui.WHITE, dp(20).toFloat())
            clipToOutline = true
            addView(list, FrameLayout.LayoutParams(-1, -1))
            addView(empty, FrameLayout.LayoutParams(-1, -1))
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(header, LinearLayout.LayoutParams(-1, dp(52)))
            addView(master, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(4), dp(12), dp(8)) })
            addView(body, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(dp(12), 0, dp(12), dp(12)) })
        }

        editor = buildEditor()
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(Ui.CHROME)
            addView(page, FrameLayout.LayoutParams(-1, -1))
            addView(editor, FrameLayout.LayoutParams(-1, -1))
            addView(sheet.layer, FrameLayout.LayoutParams(-1, -1))
        })
        lightBars(Ui.CHROME)
        reload()
    }

    private fun newSwitch(): Switch = Switch(this).apply {
        val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        thumbTintList = ColorStateList(st, intArrayOf(Ui.WHITE, Ui.WHITE))
        trackTintList = ColorStateList(st, intArrayOf(Ui.PRIMARY, 0xFFCDD0DA.toInt()))
        isFocusable = false
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun reload() {
        data = Scripts.all()
        empty.visibility = if (data.isEmpty()) View.VISIBLE else View.GONE
        adapter.notifyDataSetChanged()
    }

    // ---------- 添加 / 导入 ----------

    private fun showAddSheet() {
        sheet.showActions("添加脚本", "支持 .user.js / .js 文件，或直接粘贴脚本代码", listOf(
            SheetLayer.Action(IconView.Kind.CODE, "粘贴代码 / 新建") { openEditor(null) },
            SheetLayer.Action(IconView.Kind.DOWNLOAD, "导入脚本文件") { pickFile() },
            SheetLayer.Action(IconView.Kind.LINK, "从剪贴板导入") { importClipboard() }
        ))
    }

    @Suppress("DEPRECATION")
    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        try {
            startActivityForResult(i, REQ_PICK)
        } catch (e: Exception) {
            toast("找不到可用的文件选择器")
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        data.clipData?.let { c -> for (i in 0 until c.itemCount) uris.add(c.getItemAt(i).uri) }
        if (uris.isEmpty()) data.data?.let { uris.add(it) }
        if (uris.isNotEmpty()) importUris(uris)
    }

    private class Loaded(val name: String, val code: String?, val error: String?)

    /** 文件在后台线程读，读完回到主线程再写入存储（Scripts 只在主线程访问）。 */
    private fun importUris(uris: List<Uri>) {
        Thread {
            val out = ArrayList<Loaded>()
            for (u in uris) {
                val name = displayName(u)
                try {
                    val bytes = readBytes(u)
                    when {
                        bytes == null -> out.add(Loaded(name, null, "文件过大"))
                        bytes.any { it == 0.toByte() } -> out.add(Loaded(name, null, "不是文本文件"))
                        else -> {
                            val text = String(bytes, Charsets.UTF_8)
                            if (text.isBlank()) out.add(Loaded(name, null, "文件是空的"))
                            else if (text.length > Scripts.MAX_CHARS) out.add(Loaded(name, null, "脚本过长"))
                            else out.add(Loaded(name, text, null))
                        }
                    }
                } catch (e: Exception) {
                    out.add(Loaded(name, null, "读取失败"))
                }
            }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                var ok = 0
                var updated = 0
                var firstErr: String? = null
                for (l in out) {
                    val code = l.code
                    if (code == null) {
                        if (firstErr == null) firstErr = "${l.name.ifBlank { "文件" }}：${l.error}"
                        continue
                    }
                    val label = l.name.replace(Regex("(\\.user)?\\.js\\z", RegexOption.IGNORE_CASE), "")
                    val r = Scripts.add(code, label)
                    ok++
                    if (r.second) updated++
                }
                reload()
                when {
                    ok == 0 -> toast("导入失败：${firstErr ?: "未知错误"}")
                    out.size == 1 -> toast(if (updated == 1) "已更新同名脚本" else "已导入脚本")
                    else -> toast("已导入 $ok 个脚本" + (if (updated > 0) "（其中 $updated 个为更新）" else "") +
                        (if (firstErr != null) "，有文件失败：$firstErr" else ""))
                }
            }
        }.start()
    }

    private fun readBytes(u: Uri): ByteArray? {
        contentResolver.openInputStream(u)?.use { ins ->
            val out = ByteArrayOutputStream()
            val buf = ByteArray(16 * 1024)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                out.write(buf, 0, n)
                if (out.size() > MAX_BYTES) return null
            }
            return out.toByteArray()
        }
        throw IllegalStateException("无法打开文件")
    }

    private fun displayName(u: Uri): String {
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: ""
            }
        } catch (e: Exception) {
        }
        return u.lastPathSegment ?: ""
    }

    private fun importClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        val text = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this).toString() else ""
        when {
            text.isBlank() -> toast("剪贴板里没有内容")
            text.length > Scripts.MAX_CHARS -> toast("脚本过长")
            Regex("https?://\\S+").matches(text.trim()) -> toast("剪贴板里是网址，不是脚本代码")
            else -> {
                val r = Scripts.add(text, "")
                reload()
                toast(if (r.second) "已更新同名脚本「${r.first.name}」" else "已导入「${r.first.name}」")
            }
        }
    }

    // ---------- 长按操作 ----------

    private fun showActions(s: Scripts.Script) {
        sheet.showActions(s.name, s.scopeText(), listOf(
            SheetLayer.Action(IconView.Kind.CODE, "编辑") { openEditor(s) },
            SheetLayer.Action(IconView.Kind.LINK, "复制代码") {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("script", s.code))
                toast("已复制代码")
            },
            SheetLayer.Action(IconView.Kind.TRASH, "删除", danger = true) {
                // 等操作面板收起的动画结束再弹确认框，避免同一个面板被连续复用
                sheet.layer.postDelayed({ confirmDelete(s) }, 280)
            }
        ))
    }

    private fun confirmDelete(s: Scripts.Script) {
        sheet.showConfirm("删除脚本", "「${s.name}」将被删除，此操作无法撤销。", "删除", true) {
            Scripts.remove(s.id)
            reload()
        }
    }

    // ---------- 编辑器 ----------

    private fun buildEditor(): LinearLayout {
        val cancel = TextView(this).apply {
            text = "取消"
            textSize = 15f
            setTextColor(Ui.TEXT_SUB)
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setOnClickListener { closeEditor() }
        }
        val save = TextView(this).apply {
            text = "保存"
            textSize = 15f
            typeface = Ui.MEDIUM
            setTextColor(Ui.PRIMARY)
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setOnClickListener { saveEditor() }
        }
        editorTitle = TextView(this).apply {
            textSize = 17f
            typeface = Ui.MEDIUM
            setTextColor(Ui.TEXT)
        }
        val header = FrameLayout(this).apply {
            addView(cancel, FrameLayout.LayoutParams(-2, -2, Gravity.START or Gravity.CENTER_VERTICAL))
            addView(editorTitle, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            addView(save, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL))
        }

        nameInput = EditText(this).apply {
            hint = "名称（可选；代码里有 @name 时以 @name 为准）"
            textSize = 14f
            setTextColor(Ui.TEXT)
            setHintTextColor(Ui.ICON_DIM)
            setSingleLine(true)
            background = null
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        val nameCard = FrameLayout(this).apply {
            background = roundRect(Ui.WHITE, dp(16).toFloat())
            addView(nameInput, FrameLayout.LayoutParams(-1, -2))
        }

        codeInput = EditText(this).apply {
            hint = "在这里粘贴脚本代码…\n\n可以带 ==UserScript== 头部（@name / @match / @include / @exclude / @run-at）；没有头部时在所有网页运行。"
            textSize = 12.5f
            typeface = Typeface.MONOSPACE
            setTextColor(Ui.TEXT)
            setHintTextColor(Ui.ICON_DIM)
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            background = null
            isVerticalScrollBarEnabled = true
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        val codeCard = FrameLayout(this).apply {
            background = roundRect(Ui.WHITE, dp(16).toFloat())
            clipToOutline = true
            addView(codeInput, FrameLayout.LayoutParams(-1, -1))
        }

        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.CHROME)
            isClickable = true      // 吃掉触摸，不让点击穿透到下面的列表
            visibility = View.GONE
            addView(header, LinearLayout.LayoutParams(-1, dp(52)))
            addView(nameCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(4), dp(12), dp(8)) })
            addView(codeCard, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(dp(12), 0, dp(12), dp(12)) })
        }
    }

    /** [s] 为空 = 新建；否则编辑这个脚本。 */
    private fun openEditor(s: Scripts.Script?) {
        if (s != null && s.code.length > MAX_EDIT_CHARS) {
            toast("脚本太大，不支持在应用内编辑；可用「导入脚本文件」覆盖更新")
            return
        }
        editingId = s?.id
        editorTitle.text = if (s == null) "新建脚本" else "编辑脚本"
        nameInput.setText(s?.label ?: "")
        codeInput.setText(s?.code ?: "")
        codeInput.setSelection(0)
        editor.visibility = View.VISIBLE
    }

    private fun closeEditor() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(editor.windowToken, 0)
        editor.visibility = View.GONE
        editingId = null
    }

    private fun saveEditor() {
        val code = codeInput.text.toString()
        if (code.isBlank()) {
            toast("脚本代码不能为空")
            return
        }
        if (code.length > Scripts.MAX_CHARS) {
            toast("脚本过长")
            return
        }
        val label = nameInput.text.toString().trim()
        val id = editingId
        if (id == null) {
            val r = Scripts.add(code, label)
            toast(if (r.second) "已更新同名脚本「${r.first.name}」" else "已添加「${r.first.name}」")
        } else {
            Scripts.update(id, code, label)
            toast("已保存，刷新网页后生效")
        }
        closeEditor()
        reload()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when {
            sheet.isShowing -> sheet.hide()
            editor.visibility == View.VISIBLE -> closeEditor()
            else -> super.onBackPressed()
        }
    }

    // ---------- 列表行 ----------

    private inner class Row {
        val ctx: Context = this@ScriptsActivity
        var cur: Scripts.Script? = null
        val letter = TextView(ctx).apply {
            gravity = Gravity.CENTER
            textSize = 15f
            setTextColor(Ui.WHITE)
            typeface = Ui.MEDIUM
        }
        val title = TextView(ctx).apply {
            textSize = 15f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val sub = TextView(ctx).apply {
            textSize = 12f
            setTextColor(Ui.TEXT_SUB)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val sw = newSwitch()
        val root = LinearLayout(ctx)

        init {
            val col = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                addView(title)
                addView(sub, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
            }
            root.orientation = LinearLayout.HORIZONTAL
            root.gravity = Gravity.CENTER_VERTICAL
            root.setPadding(dp(16), dp(10), dp(12), dp(10))
            root.addView(letter, LinearLayout.LayoutParams(dp(40), dp(40)))
            root.addView(col, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(14) })
            root.addView(sw, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
            sw.setOnCheckedChangeListener { _, on ->
                val s = cur
                if (s != null && s.enabled != on) {
                    Scripts.setEnabled(s.id, on)
                    style(s)
                }
            }
        }

        private fun style(s: Scripts.Script) {
            title.setTextColor(if (s.enabled) Ui.TEXT else Ui.TEXT_SUB)
            letter.alpha = if (s.enabled) 1f else 0.4f
        }

        fun bind(s: Scripts.Script) {
            cur = s
            title.text = s.name
            sub.text = listOfNotNull(
                s.meta.version.takeIf { it.isNotBlank() }?.let { "v$it" },
                s.scopeText()
            ).joinToString(" · ")
            letter.text = (s.name.firstOrNull { it.isLetterOrDigit() } ?: '#').uppercaseChar().toString()
            letter.background = ctx.badge(s.name, 13)
            sw.isChecked = s.enabled
            style(s)
        }
    }
}
