package com.example.searchhub

import android.app.DownloadManager
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.webkit.CookieManager
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.IOException
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 下载中心（进程内单例，与 Activity 生命周期无关）：
 * - 直链(mp4/mp3…)：交给系统 DownloadManager，进度靠 [refresh] 轮询；
 * - m3u8：用 [HlsDownloader] 在后台线程下载，经 MediaStore 写入「下载」目录。
 * 任务记录持久化在 SharedPreferences，重启应用后仍可在「下载」页查看、播放、删除、重试。
 */
object DownloadCenter {
    const val QUEUED = 0
    const val RUNNING = 1
    const val DONE = 2
    const val FAILED = 3

    class Task(
        val id: String,
        var title: String,
        val url: String,
        val kind: String,            // "dm" 系统下载 | "hls"
        val ua: String,
        val referer: String?,
        val createdAt: Long,
        val subDir: String = ""      // 「下载」目录下的子文件夹，空 = 直接放在下载目录
    ) {
        @Volatile var status = QUEUED
        @Volatile var bytes = 0L     // 已下载字节
        @Volatile var done = 0L      // hls：已完成分片数
        @Volatile var total = -1L    // dm：总字节(未知 -1)；hls：分片总数(未知 -1)
        @Volatile var fileUri: String? = null
        @Volatile var mime: String? = null
        @Volatile var error: String? = null
        @Volatile var dmId = -1L
        // 速度统计，仅界面线程使用
        var lastBytes = 0L
        var lastTime = 0L
        var speed = 0L

        /** 0..1；未知返回 -1。 */
        fun fraction(): Float = when {
            status == DONE -> 1f
            kind == "hls" -> if (total > 0) done.toFloat() / total else -1f
            else -> if (total > 0) bytes.toFloat() / total else -1f
        }
    }

    private val lock = Any()
    private val tasks = ArrayList<Task>()      // 新的在前
    private var inited = false
    private lateinit var app: Context
    private val main = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(2) { r -> Thread(r).apply { isDaemon = true } }
    private val cancels = ConcurrentHashMap<String, AtomicBoolean>()

    fun init(ctx: Context) {
        synchronized(lock) {
            if (inited) return
            inited = true
            app = ctx.applicationContext
            load()
        }
    }

    fun snapshot(): List<Task> = synchronized(lock) { ArrayList(tasks) }

    fun hlsActiveCount(): Int = synchronized(lock) { tasks.count { it.kind == "hls" && (it.status == QUEUED || it.status == RUNNING) } }

    fun activeCount(): Int = synchronized(lock) { tasks.count { it.status == QUEUED || it.status == RUNNING } }

    // ---------- 新建任务 ----------

    fun startDirect(url: String, title: String, ua: String, referer: String?, subDir: String = ""): Task {
        val t = Task(UUID.randomUUID().toString(), uniqueTitle(title), url, "dm", ua, referer, System.currentTimeMillis(), subDir)
        add(t)
        enqueueDm(t)
        save()
        return t
    }

    fun startHls(url: String, title: String, ua: String, referer: String?, subDir: String = ""): Task {
        val t = Task(UUID.randomUUID().toString(), title, url, "hls", ua, referer, System.currentTimeMillis(), subDir)
        add(t)
        runHls(t)
        save()
        return t
    }

    // ---------- 操作 ----------

    fun cancel(t: Task) {
        if (t.status != QUEUED && t.status != RUNNING) return
        if (t.kind == "hls") {
            cancels[t.id]?.set(true)   // 工作线程会清理半成品并把状态置为“已取消”
        } else {
            removeDm(t.dmId)
            t.status = FAILED
            t.error = "已取消"
            save()
        }
    }

    fun retry(t: Task) {
        if (t.status != FAILED) return
        val fileExists = t.error?.contains("已存在") == true
        t.error = null
        t.bytes = 0
        t.done = 0
        t.total = -1
        t.fileUri = null
        t.speed = 0
        if (t.kind == "hls") {
            runHls(t)
        } else {
            if (fileExists) t.title = withSuffix(t.title)
            enqueueDm(t)
        }
        save()
    }

    /** 移除任务记录；deleteFile 为 true 时同时删除已下载的文件。 */
    fun remove(t: Task, deleteFile: Boolean) {
        if (t.status == QUEUED || t.status == RUNNING) cancel(t)
        if (deleteFile) {
            if (t.kind == "dm") removeDm(t.dmId)
            else t.fileUri?.let { runCatching { app.contentResolver.delete(Uri.parse(it), null, null) } }
        }
        synchronized(lock) { tasks.remove(t) }
        save()
    }

    fun clearFinished() {
        synchronized(lock) { tasks.removeAll { it.status == DONE || it.status == FAILED } }
        save()
    }

    fun exists(uri: Uri): Boolean = try {
        app.contentResolver.openFileDescriptor(uri, "r")?.close()
        true
    } catch (e: Exception) {
        false
    }

    /** 由界面定时调用：刷新系统下载任务的进度与结果。 */
    fun refresh() {
        val running = synchronized(lock) { tasks.filter { it.kind == "dm" && (it.status == RUNNING || it.status == QUEUED) } }
        if (running.isEmpty()) return
        val dm = app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        var changed = false
        for (t in running) {
            val c: Cursor? = try { dm.query(DownloadManager.Query().setFilterById(t.dmId)) } catch (e: Exception) { null }
            if (c == null) continue
            try {
                if (!c.moveToFirst()) {
                    t.status = FAILED
                    t.error = "任务已被移除"
                    changed = true
                    continue
                }
                val st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val soFar = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val size = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                when (st) {
                    DownloadManager.STATUS_SUCCESSFUL -> {
                        t.bytes = if (size > 0) size else soFar
                        t.total = t.bytes
                        t.fileUri = dm.getUriForDownloadedFile(t.dmId)?.toString()
                        t.mime = dm.getMimeTypeForDownloadedFile(t.dmId)
                        t.status = DONE
                        changed = true
                        toast("下载完成：${t.title}")
                    }
                    DownloadManager.STATUS_FAILED -> {
                        val reason = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                        t.error = reasonText(reason)
                        t.status = FAILED
                        changed = true
                        toast("下载失败：${t.title}")
                    }
                    else -> {
                        t.bytes = soFar
                        t.total = if (size > 0) size else -1
                        t.status = RUNNING
                    }
                }
            } finally {
                c.close()
            }
        }
        if (changed) save()
    }

    // ---------- 直链：系统 DownloadManager ----------

    private fun enqueueDm(t: Task) {
        try {
            val req = DownloadManager.Request(Uri.parse(t.url))
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, if (t.subDir.isEmpty()) t.title else "${t.subDir}/${t.title}")
                .addRequestHeader("User-Agent", t.ua)
            t.referer?.let { req.addRequestHeader("Referer", it) }
            cookieFor(t.url)?.let { req.addRequestHeader("Cookie", it) }
            t.dmId = (app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            t.status = RUNNING
        } catch (e: Exception) {
            t.status = FAILED
            t.error = e.message ?: "无法创建下载任务"
        }
    }

    private fun removeDm(id: Long) {
        if (id < 0) return
        try {
            (app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(id)
        } catch (e: Exception) {
            // 忽略
        }
    }

    private fun reasonText(reason: Int): String = when {
        reason in 400..599 -> "HTTP $reason（链接可能已失效或需要登录）"
        reason == DownloadManager.ERROR_FILE_ALREADY_EXISTS -> "文件已存在（重试会自动改名）"
        reason == DownloadManager.ERROR_INSUFFICIENT_SPACE -> "存储空间不足"
        reason == DownloadManager.ERROR_DEVICE_NOT_FOUND -> "找不到存储设备"
        reason == DownloadManager.ERROR_TOO_MANY_REDIRECTS -> "重定向次数过多"
        reason == DownloadManager.ERROR_HTTP_DATA_ERROR -> "网络数据错误"
        reason == DownloadManager.ERROR_CANNOT_RESUME -> "无法继续下载"
        reason == DownloadManager.ERROR_FILE_ERROR -> "文件写入错误"
        else -> "下载出错（$reason）"
    }

    // ---------- m3u8：自带下载器 ----------

    private class Counting(private val out: OutputStream, private val t: Task) : OutputStream() {
        override fun write(b: Int) { out.write(b); t.bytes += 1 }
        override fun write(b: ByteArray, off: Int, len: Int) { out.write(b, off, len); t.bytes += len }
        override fun flush() = out.flush()
        override fun close() = out.close()
    }

    private fun runHls(t: Task) {
        val cancel = AtomicBoolean(false)
        cancels[t.id] = cancel
        t.status = QUEUED
        DownloadService.sync(app)
        pool.execute {
            var created: Uri? = null
            try {
                if (cancel.get()) throw HlsDownloader.Cancelled()
                t.status = RUNNING
                val dl = HlsDownloader { u -> headersFor(u, t.ua, t.referer) }
                val pl = dl.load(t.url)
                if (pl.live) toast("疑似直播流，只会下载当前列表里的片段")
                val resolver = app.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, "${t.title}.${pl.ext}")
                    put(MediaStore.Downloads.MIME_TYPE, pl.mime)
                    put(MediaStore.Downloads.RELATIVE_PATH,
                        if (t.subDir.isEmpty()) Environment.DIRECTORY_DOWNLOADS else "${Environment.DIRECTORY_DOWNLOADS}/${t.subDir}")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IOException("无法在「下载」目录创建文件")
                created = uri
                t.fileUri = uri.toString()   // 先记下，进程被杀后下次启动可清理半成品
                t.mime = pl.mime
                // MediaStore 遇到重名会自动改名，这里读回真实文件名
                runCatching {
                    resolver.query(uri, arrayOf(MediaStore.Downloads.DISPLAY_NAME), null, null, null)?.use { c ->
                        if (c.moveToFirst()) t.title = c.getString(0)
                    }
                }
                t.total = pl.segments.size.toLong()
                val raw = resolver.openOutputStream(uri) ?: throw IOException("无法写入文件")
                Counting(BufferedOutputStream(raw, 64 * 1024), t).use { out ->
                    dl.writeTo(pl, out, { done, _ -> t.done = done.toLong() }, { cancel.get() })
                }
                resolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
                t.done = t.total
                t.status = DONE
                toast("下载完成：${t.title}")
            } catch (e: Throwable) {
                created?.let { runCatching { app.contentResolver.delete(it, null, null) } }
                t.fileUri = null
                t.status = FAILED
                val cancelled = e is HlsDownloader.Cancelled
                t.error = if (cancelled) "已取消" else (e.message ?: e.javaClass.simpleName)
                if (!cancelled) toast("下载失败：${t.title}")
            } finally {
                cancels.remove(t.id)
                save()
                DownloadService.sync(app)
            }
        }
    }

    // ---------- 工具 ----------

    private fun add(t: Task) {
        synchronized(lock) { tasks.add(0, t) }
    }

    private fun cookieFor(url: String): String? =
        runCatching { CookieManager.getInstance().getCookie(url) }.getOrNull()

    fun headersFor(u: String, ua: String, referer: String?): Map<String, String> {
        val h = HashMap<String, String>()
        h["User-Agent"] = ua
        if (referer != null) h["Referer"] = referer
        cookieFor(u)?.let { h["Cookie"] = it }
        return h
    }

    private fun uniqueTitle(title: String): String {
        val used = synchronized(lock) { tasks.map { it.title }.toSet() }
        if (title !in used) return title
        val dot = title.lastIndexOf('.')
        val base = if (dot > 0) title.substring(0, dot) else title
        val ext = if (dot > 0) title.substring(dot) else ""
        var n = 2
        while ("$base ($n)$ext" in used) n++
        return "$base ($n)$ext"
    }

    private fun withSuffix(title: String): String {
        val dot = title.lastIndexOf('.')
        val base = if (dot > 0) title.substring(0, dot) else title
        val ext = if (dot > 0) title.substring(dot) else ""
        return "${base}_${System.currentTimeMillis() % 100000}$ext"
    }

    private fun toast(s: String) {
        main.post { Toast.makeText(app, s, Toast.LENGTH_SHORT).show() }
    }

    // ---------- 持久化 ----------

    private fun prefs() = app.getSharedPreferences("downloads", Context.MODE_PRIVATE)

    private fun save() {
        val arr = JSONArray()
        synchronized(lock) {
            for (t in tasks.take(200)) {
                val o = JSONObject()
                o.put("id", t.id)
                o.put("title", t.title)
                o.put("url", t.url)
                o.put("kind", t.kind)
                o.put("ua", t.ua)
                o.put("referer", t.referer ?: "")
                o.put("createdAt", t.createdAt)
                o.put("status", t.status)
                o.put("bytes", t.bytes)
                o.put("done", t.done)
                o.put("total", t.total)
                o.put("fileUri", t.fileUri ?: "")
                o.put("mime", t.mime ?: "")
                o.put("error", t.error ?: "")
                o.put("dmId", t.dmId)
                o.put("subDir", t.subDir)
                arr.put(o)
            }
        }
        prefs().edit().putString("tasks", arr.toString()).apply()
    }

    private fun load() {
        val s = prefs().getString("tasks", null) ?: return
        try {
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val t = Task(
                    o.getString("id"), o.getString("title"), o.getString("url"), o.getString("kind"),
                    o.optString("ua"), o.optString("referer").ifEmpty { null }, o.optLong("createdAt"),
                    o.optString("subDir")
                )
                t.status = o.optInt("status")
                t.bytes = o.optLong("bytes")
                t.done = o.optLong("done")
                t.total = o.optLong("total", -1L)
                t.fileUri = o.optString("fileUri").ifEmpty { null }
                t.mime = o.optString("mime").ifEmpty { null }
                t.error = o.optString("error").ifEmpty { null }
                t.dmId = o.optLong("dmId", -1L)
                if (t.kind == "hls" && (t.status == QUEUED || t.status == RUNNING)) {
                    // 上次进程在下载途中被结束：清理半成品，标记为失败，可重试
                    t.fileUri?.let { runCatching { app.contentResolver.delete(Uri.parse(it), null, null) } }
                    t.fileUri = null
                    t.status = FAILED
                    t.error = "已中断（应用被关闭），可重试"
                }
                tasks.add(t)
            }
        } catch (e: Exception) {
            // 记录损坏则忽略
        }
    }
}
