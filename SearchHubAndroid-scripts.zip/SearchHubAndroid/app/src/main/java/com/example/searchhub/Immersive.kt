package com.example.searchhub

import android.app.Activity
import android.os.Build
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager

/** 进入 / 退出沉浸式全屏：隐藏状态栏和导航栏（滑动屏幕边缘可临时唤出），刘海屏横屏时画面延伸到刘海区域。 */
@Suppress("DEPRECATION")
fun Activity.setImmersive(on: Boolean) {
    val cutout = if (on) WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
    else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
    if (window.attributes.layoutInDisplayCutoutMode != cutout) {
        window.attributes = window.attributes.also { it.layoutInDisplayCutoutMode = cutout }
    }
    if (Build.VERSION.SDK_INT >= 30) {
        window.setDecorFitsSystemWindows(!on)
        // decorView 还没挂到窗口上时 insetsController 为 null，之后 onWindowFocusChanged 再调用一次即可
        window.insetsController?.let {
            if (on) {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            } else {
                it.show(WindowInsets.Type.systemBars())
            }
        }
    } else {
        window.decorView.systemUiVisibility = if (on) {
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        } else {
            View.SYSTEM_UI_FLAG_VISIBLE
        }
    }
}
