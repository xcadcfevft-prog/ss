package com.example.searchhub

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * 全屏播放嗅探到的媒体：基于 Media3 ExoPlayer，界面和手势全部用代码构建（不依赖 media3-ui 的布局资源）。
 *
 * - 格式：mp4 / mkv / webm / flv / ts / mp3 / HLS(m3u8) / DASH(mpd)，自动带上网页的 UA / Referer / Cookie 通过防盗链
 * - 手势：单击呼出控制条、双击左 / 右快退 / 快进 10 秒、双击中间暂停、水平滑动调进度、
 *         左半屏竖滑调亮度、右半屏竖滑调音量、长按 2 倍速（松手恢复）
 * - 控制条：进度 + 缓冲、倍速、画面比例（适应 / 拉伸 / 裁剪 / 16:9 / 4:3）、旋转、锁屏、转外部播放器
 * - 容错：无后缀的 URL 解析失败时自动按 HLS 重试；直播窗口落后自动跳回；失败可重试 / 转外部播放器
 */
@OptIn(UnstableApi::class)
@SuppressLint("ClickableViewAccessibility")
class PlayerActivity : Activity() {

    private enum class Fit(val label: String, val ratio: Float?) {
        FIT("适应屏幕", null),
        FILL("拉伸铺满", null),
        CROP("裁剪铺满", null),
        R16_9("16:9", 16f / 9f),
        R4_3("4:3", 4f / 3f)
    }

    // ---- 播放状态 ----
    private var player: ExoPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var url = ""
    private var mimeOverride: String? = null
    private var triedHls = false
    private var resumePos = C.TIME_UNSET
    private var resumePlay = true
    private var wasPlaying = false
    private var speed = 1f
    private var fit = Fit.FIT
    private var vw = 0
    private var vh = 0
    private var vRatio = 1f
    private var orientationSet = false

    // ---- 清晰度：自动 / 最高（默认）/ 指定某一档 ----
    private var qMode = Q_HIGHEST
    private var qHeight = 0
    private var qBitrate = 0

    // ---- 界面状态 ----
    private var locked = false
    private var controlsShown = true
    private var dragging = false
    private var menuVisible = false
    private var errorDialog: AlertDialog? = null

    // ---- 手势状态 ----
    private var gMode = G_NONE
    private var seekStart = 0L
    private var seekTarget = 0L
    private var curVol = 0f
    private var curBright = 0.5f
    private var longSpeed = false
    private val audio by lazy { getSystemService(AUDIO_SERVICE) as AudioManager }

    // ---- Views ----
    private lateinit var root: FrameLayout
    private lateinit var surface: SurfaceView
    private lateinit var loading: ProgressBar
    private lateinit var hud: TextView
    private lateinit var controls: FrameLayout
    private lateinit var topBar: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var titleTv: TextView
    private lateinit var curTv: TextView
    private lateinit var durTv: TextView
    private lateinit var seek: SeekBar
    private lateinit var playBtn: PlayerIconView
    private lateinit var speedTv: TextView
    private lateinit var qualityTv: TextView
    private lateinit var fitTv: TextView
    private lateinit var lockBtn: PlayerIconView
    private lateinit var menuPanel: ScrollView
    private lateinit var menuList: LinearLayout
    private lateinit var gd: GestureDetector

    private val hideRunnable = Runnable { hideControls() }
    private val hudHide = Runnable { hud.visibility = View.GONE }
    private val ticker = object : Runnable {
        override fun run() {
            if (controlsShown && !locked && !dragging) updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            loading.visibility = if (state == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
            if (state == Player.STATE_ENDED) {
                handler.removeCallbacks(hideRunnable)
                showControls()
            }
            refreshPlayIcon()
            updateProgress()
        }

        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) = refreshPlayIcon()

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            refreshPlayIcon()
            scheduleHide()
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            vw = videoSize.width
            vh = videoSize.height
            vRatio = if (videoSize.pixelWidthHeightRatio > 0f) videoSize.pixelWidthHeightRatio else 1f
            applyResize()
            if (!orientationSet && vw > 0 && vh > 0) {
                orientationSet = true
                requestedOrientation = if (vh > vw) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            }
        }

        override fun onTracksChanged(tracks: Tracks) {
            val list = videoTracks()
            qualityTv.visibility = if (list.size > 1) View.VISIBLE else View.GONE
            if (qMode == Q_FIXED) {
                // 指定档位：轨道信息出来后（或重新起播后）把选择落实到播放器
                val t = list.firstOrNull { it.format.height == qHeight && it.format.bitrate == qBitrate }
                if (t != null && !t.group.isTrackSelected(t.index)) applyQuality()
            }
            refreshQualityLabel(list)
        }

        override fun onPlayerError(error: PlaybackException) = handleError(error)
    }

    // =====================================================================
    // 生命周期
    // =====================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        url = intent.getStringExtra(EXTRA_URL) ?: run { finish(); return }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        volumeControlStream = AudioManager.STREAM_MUSIC
        buildUi()
        setContentView(root)
    }

    override fun onStart() {
        super.onStart()
        if (url.isNotEmpty()) initPlayer()
    }

    override fun onResume() {
        super.onResume()
        setImmersive(true)
        if (wasPlaying) player?.play()
    }

    override fun onPause() {
        super.onPause()
        val p = player ?: return
        wasPlaying = p.playWhenReady && p.playbackState != Player.STATE_ENDED
        p.pause()
    }

    override fun onStop() {
        super.onStop()
        releasePlayer()
    }

    override fun onDestroy() {
        super.onDestroy()
        errorDialog?.dismiss()
        handler.removeCallbacksAndMessages(null)
        releasePlayer()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) setImmersive(true)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when {
            menuVisible -> hideMenu()
            locked -> { showControls(); showHud("已锁定，点左侧锁图标解锁") }
            else -> super.onBackPressed()
        }
    }

    // =====================================================================
    // 播放器
    // =====================================================================

    private fun initPlayer() {
        if (player != null) return

        val headers = HashMap<String, String>()
        intent.getStringExtra(EXTRA_REFERER)?.let { headers["Referer"] = it }
        intent.getStringExtra(EXTRA_COOKIE)?.let { headers["Cookie"] = it }
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true) // http <-> https 跳转
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)
            .setDefaultRequestProperties(headers)
        intent.getStringExtra(EXTRA_UA)?.let { http.setUserAgent(it) }

        val extractors = DefaultExtractorsFactory().setConstantBitrateSeekingEnabled(true)
        val sourceFactory = DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http), extractors)
        val renderers = DefaultRenderersFactory(this).setEnableDecoderFallback(true)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 50_000, 1_000, 2_500) // 更快起播
            .build()

        val p = ExoPlayer.Builder(this, renderers)
            .setMediaSourceFactory(sourceFactory)
            .setLoadControl(loadControl)
            .build()
        p.setVideoSurfaceView(surface)
        p.setPlaybackSpeed(speed)
        p.addListener(listener)
        player = p
        applyQuality() // 起播前就设成「最高画质」，避免先低清后切换

        loading.visibility = View.VISIBLE
        loadMedia(p)
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    private fun loadMedia(p: ExoPlayer) {
        val item = MediaItem.Builder().setUri(url).apply {
            (mimeOverride ?: mimeHint(url))?.let { setMimeType(it) }
        }.build()
        p.setMediaItem(item, resumePos)
        p.playWhenReady = resumePlay
        p.prepare()
    }

    private fun releasePlayer() {
        handler.removeCallbacks(ticker)
        val p = player ?: return
        resumePos = if (p.playbackState == Player.STATE_ENDED) C.TIME_UNSET else p.currentPosition
        resumePlay = wasPlaying
        p.removeListener(listener)
        p.release()
        player = null
    }

    /** 按 URL 里的后缀给 ExoPlayer 一个格式提示；没有后缀的交给它自己嗅探。 */
    private fun mimeHint(u: String): String? {
        val l = u.lowercase(Locale.ROOT)
        return when {
            l.contains(".m3u8") -> MimeTypes.APPLICATION_M3U8
            l.contains(".mpd") -> MimeTypes.APPLICATION_MPD
            else -> null
        }
    }

    private fun handleError(e: PlaybackException) {
        val p = player ?: return
        loading.visibility = View.GONE
        when (e.errorCode) {
            PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW -> {
                p.seekToDefaultPosition()
                p.prepare()
                return
            }
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED -> {
                // 嗅探到的链接常常没有 .m3u8 后缀：认不出容器时，按 HLS 再试一次
                if (!triedHls && mimeOverride == null && mimeHint(url) == null) {
                    triedHls = true
                    mimeOverride = MimeTypes.APPLICATION_M3U8
                    resumePos = C.TIME_UNSET
                    resumePlay = true
                    loading.visibility = View.VISIBLE
                    loadMedia(p)
                    return
                }
            }
        }
        showError(e)
    }

    private fun showError(e: PlaybackException) {
        if (isFinishing || isDestroyed) return
        errorDialog?.dismiss()
        val cause = e.cause
        val detail = if (cause is HttpDataSource.InvalidResponseCodeException) "HTTP ${cause.responseCode}" else e.errorCodeName
        val hint = when {
            cause is HttpDataSource.InvalidResponseCodeException &&
                (cause.responseCode == 401 || cause.responseCode == 403) -> "链接需要登录、已过期，或被网站的防盗链拦截。"
            else -> when (e.errorCode) {
                PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
                PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT -> "网络连接失败，请检查网络后重试。"
                PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
                PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
                PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED,
                PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED -> "格式不支持，或文件已损坏。"
                else -> "资源可能已失效，或格式不受支持。"
            }
        }
        errorDialog = AlertDialog.Builder(this)
            .setTitle("无法播放")
            .setMessage("$hint\n\n($detail)")
            .setPositiveButton("重试") { _, _ ->
                loading.visibility = View.VISIBLE
                player?.prepare()
                player?.play()
            }
            .setNeutralButton("外部播放器") { _, _ -> openExternal() }
            .setNegativeButton("关闭") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    /** 「外部播放」：弹出底部面板，列出已安装的外部播放器（带图标）+「更多…」，点选后把链接交给它。 */
    private fun openExternal() {
        player?.pause()
        val path = (Uri.parse(url).path ?: "").lowercase(Locale.ROOT)
        val hls = path.endsWith(".m3u8")
        val apps = ExternalApps.players(this, url, false, hls)
        val ua = intent.getStringExtra(EXTRA_UA)
        val referer = intent.getStringExtra(EXTRA_REFERER)
        val cookie = intent.getStringExtra(EXTRA_COOKIE)
        val title = titleOf(url)

        class Tile(val label: String, val icon: View, val onClick: () -> Unit)
        lateinit var dialog: AlertDialog
        val tiles = ArrayList<Tile>()
        for (app in apps) {
            tiles.add(Tile(app.label, android.widget.ImageView(this).apply {
                setImageDrawable(app.icon)
                scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            }) {
                if (ExternalApps.launchPlayer(this, app, url, title, ua, referer, cookie)) { dialog.dismiss(); finish() }
            })
        }
        tiles.add(Tile("更多…", TextView(this).apply {
            text = "…"
            textSize = 22f
            setTextColor(0xFF6B7080.toInt())
            gravity = Gravity.CENTER
            background = rounded(0xFFE9EBF0.toInt(), 12)
        }) {
            if (ExternalApps.chooseAnyPlayer(this, url, false, title, ua, referer, cookie)) { dialog.dismiss(); finish() }
        })

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(12))
        }
        val cols = 4
        var i = 0
        while (i < tiles.size) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until cols) {
                val t = tiles.getOrNull(i + c)
                val cell: View = if (t == null) View(this) else LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                    setPadding(dp(2), dp(6), dp(2), dp(6))
                    addView(t.icon, LinearLayout.LayoutParams(dp(44), dp(44)))
                    addView(TextView(this@PlayerActivity).apply {
                        text = t.label
                        textSize = 11f
                        setTextColor(0xFF222222.toInt())
                        gravity = Gravity.CENTER
                        maxLines = 2
                        ellipsize = TextUtils.TruncateAt.END
                    }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
                    setOnClickListener { t.onClick() }
                }
                row.addView(cell, LinearLayout.LayoutParams(0, -2, 1f))
            }
            body.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = if (i > 0) dp(8) else 0 })
            i += cols
        }
        val scroll = ScrollView(this).apply { addView(body) }
        dialog = AlertDialog.Builder(this)
            .setTitle("外部播放")
            .setView(scroll)
            .setNegativeButton("取消") { _, _ -> player?.play() }
            .setOnCancelListener { player?.play() }
            .show()
    }

    // =====================================================================
    // 播放控制
    // =====================================================================

    private fun togglePlay() {
        val p = player ?: return
        when {
            p.playbackState == Player.STATE_ENDED -> { p.seekTo(0); p.play() }
            p.playbackState == Player.STATE_IDLE -> { p.prepare(); p.play() }
            p.playWhenReady -> p.pause()
            else -> p.play()
        }
    }

    private fun seekBy(delta: Long, hint: String) {
        val p = player ?: return
        if (!p.isCurrentMediaItemSeekable) return
        val d = durationMs()
        val t = p.currentPosition + delta
        p.seekTo(if (d > 0) t.coerceIn(0L, d) else max(0L, t))
        showHud(hint)
    }

    private fun setSpeed(s: Float) {
        speed = s
        player?.setPlaybackSpeed(s)
        speedTv.text = if (s == 1f) "倍速" else "${s}x"
    }

    private fun toggleOrientation() {
        val portrait = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
        requestedOrientation = if (portrait) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        orientationSet = true
    }

    private fun durationMs(): Long {
        val p = player ?: return 0L
        val d = p.duration
        return if (d == C.TIME_UNSET || p.isCurrentMediaItemLive) 0L else d
    }

    private fun refreshPlayIcon() {
        val p = player ?: return
        playBtn.kind = if (p.playWhenReady && p.playbackState != Player.STATE_ENDED) PlayerIconView.PAUSE else PlayerIconView.PLAY
    }

    private fun updateProgress() {
        val p = player ?: return
        val d = durationMs()
        if (d > 0) {
            seek.isEnabled = true
            durTv.text = fmt(d)
            if (!dragging) {
                val pos = p.currentPosition.coerceIn(0L, d)
                curTv.text = fmt(pos)
                seek.progress = (pos * 1000 / d).toInt()
            }
            seek.secondaryProgress = (p.bufferedPosition.coerceIn(0L, d) * 1000 / d).toInt()
        } else {
            seek.isEnabled = false
            seek.progress = 0
            seek.secondaryProgress = 0
            curTv.text = fmt(p.currentPosition)
            durTv.text = if (p.isCurrentMediaItemLive) "直播" else "--:--"
        }
    }

    private fun fmt(ms: Long): String {
        val s = max(0L, ms) / 1000
        val h = s / 3600
        val m = s % 3600 / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%02d:%02d", m, sec)
    }

    /** 按画面比例设置 SurfaceView 的大小（超出屏幕的部分会被裁掉）。 */
    private fun applyResize() {
        val cw = root.width
        val ch = root.height
        if (vw <= 0 || vh <= 0 || cw <= 0 || ch <= 0) return
        val ar = fit.ratio ?: (vw * vRatio / vh)
        val boxAr = cw.toFloat() / ch
        var w = cw
        var h = ch
        when (fit) {
            Fit.FILL -> Unit
            Fit.CROP -> if (boxAr > ar) h = (cw / ar).toInt() else w = (ch * ar).toInt()
            else -> if (boxAr > ar) w = (ch * ar).toInt() else h = (cw / ar).toInt()
        }
        val lp = surface.layoutParams as FrameLayout.LayoutParams
        if (lp.width != w || lp.height != h) {
            lp.width = w
            lp.height = h
            surface.layoutParams = lp
        }
    }

    // =====================================================================
    // 控制条显隐 / 锁屏 / 菜单 / 提示
    // =====================================================================

    private fun showControls() {
        controlsShown = true
        if (!locked) {
            fadeView(controls, true)
            updateProgress()
        }
        fadeView(lockBtn, true)
        scheduleHide()
    }

    private fun hideControls() {
        controlsShown = false
        handler.removeCallbacks(hideRunnable)
        fadeView(controls, false)
        fadeView(lockBtn, false)
    }

    private fun toggleControls() = if (controlsShown) hideControls() else showControls()

    private fun scheduleHide() {
        handler.removeCallbacks(hideRunnable)
        if (menuVisible || dragging) return
        if (locked || player?.isPlaying == true) handler.postDelayed(hideRunnable, 4000)
    }

    private fun setLocked(v: Boolean) {
        locked = v
        lockBtn.kind = if (v) PlayerIconView.LOCK else PlayerIconView.UNLOCK
        fadeView(controls, !v)
        controlsShown = true
        showHud(if (v) "已锁定" else "已解锁")
        scheduleHide()
    }

    private fun fadeView(v: View, show: Boolean) {
        v.animate().cancel()
        if (show) {
            v.visibility = View.VISIBLE
            v.animate().alpha(1f).setDuration(150).start()
        } else {
            v.animate().alpha(0f).setDuration(150).withEndAction { v.visibility = View.GONE }.start()
        }
    }

    private fun showHud(text: String, ms: Long = 800) {
        hud.text = text
        hud.visibility = View.VISIBLE
        handler.removeCallbacks(hudHide)
        if (ms > 0) handler.postDelayed(hudHide, ms)
    }

    // ---------- 清晰度 ----------

    /** 当前流里所有可解码的视频档位，按分辨率 / 码率从高到低排。 */
    private fun videoTracks(): List<QTrack> {
        val p = player ?: return emptyList()
        val out = ArrayList<QTrack>()
        for (g in p.currentTracks.groups) {
            if (g.type != C.TRACK_TYPE_VIDEO) continue
            for (i in 0 until g.length) {
                if (g.isTrackSupported(i)) out.add(QTrack(g, i, g.getTrackFormat(i)))
            }
        }
        out.sortWith(compareByDescending<QTrack> { it.format.height }.thenByDescending { it.format.bitrate })
        return out
    }

    private fun qLabel(f: Format): String {
        val res = when {
            f.height > 0 -> "${f.height}p"
            f.width > 0 -> "${f.width}w"
            else -> "未知"
        }
        val br = if (f.bitrate > 0) String.format(Locale.US, " · %.1f Mbps", f.bitrate / 1_000_000f) else ""
        return res + br
    }

    /** 把 qMode 落实到播放器：自动 = 自适应；最高 = 强制最高码率（不受屏幕尺寸限制）；指定 = 固定某一档。 */
    private fun applyQuality() {
        val p = player ?: return
        val b = p.trackSelectionParameters.buildUpon()
            .setViewportSize(Int.MAX_VALUE, Int.MAX_VALUE, false)
            .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
            .setForceHighestSupportedBitrate(qMode != Q_AUTO) // 指定档位时作为兜底，档位找不到就回到最高
        if (qMode == Q_FIXED) {
            val t = videoTracks().firstOrNull { it.format.height == qHeight && it.format.bitrate == qBitrate }
            if (t != null) b.addOverride(TrackSelectionOverride(t.group.mediaTrackGroup, t.index))
        }
        p.trackSelectionParameters = b.build()
    }

    private fun refreshQualityLabel(list: List<QTrack>) {
        val sel = list.firstOrNull { it.group.isTrackSelected(it.index) }
        qualityTv.text = when {
            qMode == Q_AUTO -> "自动"
            sel != null && sel.format.height > 0 -> "${sel.format.height}p"
            else -> "画质"
        }
    }

    private fun showQualityMenu() {
        val list = videoTracks()
        if (list.size <= 1) return
        val labels = ArrayList<String>()
        labels.add("自动（自适应）")
        list.forEachIndexed { i, t -> labels.add(qLabel(t.format) + if (i == 0) "（最高）" else "") }
        val checked = when (qMode) {
            Q_AUTO -> 0
            Q_HIGHEST -> 1
            else -> 1 + max(0, list.indexOfFirst { it.format.height == qHeight && it.format.bitrate == qBitrate })
        }
        showMenu("清晰度", labels, checked) { i ->
            when {
                i == 0 -> qMode = Q_AUTO
                i == 1 -> qMode = Q_HIGHEST
                else -> {
                    val t = list[i - 1]
                    qMode = Q_FIXED
                    qHeight = t.format.height
                    qBitrate = t.format.bitrate
                }
            }
            applyQuality()
            refreshQualityLabel(videoTracks())
            showHud("清晰度：" + labels[i].substringBefore("（"))
        }
    }

    private val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f)

    private fun showSpeedMenu() {
        val labels = speeds.map { if (it == 1f) "1.0x（正常）" else "${it}x" }
        showMenu("播放速度", labels, speeds.indexOfFirst { it == speed }) { i -> setSpeed(speeds[i]) }
    }

    private fun showFitMenu() {
        showMenu("画面比例", Fit.values().map { it.label }, fit.ordinal) { i ->
            fit = Fit.values()[i]
            fitTv.text = fit.label
            applyResize()
        }
    }

    private fun showMenu(title: String, items: List<String>, checked: Int, onPick: (Int) -> Unit) {
        menuList.removeAllViews()
        menuList.addView(TextView(this).apply {
            text = title
            setTextColor(0x99FFFFFF.toInt())
            textSize = 13f
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), 0, dp(20), 0)
        }, LinearLayout.LayoutParams(-1, dp(40)))
        items.forEachIndexed { i, label ->
            menuList.addView(TextView(this).apply {
                text = label
                setTextColor(if (i == checked) ACCENT else Color.WHITE)
                textSize = 16f
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(20), 0, dp(20), 0)
                setOnClickListener { onPick(i); hideMenu() }
            }, LinearLayout.LayoutParams(-1, dp(46)))
        }
        menuPanel.visibility = View.VISIBLE
        menuVisible = true
        hideControls()
    }

    private fun hideMenu() {
        menuPanel.visibility = View.GONE
        menuVisible = false
    }

    // =====================================================================
    // 手势
    // =====================================================================

    private fun currentBrightness(): Float {
        val b = window.attributes.screenBrightness
        if (b >= 0f) return b
        return try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (e: Exception) {
            0.5f
        }
    }

    private fun endGesture() {
        val active = gMode != G_NONE || longSpeed
        if (gMode == G_SEEK) player?.seekTo(seekTarget)
        if (longSpeed) {
            longSpeed = false
            player?.setPlaybackSpeed(speed)
        }
        gMode = G_NONE
        if (active) {
            handler.removeCallbacks(hudHide)
            handler.postDelayed(hudHide, 500)
        }
    }

    private fun buildGestures() {
        gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                toggleControls()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                val x = e.x / root.width
                when {
                    x < 0.33f -> seekBy(-10_000L, "快退 10 秒")
                    x > 0.67f -> seekBy(10_000L, "快进 10 秒")
                    else -> togglePlay()
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (locked) return
                val p = player ?: return
                if (p.isPlaying) {
                    longSpeed = true
                    p.setPlaybackSpeed(2f)
                    showHud("2.0x 倍速播放中", 0)
                }
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (locked || e1 == null || longSpeed) return false
                val w = root.width.toFloat()
                val h = root.height.toFloat()
                if (gMode == G_NONE) {
                    val edge = dp(24)
                    // 屏幕边缘留给系统手势
                    if (e1.x < edge || e1.x > w - edge || e1.y < edge || e1.y > h - edge) return false
                    if (abs(e2.x - e1.x) > abs(e2.y - e1.y)) {
                        val p = player ?: return false
                        if (durationMs() <= 0 || !p.isCurrentMediaItemSeekable) return false
                        gMode = G_SEEK
                        seekStart = p.currentPosition
                        seekTarget = seekStart
                    } else if (e1.x < w / 2) {
                        gMode = G_BRIGHT
                        curBright = currentBrightness()
                    } else {
                        gMode = G_VOL
                        curVol = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() /
                            audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    }
                }
                when (gMode) {
                    G_SEEK -> {
                        val d = durationMs()
                        val span = min(d, 180_000L) // 整个屏幕宽度最多对应 3 分钟
                        val delta = ((e2.x - e1.x) / w * span).toLong()
                        seekTarget = (seekStart + delta).coerceIn(0L, d)
                        val diff = (seekTarget - seekStart) / 1000
                        val sign = if (diff >= 0) "+" else "-"
                        showHud("${fmt(seekTarget)} / ${fmt(d)}\n$sign${abs(diff)} 秒", 0)
                    }
                    G_BRIGHT -> {
                        curBright = (curBright + distanceY / (h * 0.75f)).coerceIn(0.02f, 1f)
                        window.attributes = window.attributes.also { it.screenBrightness = curBright }
                        showHud("亮度 ${(curBright * 100).roundToInt()}%", 0)
                    }
                    G_VOL -> {
                        curVol = (curVol + distanceY / (h * 0.75f)).coerceIn(0f, 1f)
                        val maxVol = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, (curVol * maxVol).roundToInt(), 0)
                        showHud("音量 ${(curVol * 100).roundToInt()}%", 0)
                    }
                }
                return true
            }
        })
    }

    // =====================================================================
    // 界面构建
    // =====================================================================

    private fun buildUi() {
        buildGestures()
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        surface = SurfaceView(this)
        root.addView(surface, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        root.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> applyResize() }

        loading = ProgressBar(this).apply { indeterminateTintList = ColorStateList.valueOf(Color.WHITE) }
        root.addView(loading, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER))

        hud = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(10), dp(20), dp(10))
            background = rounded(0xB3000000.toInt(), 10)
            visibility = View.GONE
        }
        root.addView(hud, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(72)
        })

        // 顶部栏
        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = shade(true)
            setPadding(dp(8), dp(4), dp(8), dp(24))
        }
        topBar.addView(PlayerIconView(this, PlayerIconView.BACK).apply { setOnClickListener { finish() } },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        titleTv = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            text = titleOf(url)
        }
        topBar.addView(titleTv, LinearLayout.LayoutParams(0, -2, 1f))
        topBar.addView(textButton("旋转") { toggleOrientation() }, LinearLayout.LayoutParams(-2, -2))
        topBar.addView(textButton("外部播放") { openExternal() }, LinearLayout.LayoutParams(-2, -2))

        // 底部栏：进度行 + 按钮行
        bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shade(false)
            setPadding(dp(16), dp(24), dp(16), dp(8))
        }
        curTv = timeText()
        durTv = timeText()
        seek = SeekBar(this).apply {
            max = 1000
            setPadding(dp(12), 0, dp(12), 0)
            progressTintList = ColorStateList.valueOf(ACCENT)
            thumbTintList = ColorStateList.valueOf(ACCENT)
            secondaryProgressTintList = ColorStateList.valueOf(0x88FFFFFF.toInt())
            progressBackgroundTintList = ColorStateList.valueOf(0x44FFFFFF)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, progress: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    val d = durationMs()
                    if (d > 0) curTv.text = fmt(d * progress / 1000)
                }

                override fun onStartTrackingTouch(s: SeekBar) {
                    dragging = true
                    handler.removeCallbacks(hideRunnable)
                }

                override fun onStopTrackingTouch(s: SeekBar) {
                    dragging = false
                    val d = durationMs()
                    if (d > 0) player?.seekTo(d * s.progress / 1000)
                    scheduleHide()
                }
            })
        }
        val seekRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        seekRow.addView(curTv, LinearLayout.LayoutParams(-2, -2))
        seekRow.addView(seek, LinearLayout.LayoutParams(0, dp(36), 1f))
        seekRow.addView(durTv, LinearLayout.LayoutParams(-2, -2))

        playBtn = PlayerIconView(this, PlayerIconView.PAUSE).apply { setOnClickListener { togglePlay() } }
        qualityTv = textButton("画质") { showQualityMenu() }.apply { visibility = View.GONE } // 只有一个档位时不显示
        speedTv = textButton("倍速") { showSpeedMenu() }
        fitTv = textButton(fit.label) { showFitMenu() }
        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        btnRow.addView(playBtn, LinearLayout.LayoutParams(dp(44), dp(44)))
        btnRow.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        btnRow.addView(qualityTv, LinearLayout.LayoutParams(-2, -2))
        btnRow.addView(speedTv, LinearLayout.LayoutParams(-2, -2))
        btnRow.addView(fitTv, LinearLayout.LayoutParams(-2, -2))
        bottomBar.addView(seekRow, LinearLayout.LayoutParams(-1, -2))
        bottomBar.addView(btnRow, LinearLayout.LayoutParams(-1, -2))

        controls = FrameLayout(this)
        controls.addView(topBar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        controls.addView(bottomBar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        root.addView(controls, FrameLayout.LayoutParams(-1, -1))

        // 锁屏按钮
        lockBtn = PlayerIconView(this, PlayerIconView.UNLOCK).apply {
            background = oval(0x66000000)
            setOnClickListener { setLocked(!locked) }
        }
        root.addView(lockBtn, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.START or Gravity.CENTER_VERTICAL).apply {
            marginStart = dp(20)
        })

        // 右侧菜单（倍速 / 画面比例）
        menuList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        menuPanel = ScrollView(this).apply {
            setBackgroundColor(0xEE111111.toInt())
            visibility = View.GONE
            addView(menuList)
        }
        root.addView(menuPanel, FrameLayout.LayoutParams(dp(180), -1, Gravity.END))

        // 刘海屏：控制条避开挖孔区域
        root.setOnApplyWindowInsetsListener { _, insets ->
            val c = insets.displayCutout
            val l = c?.safeInsetLeft ?: 0
            val r = c?.safeInsetRight ?: 0
            val t = c?.safeInsetTop ?: 0
            val b = c?.safeInsetBottom ?: 0
            topBar.setPadding(dp(8) + l, dp(4) + t, dp(8) + r, dp(24))
            bottomBar.setPadding(dp(16) + l, dp(24), dp(16) + r, dp(8) + b)
            val lp = lockBtn.layoutParams as FrameLayout.LayoutParams
            lp.marginStart = dp(20) + l
            lockBtn.layoutParams = lp
            insets
        }

        root.setOnTouchListener { _, ev ->
            if (menuVisible) {
                if (ev.actionMasked == MotionEvent.ACTION_UP) hideMenu()
                return@setOnTouchListener true
            }
            gd.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) endGesture()
            true
        }
    }

    private fun titleOf(u: String): String {
        intent.getStringExtra(EXTRA_TITLE)?.takeIf { it.isNotBlank() }?.let { return it }
        val uri = Uri.parse(u)
        val seg = uri.lastPathSegment?.takeIf { it.isNotBlank() }
        return Uri.decode(seg ?: uri.host ?: u)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun oval(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    /** 顶部 / 底部的渐变遮罩，让白色文字在任何画面上都看得清。 */
    private fun shade(top: Boolean) = GradientDrawable(
        if (top) GradientDrawable.Orientation.TOP_BOTTOM else GradientDrawable.Orientation.BOTTOM_TOP,
        intArrayOf(0xCC000000.toInt(), 0x00000000)
    )

    private fun timeText() = TextView(this).apply {
        setTextColor(Color.WHITE)
        textSize = 12f
        text = "00:00"
        gravity = Gravity.CENTER
        minWidth = dp(48)
    }

    private fun textButton(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 14f
        gravity = Gravity.CENTER
        minHeight = dp(44)
        setPadding(dp(12), 0, dp(12), 0)
        setOnClickListener { onClick() }
    }

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_UA = "ua"
        const val EXTRA_REFERER = "referer"
        const val EXTRA_COOKIE = "cookie"
        const val EXTRA_TITLE = "title" // 可选：传了就显示在顶部栏，不传则取 URL 文件名

        private val ACCENT = 0xFF4C8DFF.toInt()
        private const val Q_AUTO = 0
        private const val Q_HIGHEST = 1
        private const val Q_FIXED = 2
        private const val G_NONE = 0
        private const val G_SEEK = 1
        private const val G_BRIGHT = 2
        private const val G_VOL = 3
    }
}

/** 一个可选的视频档位。 */
private class QTrack(val group: Tracks.Group, val index: Int, val format: Format)

/** 用 Canvas 画的小图标（24x24 网格），省去 drawable 资源文件。 */
private class PlayerIconView(ctx: Context, kind: Int) : View(ctx) {
    var kind: Int = kind
        set(v) {
            field = v
            invalidate()
        }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 2.2f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()

    init {
        isClickable = true
    }

    override fun onDraw(c: Canvas) {
        val s = min(width, height) / 24f * 0.6f
        c.save()
        c.translate((width - 24 * s) / 2f, (height - 24 * s) / 2f)
        c.scale(s, s)
        path.reset()
        when (kind) {
            PLAY -> {
                path.moveTo(8f, 5f); path.lineTo(8f, 19f); path.lineTo(19f, 12f); path.close()
                c.drawPath(path, fill)
            }
            PAUSE -> {
                c.drawRect(6f, 5f, 10f, 19f, fill)
                c.drawRect(14f, 5f, 18f, 19f, fill)
            }
            BACK -> {
                path.moveTo(15f, 5f); path.lineTo(8f, 12f); path.lineTo(15f, 19f)
                c.drawPath(path, line)
            }
            LOCK, UNLOCK -> {
                c.drawRoundRect(RectF(6f, 11f, 18f, 20f), 2f, 2f, fill)
                path.moveTo(8.5f, 11f); path.lineTo(8.5f, 7.5f)
                path.arcTo(RectF(8.5f, 4f, 15.5f, 11f), 180f, 180f)
                if (kind == LOCK) path.lineTo(15.5f, 11f) // 锁上：两脚都插进锁身；解锁：右脚悬空
                c.drawPath(path, line)
            }
        }
        c.restore()
    }

    companion object {
        const val PLAY = 0
        const val PAUSE = 1
        const val BACK = 2
        const val LOCK = 3
        const val UNLOCK = 4
    }
}
