package com.example.searchhub

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** 切换器里一张卡片需要的全部信息。 */
class TabCard(
    val id: Long,
    val title: String,
    val host: String,
    val thumb: Bitmap?,
    val favicon: Bitmap?,
    val isHome: Boolean,
    val selected: Boolean
)

/** 缩略图：宽度铺满、顶部对齐（网页截图是竖长的，只看最上面一屏）。 */
private class TopCropView(ctx: Context) : ImageView(ctx) {
    init { scaleType = ImageView.ScaleType.MATRIX }

    override fun setFrame(l: Int, t: Int, r: Int, b: Int): Boolean {
        val changed = super.setFrame(l, t, r, b)
        val d = drawable
        if (d != null && d.intrinsicWidth > 0) {
            val s = (r - l).toFloat() / d.intrinsicWidth
            val m = Matrix()
            m.setScale(s, s)
            imageMatrix = m
        }
        return changed
    }
}

/**
 * 标签页切换器：全屏的卡片网格（两列），当前标签带靛青描边；
 * 每张卡片有网页截图、标题、关闭按钮；底部是「关闭全部 / 新建 / 完成」。
 * 用法：把 [layer] 加到最上层 FrameLayout，需要时调用 [show] / [render] / [hide]。
 */
class TabSwitcher(
    private val ctx: Context,
    private val onSelect: (Long) -> Unit,
    private val onClose: (Long) -> Unit,
    private val onNew: () -> Unit,
    private val onCloseAll: () -> Unit,
    private val onDone: () -> Unit,
    private val onChange: () -> Unit = {}
) {
    private val title = TextView(ctx).apply {
        textSize = 17f
        typeface = Ui.MEDIUM
        setTextColor(Ui.TEXT)
        setPadding(ctx.dp(22), ctx.dp(16), ctx.dp(22), ctx.dp(10))
    }
    private val grid = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(ctx.dp(10), ctx.dp(4), ctx.dp(10), ctx.dp(20))
    }
    private val scroll = ScrollView(ctx).apply {
        isVerticalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        addView(grid, FrameLayout.LayoutParams(-1, -2))
    }
    private var selectedRow: View? = null

    val layer = FrameLayout(ctx).apply {
        visibility = View.GONE
        isClickable = true   // 不让触摸穿透到下面的网页
        setBackgroundColor(Ui.CHROME)
        addView(LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(title, LinearLayout.LayoutParams(-1, -2))
            addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(bottomBar(), LinearLayout.LayoutParams(-1, -2))
        }, FrameLayout.LayoutParams(-1, -1))
    }

    val isShowing: Boolean get() = layer.visibility == View.VISIBLE

    private fun bottomBar(): View {
        fun textBtn(label: String, color: Int, onClick: () -> Unit) = TextView(ctx).apply {
            text = label
            textSize = 14f
            typeface = Ui.MEDIUM
            gravity = Gravity.CENTER
            setTextColor(color)
            background = rippleOf(null)
            setOnClickListener { onClick() }
        }
        val plus = FrameLayout(ctx).apply {
            background = roundRect(Ui.PRIMARY, ctx.dp(24).toFloat())
            elevation = ctx.dp(3).toFloat()
            isClickable = true
            addView(IconView(ctx, IconView.Kind.PLUS, Ui.WHITE), FrameLayout.LayoutParams(ctx.dp(22), ctx.dp(22), Gravity.CENTER))
            pressFeedback(0.9f)
            setOnClickListener { onNew() }
        }
        val plusCell = FrameLayout(ctx).apply {
            addView(plus, FrameLayout.LayoutParams(ctx.dp(48), ctx.dp(48), Gravity.CENTER))
        }
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(textBtn("关闭全部", Ui.TEXT_SUB) { onCloseAll() }, LinearLayout.LayoutParams(0, -1, 1f))
            addView(plusCell, LinearLayout.LayoutParams(0, -1, 1f))
            addView(textBtn("完成", Ui.PRIMARY) { onDone() }, LinearLayout.LayoutParams(0, -1, 1f))
        }
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.CHROME)
            addView(View(ctx).apply { setBackgroundColor(0xFFE9EBF2.toInt()) }, LinearLayout.LayoutParams(-1, 1))
            addView(row, LinearLayout.LayoutParams(-1, ctx.dp(56)))
        }
    }

    fun show(cards: List<TabCard>) {
        render(cards)
        layer.animate().cancel()
        layer.visibility = View.VISIBLE
        layer.alpha = 0f
        layer.scaleX = 1.04f
        layer.scaleY = 1.04f
        layer.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(200)
            .setInterpolator(DecelerateInterpolator()).start()
        selectedRow?.let { row -> scroll.post { scroll.scrollTo(0, maxOf(0, row.top - ctx.dp(8))) } }
        onChange()
    }

    fun hide() {
        if (!isShowing) return
        layer.animate().cancel()
        layer.animate().alpha(0f).scaleX(1.04f).scaleY(1.04f).setDuration(160).withEndAction {
            layer.visibility = View.GONE
            layer.alpha = 1f
            layer.scaleX = 1f
            layer.scaleY = 1f
            onChange()
        }.start()
    }

    /** 重新画整个网格（标签增删后调用，保持当前滚动位置）。 */
    fun render(cards: List<TabCard>) {
        title.text = "${cards.size} 个标签页"
        grid.removeAllViews()
        selectedRow = null
        val gap = ctx.dp(12)
        val cardW = (ctx.resources.displayMetrics.widthPixels - ctx.dp(10) * 2 - gap * 2) / 2
        var i = 0
        while (i < cards.size) {
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            for (k in 0 until 2) {
                val c = cards.getOrNull(i + k)
                val lp = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(gap / 2, gap / 2, gap / 2, gap / 2) }
                if (c != null) {
                    row.addView(card(c, cardW), lp)
                    if (c.selected) selectedRow = row
                } else {
                    row.addView(View(ctx), lp)
                }
            }
            grid.addView(row, LinearLayout.LayoutParams(-1, -2))
            i += 2
        }
    }

    private fun card(c: TabCard, cardW: Int): View {
        val icon: View = if (c.favicon != null) {
            ImageView(ctx).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                setImageBitmap(c.favicon)
            }
        } else {
            TextView(ctx).apply {
                text = (c.host.firstOrNull { it.isLetterOrDigit() } ?: '#').uppercaseChar().toString()
                textSize = 11f
                typeface = Ui.MEDIUM
                gravity = Gravity.CENTER
                setTextColor(Ui.WHITE)
                background = ctx.badge(c.host.ifEmpty { "home" }, 6)
            }
        }
        val name = TextView(ctx).apply {
            text = c.title.ifBlank { if (c.isHome) "新标签页" else c.host }
            textSize = 12.5f
            setTextColor(Ui.TEXT)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val close = ctx.iconButton(IconView.Kind.CLEAR, 32, 16, Ui.TEXT_SUB) { onClose(c.id) }
        val head = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ctx.dp(10), 0, ctx.dp(2), 0)
            addView(icon, LinearLayout.LayoutParams(ctx.dp(18), ctx.dp(18)))
            addView(name, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = ctx.dp(8) })
            addView(close, LinearLayout.LayoutParams(ctx.dp(32), ctx.dp(32)))
        }

        val preview = FrameLayout(ctx).apply { setBackgroundColor(Ui.SURFACE) }
        if (c.thumb != null) {
            preview.addView(TopCropView(ctx).apply { setImageBitmap(c.thumb) }, FrameLayout.LayoutParams(-1, -1))
        } else if (c.isHome) {
            preview.addView(LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                addView(IconView(ctx, IconView.Kind.SEARCH, Ui.ICON_DIM), LinearLayout.LayoutParams(ctx.dp(26), ctx.dp(26)))
                addView(TextView(ctx).apply {
                    text = "新标签页"
                    textSize = 12f
                    setTextColor(Ui.TEXT_SUB)
                }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = ctx.dp(8) })
            }, FrameLayout.LayoutParams(-1, -1))
        } else {
            preview.addView(TextView(ctx).apply {
                text = (c.host.firstOrNull { it.isLetterOrDigit() } ?: '#').uppercaseChar().toString()
                textSize = 22f
                typeface = Ui.MEDIUM
                gravity = Gravity.CENTER
                setTextColor(Ui.WHITE)
                background = ctx.badge(c.host.ifEmpty { "page" }, 14)
            }, FrameLayout.LayoutParams(ctx.dp(52), ctx.dp(52), Gravity.CENTER))
        }

        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = roundRect(Ui.WHITE, ctx.dp(16).toFloat()).also {
                if (c.selected) it.setStroke(ctx.dp(2), Ui.PRIMARY)
            }
            clipToOutline = true
            elevation = ctx.dp(2).toFloat()
            addView(head, LinearLayout.LayoutParams(-1, ctx.dp(38)))
            addView(preview, LinearLayout.LayoutParams(-1, (cardW * 1.3f).toInt()))
            pressFeedback(0.97f)
            setOnClickListener { onSelect(c.id) }
        }
    }
}
