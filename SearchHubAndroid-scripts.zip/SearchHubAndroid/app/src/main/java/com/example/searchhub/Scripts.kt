package com.example.searchhub

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * 用户脚本（兼容 Tampermonkey / Greasemonkey 风格的 .user.js，也可以是不带头部的普通 JS）。
 * 负责：存储（SharedPreferences + JSON，主线程访问）、`==UserScript==` 头部解析、网址匹配、生成注入用的 JS。
 */
object Scripts {
    /** 注入时机：页面开始加载（onPageStarted）/ 页面加载完成（onPageFinished）。 */
    const val START = 0
    const val END = 1

    /** 单个脚本的代码上限（字符数）。 */
    const val MAX_CHARS = 1_000_000

    class Meta(
        val name: String,
        val namespace: String,
        val version: String,
        val description: String,
        val matches: List<String>,
        val includes: List<String>,
        val excludes: List<String>,
        val runAt: String
    )

    class Script(val id: String, var label: String, var code: String, var enabled: Boolean, var time: Long) {
        var meta: Meta = parseMeta(code)

        /** 显示名：优先用头部的 @name，其次用用户填的名称。 */
        val name: String get() = meta.name.ifBlank { label }.ifBlank { "未命名脚本" }

        fun reparse() { meta = parseMeta(code) }

        /** 是否声明了运行范围；没声明就在所有网页运行。 */
        val hasScope: Boolean get() = meta.matches.isNotEmpty() || meta.includes.isNotEmpty()

        fun matches(url: String): Boolean {
            if (!(url.startsWith("http://") || url.startsWith("https://"))) return false
            val bare = url.substringBefore('#')
            if (meta.excludes.any { globMatch(it, url) || globMatch(it, bare) }) return false
            if (!hasScope) return true
            return meta.matches.any { matchPattern(it, bare) } ||
                meta.includes.any { globMatch(it, url) || globMatch(it, bare) }
        }

        /** 列表里显示的运行范围。 */
        fun scopeText(): String {
            val all = meta.matches + meta.includes
            if (all.isEmpty()) return "所有网页"
            val first = all[0].removePrefix("*://").removePrefix("http://").removePrefix("https://")
            return if (all.size == 1) first else "$first 等 ${all.size} 条规则"
        }
    }

    private lateinit var sp: android.content.SharedPreferences
    private var inited = false
    private val list = ArrayList<Script>()      // 新的在前

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        sp = ctx.applicationContext.getSharedPreferences("scripts_store", Context.MODE_PRIVATE)
        val s = sp.getString("list", null) ?: return
        try {
            val a = JSONArray(s)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                list.add(Script(o.getString("i"), o.optString("n"), o.optString("c"), o.optBoolean("e", true), o.optLong("t")))
            }
        } catch (e: Exception) {
            list.clear()
        }
    }

    private fun save() {
        val a = JSONArray()
        for (s in list) a.put(JSONObject().put("i", s.id).put("n", s.label).put("c", s.code).put("e", s.enabled).put("t", s.time))
        sp.edit().putString("list", a.toString()).apply()
    }

    /** 总开关：关闭后所有网页都不运行脚本。 */
    var enabledAll: Boolean
        get() = sp.getBoolean("all_on", true)
        set(v) { sp.edit().putBoolean("all_on", v).apply() }

    fun all(): List<Script> = ArrayList(list)

    /** 添加脚本。头部里 @name + @namespace 都相同的视为同一个脚本，直接更新。返回 (脚本, 是否更新了已有的)。 */
    fun add(code: String, label: String): Pair<Script, Boolean> {
        val clean = code.removePrefix("\uFEFF")
        val meta = parseMeta(clean)
        val dup = if (meta.name.isNotBlank())
            list.firstOrNull { it.meta.name == meta.name && it.meta.namespace == meta.namespace } else null
        if (dup != null) {
            dup.code = clean
            dup.reparse()
            dup.time = System.currentTimeMillis()
            save()
            return dup to true
        }
        val s = Script(UUID.randomUUID().toString().take(8), label.ifBlank { "脚本 ${list.size + 1}" }, clean, true, System.currentTimeMillis())
        list.add(0, s)
        save()
        return s to false
    }

    fun update(id: String, code: String, label: String) {
        val s = list.firstOrNull { it.id == id } ?: return
        s.code = code.removePrefix("\uFEFF")
        if (label.isNotBlank()) s.label = label
        s.reparse()
        s.time = System.currentTimeMillis()
        save()
    }

    fun setEnabled(id: String, on: Boolean) {
        list.firstOrNull { it.id == id }?.enabled = on
        save()
    }

    fun remove(id: String) {
        list.removeAll { it.id == id }
        save()
    }

    /** 当前网址上会运行的脚本数（用于菜单高亮）。 */
    fun countFor(url: String?): Int =
        if (url == null || !enabledAll) 0 else list.count { it.enabled && it.matches(url) }

    /**
     * 某个网址在某个时机要注入的 JS 列表（每个脚本一段，彼此隔离）。
     * START：只含声明了 `@run-at document-start` 的；END：全部匹配的（已经在 START 跑过的靠页面内标记自动跳过）。
     */
    fun injections(url: String, phase: Int): List<String> {
        if (!enabledAll) return emptyList()
        val origin = if (phase == START) originOf(url) else ""
        return list
            .filter { it.enabled && it.matches(url) && (phase == END || it.meta.runAt == "document-start") }
            .map { build(it, origin) }
    }

    private fun originOf(url: String): String {
        val u = Uri.parse(url)
        val scheme = u.scheme ?: return ""
        val host = u.host ?: return ""
        return scheme + "://" + host + (if (u.port != -1) ":" + u.port else "")
    }

    // ---------- 头部解析 ----------

    private val HEADER = Regex("//\\s*==UserScript==([\\s\\S]*?)//\\s*==/UserScript==")
    private val LINE = Regex("\\s*//\\s*@([\\w:\\-]+)\\s*(.*?)\\s*")

    fun parseMeta(code: String): Meta {
        var name = ""
        var ns = ""
        var ver = ""
        var desc = ""
        var runAt = "document-idle"
        val matches = ArrayList<String>()
        val includes = ArrayList<String>()
        val excludes = ArrayList<String>()
        val h = HEADER.find(code)
        if (h != null) {
            for (line in h.groupValues[1].lines()) {
                val m = LINE.matchEntire(line) ?: continue
                val v = m.groupValues[2]
                if (v.isEmpty()) continue
                when (m.groupValues[1].lowercase()) {
                    "name" -> if (name.isEmpty()) name = v
                    "namespace" -> if (ns.isEmpty()) ns = v
                    "version" -> if (ver.isEmpty()) ver = v
                    "description" -> if (desc.isEmpty()) desc = v
                    "match" -> matches.add(v)
                    "include" -> includes.add(v)
                    "exclude", "exclude-match" -> excludes.add(v)
                    "run-at" -> runAt = v.lowercase()
                }
            }
        }
        return Meta(name, ns, ver, desc, matches, includes, excludes, runAt)
    }

    // ---------- 网址匹配 ----------

    /** @include / @exclude：`*` 通配的 glob，或写成 `/正则/`。 */
    private fun globMatch(g: String, url: String): Boolean = try {
        val re = if (g.length > 2 && g.startsWith("/") && g.endsWith("/"))
            Regex(g.substring(1, g.length - 1), RegexOption.IGNORE_CASE)
        else
            Regex(g.split('*').joinToString(".*") { Regex.escape(it) }, RegexOption.IGNORE_CASE)
        re.matches(url)
    } catch (e: Exception) {
        false
    }

    private val MATCH = Regex("(\\*|https?)://([^/]*)(/.*)?")

    /** @match：Chrome 扩展的匹配模式 `scheme://host/path`（scheme 可为 *，host 可为 * 或 *.example.com）。 */
    private fun matchPattern(p: String, url: String): Boolean {
        if (p == "<all_urls>") return true
        val m = MATCH.matchEntire(p) ?: return false
        val u = Uri.parse(url)
        val scheme = u.scheme ?: return false
        val host = (u.host ?: return false).lowercase()
        val ps = m.groupValues[1]
        if (ps == "*") {
            if (scheme != "http" && scheme != "https") return false
        } else if (ps != scheme) return false
        val ph = m.groupValues[2].lowercase()
        val hostOk = when {
            ph == "*" -> true
            ph.startsWith("*.") -> host == ph.substring(2) || host.endsWith(ph.substring(1))
            else -> host == ph
        }
        if (!hostOk) return false
        val path = (u.encodedPath ?: "/").ifEmpty { "/" } + (u.encodedQuery?.let { "?$it" } ?: "")
        val pp = m.groupValues[3].ifEmpty { "/" }
        return Regex(pp.split('*').joinToString(".*") { Regex.escape(it) }).matches(path)
    }

    // ---------- 注入代码 ----------

    /**
     * 包装模板：每个脚本单独一段、各自 try/catch；页面内用一个标记保证同一个文档只跑一次；
     * 提供常用的 GM_* / GM.* 接口（存储用页面的 localStorage，按脚本隔离；GM_xmlhttpRequest 基于 fetch，受页面跨域限制）。
     * 注意：这段 JS 里不能出现美元符号（Kotlin 原始字符串会当模板），占位符用 @@XX@@。
     */
    private val TEMPLATE = """
(function(){
  var __id = @@ID@@, __origin = @@ORIGIN@@;
  var __guard = '__sh_script_' + __id;
  try {
    if (__origin && location.origin !== __origin) return;
    if (window[__guard]) return;
    Object.defineProperty(window, __guard, {value: 1, configurable: true});
  } catch (e) { return; }
  var unsafeWindow = window;
  var GM_info = @@INFO@@;
  var __ns = '__shgm_' + __id + ':';
  function GM_addStyle(css) {
    var s = document.createElement('style'); s.textContent = css;
    (document.head || document.documentElement).appendChild(s); return s;
  }
  function GM_getValue(k, d) { try { var v = localStorage.getItem(__ns + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } }
  function GM_setValue(k, v) { try { localStorage.setItem(__ns + k, JSON.stringify(v)); } catch (e) {} }
  function GM_deleteValue(k) { try { localStorage.removeItem(__ns + k); } catch (e) {} }
  function GM_listValues() {
    var r = [];
    try { for (var i = 0; i < localStorage.length; i++) { var k = localStorage.key(i); if (k.indexOf(__ns) === 0) r.push(k.slice(__ns.length)); } } catch (e) {}
    return r;
  }
  function GM_log() { try { console.log.apply(console, arguments); } catch (e) {} }
  function GM_openInTab(u) { window.open(u, '_blank'); }
  function GM_setClipboard(t) {
    try { navigator.clipboard.writeText(String(t)); } catch (e) {
      var a = document.createElement('textarea'); a.value = String(t); a.style.cssText = 'position:fixed;opacity:0';
      document.body.appendChild(a); a.select(); try { document.execCommand('copy'); } catch (e2) {} a.remove();
    }
  }
  function GM_registerMenuCommand() {}
  function GM_xmlhttpRequest(d) {
    var o = {method: d.method || 'GET', headers: d.headers || {}, credentials: 'include'};
    if (d.data != null) o.body = d.data;
    var ac = typeof AbortController !== 'undefined' ? new AbortController() : null;
    if (ac) o.signal = ac.signal;
    fetch(d.url, o).then(function (r) {
      return r.text().then(function (t) {
        var h = ''; r.headers.forEach(function (v, k) { h += k + ': ' + v + '\r\n'; });
        var res = {status: r.status, statusText: r.statusText, responseText: t, response: t, responseHeaders: h, finalUrl: r.url, readyState: 4};
        if (d.onload) d.onload(res);
      });
    }).catch(function (e) { if (d.onerror) d.onerror({error: String(e)}); });
    return {abort: function () { if (ac) ac.abort(); }};
  }
  var GM = {
    info: GM_info,
    getValue: function (k, d) { return Promise.resolve(GM_getValue(k, d)); },
    setValue: function (k, v) { GM_setValue(k, v); return Promise.resolve(); },
    deleteValue: function (k) { GM_deleteValue(k); return Promise.resolve(); },
    listValues: function () { return Promise.resolve(GM_listValues()); },
    setClipboard: GM_setClipboard,
    openInTab: GM_openInTab,
    addStyle: GM_addStyle,
    xmlHttpRequest: GM_xmlhttpRequest
  };
  try {
    (function () {
@@CODE@@
    }).call(window);
  } catch (e) { try { console.error('[脚本 ' + GM_info.script.name + ']', e); } catch (e2) {} }
})();
"""

    private fun build(s: Script, origin: String): String {
        val info = JSONObject().put("scriptHandler", "SearchHub").put("version", "1.0").put(
            "script", JSONObject().put("name", s.name).put("namespace", s.meta.namespace)
                .put("version", s.meta.version).put("description", s.meta.description)
        )
        val parts = TEMPLATE.split("@@CODE@@")
        fun fill(t: String) = t
            .replace("@@ID@@", JSONObject.quote(s.id))
            .replace("@@ORIGIN@@", JSONObject.quote(origin))
            .replace("@@INFO@@", info.toString())
        // 用户代码最后拼进去，不会被占位符替换误伤；末尾补换行，避免最后一行是 // 注释时吃掉后面的括号
        return fill(parts[0]) + s.code + "\n" + fill(parts[1])
    }
}
