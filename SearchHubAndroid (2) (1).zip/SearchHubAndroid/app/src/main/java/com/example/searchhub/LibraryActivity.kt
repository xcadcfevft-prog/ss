package com.example.searchhub

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 书签 / 历史记录页。点一条返回主界面并打开；长按可复制链接或删除。 */
class LibraryActivity : Activity() {

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_TAB = "tab"   // 0 书签  1 历史
    }

    private var tab = 0
    private var data: List<Store.Entry> = emptyList()
    private lateinit var adapter: BaseAdapter
    private lateinit var tabMarks: TextView
    private lateinit var tabHist: TextView
    private lateinit var clearBtn: TextView
    private lateinit var empty: TextView
    private val dateFmt = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        tab = intent.getIntExtra(EXTRA_TAB, 0)

        val back = iconButton(IconView.Kind.BACK) { finish() }
        tabMarks = tabText("书签") { select(0) }
        tabHist = tabText("历史") { select(1) }
        val seg = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = roundRect(Ui.SURFACE, dp(18).toFloat())
            setPadding(dp(3), dp(3), dp(3), dp(3))
            addView(tabMarks, LinearLayout.LayoutParams(dp(72), dp(30)))
            addView(tabHist, LinearLayout.LayoutParams(dp(72), dp(30)))
        }
        clearBtn = TextView(this).apply {
            text = "清空"
            textSize = 14f
            setTextColor(Ui.PRIMARY)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(10), dp(16), dp(10))
            setOnClickListener { confirmClear() }
        }
        val header = FrameLayout(this).apply {
            setBackgroundColor(Ui.WHITE)
            addView(back, FrameLayout.LayoutParams(-2, dp(52), Gravity.START or Gravity.CENTER_VERTICAL).apply { leftMargin = dp(4) })
            addView(seg, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            addView(clearBtn, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL))
        }

        adapter = object : BaseAdapter() {
            override fun getCount() = data.size
            override fun getItem(position: Int): Any = data[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val row = (convertView?.tag as? Row) ?: Row().also { it.root.tag = it }
                row.bind(data[position])
                return row.root
            }
        }
        val list = ListView(this).apply {
            divider = ColorDrawable(0x00000000)
            dividerHeight = 0
            setAdapter(adapter)
            setOnItemClickListener { _, _, i, _ -> if (i < data.size) open(data[i]) }
            setOnItemLongClickListener { _, _, i, _ -> if (i < data.size) showActions(data[i]); true }
        }
        empty = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 14f
            setTextColor(Ui.TEXT_SUB)
        }
        val body = FrameLayout(this).apply {
            addView(list, FrameLayout.LayoutParams(-1, -1))
            addView(empty, FrameLayout.LayoutParams(-1, -1))
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.WHITE)
            addView(header, LinearLayout.LayoutParams(-1, dp(52)))
            addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        })
        lightBars()
        select(tab)
    }

    private fun tabText(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 14f
        gravity = Gravity.CENTER
        setOnClickListener { onClick() }
    }

    private fun select(t: Int) {
        tab = t
        fun style(v: TextView, on: Boolean) {
            v.background = if (on) roundRect(Ui.WHITE, dp(15).toFloat()) else null
            v.setTextColor(if (on) Ui.TEXT else Ui.TEXT_SUB)
            v.typeface = if (on) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
        style(tabMarks, t == 0)
        style(tabHist, t == 1)
        reload()
    }

    private fun reload() {
        data = if (tab == 0) Store.bookmarks() else Store.history()
        empty.text = if (tab == 0) "还没有书签\n在网页菜单里点「收藏」即可添加" else "暂无历史记录"
        empty.visibility = if (data.isEmpty()) View.VISIBLE else View.GONE
        clearBtn.visibility = if (tab == 1 && data.isNotEmpty()) View.VISIBLE else View.GONE
        adapter.notifyDataSetChanged()
    }

    private fun open(e: Store.Entry) {
        setResult(RESULT_OK, Intent().putExtra(EXTRA_URL, e.url))
        finish()
    }

    private fun showActions(e: Store.Entry) {
        AlertDialog.Builder(this)
            .setTitle(e.title)
            .setItems(arrayOf("复制链接", "删除")) { _, which ->
                if (which == 0) {
                    (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("url", e.url))
                    Toast.makeText(this, "已复制链接", Toast.LENGTH_SHORT).show()
                } else {
                    if (tab == 0) Store.removeBookmark(e.url) else Store.removeHistory(e)
                    reload()
                }
            }
            .show()
    }

    private fun confirmClear() {
        AlertDialog.Builder(this)
            .setMessage("清空全部历史记录？")
            .setNegativeButton("取消", null)
            .setPositiveButton("清空") { _, _ -> Store.clearHistory(); reload() }
            .show()
    }

    private inner class Row {
        val ctx: Context = this@LibraryActivity
        val letter = TextView(ctx).apply {
            gravity = Gravity.CENTER
            textSize = 15f
            setTextColor(Ui.PRIMARY)
            typeface = Typeface.DEFAULT_BOLD
            background = roundRect(Ui.PRIMARY_LIGHT, dp(18).toFloat())
        }
        val title = TextView(ctx).apply {
            textSize = 15f
            setTextColor(Ui.TEXT)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val sub = TextView(ctx).apply {
            textSize = 12f
            setTextColor(Ui.TEXT_SUB)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val root = LinearLayout(ctx)

        init {
            val col = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                addView(title)
                addView(sub, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
            }
            root.orientation = LinearLayout.HORIZONTAL
            root.gravity = Gravity.CENTER_VERTICAL
            root.setPadding(dp(16), dp(10), dp(16), dp(10))
            root.addView(letter, LinearLayout.LayoutParams(dp(36), dp(36)))
            root.addView(col, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(14) })
        }

        fun bind(e: Store.Entry) {
            val host = Uri.parse(e.url).host ?: e.url
            title.text = e.title.ifBlank { host }
            sub.text = if (tab == 1) "$host · ${dateFmt.format(Date(e.time))}" else host
            letter.text = (host.removePrefix("www.").removePrefix("m.").firstOrNull() ?: '#').uppercaseChar().toString()
        }
    }
}
