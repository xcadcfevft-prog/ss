package com.example.searchhub

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ActivityInfo
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.MediaController
import android.widget.ProgressBar
import android.widget.Toast
import android.widget.VideoView

/**
 * 全屏播放嗅探到的媒体：系统 VideoView + MediaController，无第三方依赖。
 * 横屏沉浸式、常亮；竖屏视频自动转竖屏；带上网页的 UA / Referer / Cookie 以通过防盗链。
 * 系统播放器支持 mp4 / webm / mkv / mp3 / m3u8 等；mpd / flv 等不支持时可一键转外部播放器。
 */
class PlayerActivity : Activity() {

    private lateinit var video: VideoView
    private lateinit var loading: ProgressBar
    private lateinit var controller: MediaController
    private lateinit var url: String
    private var ready = false
    private var pos = 0
    private var wasPlaying = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        url = intent.getStringExtra(EXTRA_URL) ?: run { finish(); return }

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        video = VideoView(this)
        loading = ProgressBar(this)
        controller = MediaController(this)
        video.setMediaController(controller)

        val root = FrameLayout(this).apply {
            setBackgroundColor(0xFF000000.toInt())
            addView(video, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
            addView(loading, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            setOnClickListener { toggleControls() } // 点黑边也能呼出控制条
        }
        // VideoView 自带的点击呼出只在画面区域内有效，这里统一接管
        video.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP) toggleControls()
            true
        }
        setContentView(root)

        video.setOnPreparedListener { mp ->
            ready = true
            loading.visibility = View.GONE
            requestedOrientation = if (mp.videoHeight > mp.videoWidth)
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        video.setOnInfoListener { _, what, _ ->
            when (what) {
                MediaPlayer.MEDIA_INFO_BUFFERING_START -> loading.visibility = View.VISIBLE
                MediaPlayer.MEDIA_INFO_BUFFERING_END,
                MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START -> loading.visibility = View.GONE
            }
            false
        }
        video.setOnCompletionListener { controller.show(0) }
        video.setOnErrorListener { _, _, _ ->
            ready = false
            loading.visibility = View.GONE
            if (!isFinishing && !isDestroyed) showError()
            true // 已自行处理，不再弹系统的“无法播放此视频”
        }

        val headers = HashMap<String, String>()
        intent.getStringExtra(EXTRA_UA)?.let { headers["User-Agent"] = it }
        intent.getStringExtra(EXTRA_REFERER)?.let { headers["Referer"] = it }
        intent.getStringExtra(EXTRA_COOKIE)?.let { headers["Cookie"] = it }
        video.setVideoURI(Uri.parse(url), headers)
        video.start()
    }

    private fun toggleControls() {
        if (!ready) return
        if (controller.isShowing) controller.hide() else controller.show()
    }

    private fun showError() {
        AlertDialog.Builder(this)
            .setMessage("内置播放器无法播放这个资源（格式不支持，或链接需要登录 / 已过期）。")
            .setPositiveButton("用外部播放器") { _, _ ->
                try {
                    startActivity(
                        Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(url), "video/*")
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) // 本地文件(content://)需要授权
                    )
                } catch (e: ActivityNotFoundException) {
                    Toast.makeText(this, "没有可用的播放器", Toast.LENGTH_SHORT).show()
                }
                finish()
            }
            .setNegativeButton("关闭") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    override fun onPause() {
        super.onPause()
        if (!::video.isInitialized) return
        // 退到后台时 VideoView 会释放底层播放器，这里记下进度，回来后接着播
        wasPlaying = video.isPlaying
        if (ready) {
            val p = video.currentPosition
            if (p > 0) pos = p
        }
        video.pause()
    }

    override fun onResume() {
        super.onResume()
        if (!::video.isInitialized) return
        setImmersive(true)
        if (pos > 0) video.seekTo(pos)
        if (wasPlaying) video.start()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) setImmersive(true)
    }

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_UA = "ua"
        const val EXTRA_REFERER = "referer"
        const val EXTRA_COOKIE = "cookie"
    }
}
