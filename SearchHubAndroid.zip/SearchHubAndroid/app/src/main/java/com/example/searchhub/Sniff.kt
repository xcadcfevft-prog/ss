package com.example.searchhub

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import java.io.File
import java.util.concurrent.Executors

/** 嗅探到的一个资源，以及后台探测到的信息（大小 / 时长 / 分辨率 / 预览图）。字段由后台线程写、界面线程读。 */
class SniffItem(val url: String, val ext: String) {
    @Volatile var state = 0              // 0 未探测  1 探测中  2 已完成
    @Volatile var size = -1L             // 字节，未知 -1
    @Volatile var sizeEstimated = false  // m3u8 按码率×时长估算
    @Volatile var duration = -1.0        // 秒，未知 -1
    @Volatile var resolution: String? = null
    @Volatile var live = false
    @Volatile var encrypted = false
    @Volatile var segments = 0
    @Volatile var thumb: Bitmap? = null

    val isHls: Boolean get() = ext == "M3U8"
    val isMpd: Boolean get() = ext == "MPD"
    val isAudio: Boolean get() = ext in AUDIO

    companion object {
        val AUDIO = setOf("MP3", "M4A", "AAC", "OGG")
        val THUMBABLE = setOf("MP4", "WEBM", "MKV", "MOV", "M4V", "3GP", "M3U8")
    }
}

/**
 * 后台探测：直链用 Range 请求取大小、MediaMetadataRetriever 取时长/分辨率/预览帧；
 * m3u8 解析列表得到时长/分辨率/估算大小，再取第一个分片抽预览帧。全部尽力而为，失败只是少显示信息。
 */
class MediaProbe(
    private val cacheDir: File,
    private val headers: (String) -> Map<String, String>,
    private val onUpdate: () -> Unit
) {
    private val pool = Executors.newFixedThreadPool(3) { r -> Thread(r).apply { isDaemon = true } }

    fun probe(item: SniffItem) {
        if (item.state != 0) return
        item.state = 1
        pool.execute {
            try {
                val dl = HlsDownloader(headers)
                when {
                    item.isHls -> probeHls(dl, item)
                    item.isMpd -> {}
                    else -> probeFile(dl, item)
                }
            } catch (e: Throwable) {
                // 探测失败不影响播放和下载，只是少显示信息
            }
            item.state = 2
            onUpdate()
        }
    }

    private fun probeFile(dl: HlsDownloader, item: SniffItem) {
        item.size = try { dl.contentLength(item.url) } catch (e: Exception) { -1L }
        onUpdate()
        if (item.ext in SniffItem.THUMBABLE || item.isAudio) {
            grab(item, !item.isAudio) { r -> r.setDataSource(item.url, headers(item.url)) }
        }
    }

    private fun probeHls(dl: HlsDownloader, item: SniffItem) {
        val pl = dl.load(item.url)
        item.duration = if (pl.live) -1.0 else pl.durationSec
        item.resolution = pl.resolution
        item.live = pl.live
        item.segments = pl.segments.size
        item.encrypted = pl.segments[0].key != null
        if (pl.bandwidth > 0 && pl.durationSec > 0) {
            item.size = (pl.bandwidth / 8.0 * pl.durationSec).toLong()
            item.sizeEstimated = true
        }
        onUpdate()
        // 预览图：取（初始化段 +）第一个分片落到缓存目录，再抽一帧
        val f = File(cacheDir, "thumb_${item.url.hashCode()}.${pl.ext}")
        try {
            f.writeBytes(dl.firstChunk(pl))
            grab(item, true) { r -> r.setDataSource(f.absolutePath) }
        } catch (e: Throwable) {
            // 忽略
        } finally {
            f.delete()
        }
    }

    /** 用 MediaMetadataRetriever 补充时长 / 分辨率，并抽一帧作为预览图。任何异常都吞掉。 */
    private fun grab(item: SniffItem, wantFrame: Boolean, setup: (MediaMetadataRetriever) -> Unit) {
        val r = MediaMetadataRetriever()
        try {
            setup(r)
            if (item.duration <= 0 && !item.live) {
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?.let {
                    if (it > 0) item.duration = it / 1000.0
                }
            }
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            if (item.resolution == null && w > 0 && h > 0) item.resolution = "${w}x$h"
            if (wantFrame) {
                val atUs = if (item.duration > 0) minOf(1_000_000L, (item.duration * 500_000).toLong()) else 1_000_000L
                val frame = r.getFrameAtTime(atUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: r.getFrameAtTime(0L)
                if (frame != null && frame.width > 0 && frame.height > 0) {
                    val tw = 320
                    val th = maxOf(1, frame.height * tw / frame.width)
                    val scaled = Bitmap.createScaledBitmap(frame, tw, th, true)
                    if (scaled !== frame) frame.recycle()
                    item.thumb = scaled
                }
            }
        } catch (e: Throwable) {
            // 不支持的格式 / 网络失败：保持占位图
        } finally {
            try { r.release() } catch (e: Exception) { }
        }
        onUpdate()
    }
}
