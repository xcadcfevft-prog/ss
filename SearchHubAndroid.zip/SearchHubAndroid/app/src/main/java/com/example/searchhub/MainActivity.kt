package com.example.searchhub

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*

class MainActivity : Activity() {

    private val engines = linkedMapOf(
        "百度" to "https://www.baidu.com/s?wd=",
        "Google" to "https://www.google.com/search?q=",
        "Bing" to "https://www.bing.com/search?q=",
        "DuckDuckGo" to "https://duckduckgo.com/?q=",
        "搜狗" to "https://www.sogou.com/web?query=",
        "360" to "https://www.so.com/s?q=",
        "Yandex" to "https://yandex.com/search/?text=",
        "Brave" to "https://search.brave.com/search?q=",
        "Yahoo" to "https://search.yahoo.com/search?p="
    )
    // 嗅探规则：按 URL 扩展名识别媒体（思路同猫抓 / MediaGo）
    private val mediaRe = Regex("\\.(m3u8|mpd|mp4|flv|webm|mkv|mov|mp3|m4a|aac|ogg|f4v)$", RegexOption.IGNORE_CASE)
    // 这类文件名没有信息量（index.m3u8 之类），改用网页标题命名
    private val genericNameRe = Regex("(?i)^(index|playlist|master|main|video|media|stream|chunklist|manifest|prog_index|\\d+)$")

    private val items = mutableListOf<SniffItem>()
    private val infoCache = HashMap<String, SniffItem>()
    @Volatile private var pageUrl: String? = null
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            DownloadCenter.refresh()
            updateDownloadBtn()
            handler.postDelayed(this, 800)
        }
    }

    private lateinit var web: WebView
    private lateinit var input: EditText
    private lateinit var spinner: Spinner
    private lateinit var downloadBtn: Button
    private lateinit var root: FrameLayout
    private lateinit var chip: TextView
    private lateinit var sheetLayer: FrameLayout
    private lateinit var sheet: LinearLayout
    private lateinit var sheetTitle: TextView
    private lateinit var sniffAdapter: SniffAdapter
    private lateinit var prober: MediaProbe
    private lateinit var ua: String
    // 网页内置播放器（<video>）的全屏画面
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DownloadCenter.init(this)

        spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, engines.keys.toList())
        }
        input = EditText(this).apply {
            hint = "搜索或输入网址"
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setOnEditorActionListener { _, _, _ -> go(); true }
        }
        val goBtn = Button(this).apply { text = "搜索"; minWidth = 0; setOnClickListener { go() } }
        downloadBtn = Button(this).apply {
            text = "下载"; minWidth = 0
            setOnClickListener { startActivity(Intent(this@MainActivity, DownloadsActivity::class.java)) }
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(spinner)
            addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(goBtn)
            addView(downloadBtn)
        }

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            settings.userAgentString = settings.userAgentString.replace("; wv", "")
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    pageUrl = url
                    hideCustomView()
                    items.clear()
                    if (infoCache.size > 40) infoCache.clear()
                    refreshSniff()
                }
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    val uri = request?.url ?: return null
                    if (mediaRe.containsMatchIn(uri.path ?: "")) {
                        val u = uri.toString()
                        runOnUiThread { addSniff(u) }
                    }
                    return null // 不拦截，正常加载
                }
            }
            // 没有 WebChromeClient 时，网页播放器的全屏按钮点了没反应
            webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                    if (view == null || customView != null) { callback?.onCustomViewHidden(); return }
                    customView = view
                    customCallback = callback
                    view.setBackgroundColor(0xFF000000.toInt())
                    root.addView(view, FrameLayout.LayoutParams(-1, -1))
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    setImmersive(true)
                    updateChip()
                }
                override fun onHideCustomView() = hideCustomView()
            }
        }
        ua = web.settings.userAgentString
        prober = MediaProbe(cacheDir, { u -> headersFor(u) }) {
            runOnUiThread { sniffAdapter.notifyDataSetChanged() }
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bar)
            addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        buildSniffOverlay()
        // 外层 FrameLayout：悬浮提示、底部面板、网页全屏画面都叠在网页之上
        root = FrameLayout(this).apply {
            addView(content, FrameLayout.LayoutParams(-1, -1))
            addView(chip, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply {
                setMargins(dp(16), dp(16), dp(16), dp(28))
            })
            addView(sheetLayer, FrameLayout.LayoutParams(-1, -1))
        }
        setContentView(root)
        refreshSniff()
        updateDownloadBtn()
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    private fun go() {
        val v = input.text.toString().trim()
        if (v.isEmpty()) return
        val url = when {
            Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(v) -> v
            Regex("^[\\w-]+(\\.[\\w-]+)+(/\\S*)?$").matches(v) -> "https://$v"
            else -> engines.getValue(spinner.selectedItem as String) + Uri.encode(v)
        }
        web.loadUrl(url)
    }

    // ---------- 嗅探：数据 ----------

    private fun extOf(u: String) = (Uri.parse(u).path ?: "").substringAfterLast('.', "").uppercase()

    private fun addSniff(u: String) {
        if (items.any { it.url == u }) return
        val item = infoCache.getOrPut(u) { SniffItem(u, extOf(u)) }
        items.add(item)
        prober.probe(item)
        refreshSniff(bump = true)
    }

    private fun headersFor(u: String): Map<String, String> = DownloadCenter.headersFor(u, ua, pageUrl)

    /** 文件名：优先用 URL 里有意义的文件名，否则用网页标题。 */
    private fun fileBase(item: SniffItem): String {
        val seg = Uri.parse(item.url).lastPathSegment ?: ""
        val base = seg.substringBeforeLast('.', seg)
        val fromTitle = safeName(web.title ?: "")
        val name = if (base.length < 3 || genericNameRe.matches(base)) fromTitle else safeName(Uri.decode(base))
        return name.ifEmpty { fromTitle }.ifEmpty { Uri.parse(item.url).host ?: "video" }
    }

    // ---------- 嗅探：界面（悬浮提示 + 底部面板） ----------

    private fun buildSniffOverlay() {
        chip = TextView(this).apply {
            textSize = 14f
            setTextColor(Ui.WHITE)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = roundRect(Ui.PRIMARY, dp(22).toFloat())
            elevation = dp(6).toFloat()
            visibility = View.GONE
            setOnClickListener { showSheet() }
        }

        sheetTitle = TextView(this).apply {
            textSize = 16f
            setTextColor(Ui.TEXT)
            typeface = Typeface.DEFAULT_BOLD
        }
        val closeBtn = TextView(this).apply {
            text = "关闭"
            textSize = 14f
            setTextColor(Ui.PRIMARY)
            setPadding(dp(12), dp(8), dp(4), dp(8))
            setOnClickListener { hideSheet() }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setGravity(Gravity.CENTER_VERTICAL)
            setPadding(dp(16), dp(10), dp(12), dp(6))
            addView(sheetTitle, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(closeBtn)
        }

        sniffAdapter = SniffAdapter()
        val list = ListView(this).apply {
            divider = ColorDrawable(Ui.DIVIDER)
            dividerHeight = dp(1)
            setAdapter(sniffAdapter)
            setOnItemClickListener { _, _, i, _ -> if (i < items.size) play(items[i].url) }
        }
        val empty = TextView(this).apply {
            text = "暂未发现资源\n播放网页里的视频后，会自动出现在这里"
            gravity = Gravity.CENTER
            textSize = 13f
            setTextColor(Ui.TEXT_SUB)
        }
        list.emptyView = empty
        val body = FrameLayout(this).apply {
            addView(list, FrameLayout.LayoutParams(-1, -1))
            addView(empty, FrameLayout.LayoutParams(-1, -1))
        }

        sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundRect(Ui.WHITE, dp(16).toFloat(), topOnly = true)
            elevation = dp(12).toFloat()
            addView(header)
            addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        val scrim = View(this).apply {
            setBackgroundColor(0x66000000)
            setOnClickListener { hideSheet() }
        }
        sheetLayer = FrameLayout(this).apply {
            visibility = View.GONE
            addView(scrim, FrameLayout.LayoutParams(-1, -1))
            addView(sheet, FrameLayout.LayoutParams(-1, dp(420), Gravity.BOTTOM))
        }
    }

    private fun refreshSniff(bump: Boolean = false) {
        if (!::chip.isInitialized) return
        val n = items.size
        chip.text = "发现 $n 个资源"
        sheetTitle.text = "发现 $n 个资源"
        updateChip()
        sniffAdapter.notifyDataSetChanged()
        if (bump && chip.visibility == View.VISIBLE) {
            chip.animate().cancel()
            chip.animate().scaleX(1.12f).scaleY(1.12f).setDuration(120).withEndAction {
                chip.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }.start()
        }
    }

    /** 有资源、且没打开面板、没在全屏时，才显示悬浮提示。 */
    private fun updateChip() {
        if (!::chip.isInitialized) return
        val show = items.isNotEmpty() && sheetLayer.visibility != View.VISIBLE && customView == null
        chip.visibility = if (show) View.VISIBLE else View.GONE
    }

    private fun showSheet() {
        if (customView != null) return
        val lp = sheet.layoutParams as FrameLayout.LayoutParams
        lp.height = maxOf((root.height * 0.62f).toInt(), dp(260))
        sheet.layoutParams = lp
        sheetLayer.visibility = View.VISIBLE
        sheet.translationY = lp.height.toFloat()
        sheet.animate().translationY(0f).setDuration(200).start()
        updateChip()
    }

    private fun hideSheet() {
        if (sheetLayer.visibility != View.VISIBLE) return
        sheetLayer.visibility = View.GONE
        updateChip()
    }

    private fun updateDownloadBtn() {
        val n = DownloadCenter.activeCount()
        downloadBtn.text = if (n > 0) "下载 $n" else "下载"
    }

    private inner class SniffAdapter : BaseAdapter() {
        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView?.tag as? Row) ?: Row().also { it.root.tag = it }
            row.bind(items[position])
            return row.root
        }
    }

    /** 面板里的一张资源卡片：预览图 + 名称 + 类型/分辨率/大小 + 播放/下载/更多。 */
    private inner class Row {
        val ctx: Context = this@MainActivity
        var item: SniffItem? = null
        val thumb = ImageView(ctx).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        val ph = TextView(ctx).apply {
            gravity = Gravity.CENTER
            textSize = 15f
            setTextColor(Ui.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val dur = TextView(ctx).apply {
            textSize = 11f
            setTextColor(Ui.WHITE)
            setPadding(dp(4), dp(1), dp(4), dp(1))
            background = roundRect(0xAA000000.toInt(), dp(4).toFloat())
        }
        val title = TextView(ctx).apply {
            textSize = 14f
            setTextColor(Ui.TEXT)
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        val meta = TextView(ctx).apply {
            textSize = 12f
            setTextColor(Ui.TEXT_SUB)
        }
        val host = TextView(ctx).apply {
            textSize = 11f
            setTextColor(0xFFA0A5B3.toInt())
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val playBtn = ctx.pill("播放", Ui.PRIMARY, Ui.PRIMARY_LIGHT) { item?.let { play(it.url) } }
        val dlBtn = ctx.pill("下载", Ui.WHITE, Ui.PRIMARY) { item?.let { startDownload(it) } }
        val moreBtn = ctx.pill("更多", 0xFF555B6B.toInt(), 0xFFF0F1F4.toInt()) { item?.let { more(it) } }
        val root = LinearLayout(ctx)

        init {
            val thumbBox = FrameLayout(ctx).apply {
                background = roundRect(0xFF2A2F3A.toInt(), dp(8).toFloat())
                clipToOutline = true
                addView(thumb, FrameLayout.LayoutParams(-1, -1))
                addView(ph, FrameLayout.LayoutParams(-1, -1))
                addView(dur, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply {
                    setMargins(0, 0, dp(4), dp(4))
                })
            }
            val btns = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(playBtn)
                addView(dlBtn, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
                addView(moreBtn, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
            }
            val col = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                addView(title)
                addView(meta, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
                addView(host, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(1) })
                addView(btns, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
            }
            root.orientation = LinearLayout.HORIZONTAL
            root.setPadding(dp(12), dp(12), dp(12), dp(12))
            root.addView(thumbBox, LinearLayout.LayoutParams(dp(112), dp(64)))
            root.addView(col, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(12) })
        }

        fun bind(s: SniffItem) {
            item = s
            title.text = fileBase(s)
            val parts = ArrayList<String>()
            parts.add(s.ext)
            s.resolution?.let { parts.add(it) }
            if (s.live) parts.add("直播")
            if (s.size > 0) parts.add((if (s.sizeEstimated) "约 " else "") + formatSize(s.size))
            else if (s.segments > 0) parts.add("${s.segments} 个分片")
            if (s.encrypted) parts.add("已加密")
            if (s.state != 2) parts.add("读取信息中…")
            meta.text = parts.joinToString(" · ")
            host.text = Uri.parse(s.url).host ?: ""

            val bmp = s.thumb
            thumb.setImageBitmap(bmp)
            ph.visibility = if (bmp == null) View.VISIBLE else View.GONE
            ph.text = s.ext
            if (s.duration > 0 && !s.live) {
                dur.visibility = View.VISIBLE
                dur.text = formatDuration(s.duration)
            } else {
                dur.visibility = View.GONE
            }
            dlBtn.visibility = if (s.isMpd) View.GONE else View.VISIBLE
        }
    }

    // ---------- 嗅探：操作 ----------

    /** 全屏播放：交给 PlayerActivity，并带上网页的 UA / Referer / Cookie 以通过防盗链。 */
    private fun play(u: String) {
        // 先暂停网页自己的音视频，避免和全屏播放器同时出声
        web.evaluateJavascript("document.querySelectorAll('video,audio').forEach(function(m){m.pause()})", null)
        startActivity(Intent(this, PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_URL, u)
            putExtra(PlayerActivity.EXTRA_UA, ua)
            pageUrl?.let { putExtra(PlayerActivity.EXTRA_REFERER, it) }
            CookieManager.getInstance().getCookie(u)?.let { putExtra(PlayerActivity.EXTRA_COOKIE, it) }
        })
    }

    private fun more(item: SniffItem) {
        AlertDialog.Builder(this)
            .setTitle(item.ext)
            .setItems(arrayOf("复制链接", "用外部播放器打开")) { _, which ->
                when (which) {
                    0 -> {
                        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                            .setPrimaryClip(ClipData.newPlainText("url", item.url))
                        toast("已复制")
                    }
                    1 -> try {
                        startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(item.url), "video/*"))
                    } catch (e: ActivityNotFoundException) { toast("没有可用的播放器") }
                }
            }.show()
    }

    private fun startDownload(item: SniffItem) {
        if (item.isMpd) {
            toast("DASH(mpd) 暂不支持下载，请复制链接用 1DM 等应用下载")
            return
        }
        val base = fileBase(item)
        if (item.isHls) DownloadCenter.startHls(item.url, base, ua, pageUrl)
        else DownloadCenter.startDirect(item.url, "$base.${item.ext.lowercase()}", ua, pageUrl)
        updateDownloadBtn()
        toast("已加入下载，点右上角「下载」查看进度")
    }

    // ---------- 网页内置播放器全屏 ----------

    /** 退出网页内置播放器的全屏，恢复界面与屏幕方向。 */
    private fun hideCustomView() {
        val v = customView ?: return
        root.removeView(v)
        customView = null
        customCallback?.onCustomViewHidden()
        customCallback = null
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        setImmersive(false)
        updateChip()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when {
            customView != null -> hideCustomView() // 先退出全屏，再谈网页后退
            sheetLayer.visibility == View.VISIBLE -> hideSheet()
            web.canGoBack() -> web.goBack()
            else -> super.onBackPressed()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // 全屏中系统栏被临时唤出后失去焦点再回来时，重新隐藏
        if (hasFocus && customView != null) setImmersive(true)
    }
}
