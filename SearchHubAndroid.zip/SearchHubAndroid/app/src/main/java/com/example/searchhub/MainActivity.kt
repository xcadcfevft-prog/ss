package com.example.searchhub

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*

class MainActivity : Activity() {

    private val engines = linkedMapOf(
        "百度" to "https://www.baidu.com/s?wd=",
        "Google" to "https://www.google.com/search?q=",
        "Bing" to "https://www.bing.com/search?q=",
        "DuckDuckGo" to "https://duckduckgo.com/?q=",
        "搜狗" to "https://www.sogou.com/web?query=",
        "360" to "https://www.so.com/s?q=",
        "Yandex" to "https://yandex.com/search/?text=",
        "Brave" to "https://search.brave.com/search?q=",
        "Yahoo" to "https://search.yahoo.com/search?p="
    )
    // 嗅探规则：按 URL 扩展名识别媒体（思路同猫抓 / MediaGo）
    private val mediaRe = Regex("\\.(m3u8|mpd|mp4|flv|webm|mkv|mov|mp3|m4a|aac|ogg|f4v)$", RegexOption.IGNORE_CASE)
    private val streamRe = Regex("\\.(m3u8|mpd)$", RegexOption.IGNORE_CASE)

    private val items = mutableListOf<String>()
    private lateinit var web: WebView
    private lateinit var input: EditText
    private lateinit var spinner: Spinner
    private lateinit var sniffBtn: Button
    private lateinit var panel: ListView
    private lateinit var listAdapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density

        spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, engines.keys.toList())
        }
        input = EditText(this).apply {
            hint = "搜索或输入网址"
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setOnEditorActionListener { _, _, _ -> go(); true }
        }
        val goBtn = Button(this).apply { text = "搜索"; minWidth = 0; setOnClickListener { go() } }
        sniffBtn = Button(this).apply {
            text = "嗅探 0"; minWidth = 0
            setOnClickListener { panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(spinner)
            addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(goBtn)
            addView(sniffBtn)
        }

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            settings.userAgentString = settings.userAgentString.replace("; wv", "")
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    items.clear(); refresh()
                }
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    val uri = request?.url ?: return null
                    if (mediaRe.containsMatchIn(uri.path ?: "")) {
                        val u = uri.toString()
                        runOnUiThread { if (u !in items) { items.add(u); refresh() } }
                    }
                    return null // 不拦截，正常加载
                }
            }
        }

        listAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf<String>())
        panel = ListView(this).apply {
            visibility = View.GONE
            adapter = listAdapter
            setOnItemClickListener { _, _, i, _ -> menu(items[i]) }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bar)
            addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(panel, LinearLayout.LayoutParams(-1, (220 * dp).toInt()))
        })
        refresh()
    }

    private fun go() {
        val v = input.text.toString().trim()
        if (v.isEmpty()) return
        val url = when {
            Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(v) -> v
            Regex("^[\\w-]+(\\.[\\w-]+)+(/\\S*)?$").matches(v) -> "https://$v"
            else -> engines.getValue(spinner.selectedItem as String) + Uri.encode(v)
        }
        web.loadUrl(url)
    }

    private fun ext(u: String) = (Uri.parse(u).path ?: "").substringAfterLast('.', "").uppercase()

    private fun refresh() {
        sniffBtn.text = "嗅探 ${items.size}"
        listAdapter.clear()
        listAdapter.addAll(items.map { "${ext(it)}  $it" })
        if (items.size == 1) panel.visibility = View.VISIBLE
    }

    private fun menu(u: String) {
        AlertDialog.Builder(this)
            .setTitle(ext(u))
            .setItems(arrayOf("复制链接", "下载", "用外部播放器打开")) { _, which ->
                when (which) {
                    0 -> {
                        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                            .setPrimaryClip(ClipData.newPlainText("url", u))
                        toast("已复制")
                    }
                    1 -> download(u)
                    2 -> try {
                        startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(u), "video/*"))
                    } catch (e: ActivityNotFoundException) { toast("没有可用的播放器") }
                }
            }.show()
    }

    private fun download(u: String) {
        if (streamRe.containsMatchIn(Uri.parse(u).path ?: "")) {
            toast("流媒体请复制链接，用 VLC、1DM 等支持 m3u8 的应用下载")
            return
        }
        val req = DownloadManager.Request(Uri.parse(u))
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, Uri.parse(u).lastPathSegment ?: "video.mp4")
            .addRequestHeader("User-Agent", web.settings.userAgentString)
        web.url?.let { req.addRequestHeader("Referer", it) }
        CookieManager.getInstance().getCookie(u)?.let { req.addRequestHeader("Cookie", it) }
        (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
        toast("已开始下载，见通知栏")
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
