package com.example.searchhub

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.TextView
import java.util.Locale

/** 界面用到的颜色与小工具（全部用代码绘制，不依赖资源文件）。 */
object Ui {
    val PRIMARY: Int = 0xFF2F6BFF.toInt()
    val PRIMARY_LIGHT: Int = 0xFFE8F0FF.toInt()
    val GREEN: Int = 0xFF1E9E57.toInt()
    val GREEN_LIGHT: Int = 0xFFE3F5EA.toInt()
    val RED: Int = 0xFFD93025.toInt()
    val RED_LIGHT: Int = 0xFFFDE8E7.toInt()
    val ORANGE: Int = 0xFFF28B1C.toInt()
    val TEXT: Int = 0xFF1A1C22.toInt()
    val TEXT_SUB: Int = 0xFF6B7080.toInt()
    val DIVIDER: Int = 0xFFEDEEF2.toInt()
    val WHITE: Int = 0xFFFFFFFF.toInt()
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun roundRect(color: Int, radius: Float, topOnly: Boolean = false): GradientDrawable {
    val d = GradientDrawable()
    d.setColor(color)
    if (topOnly) d.setCornerRadii(floatArrayOf(radius, radius, radius, radius, 0f, 0f, 0f, 0f))
    else d.setCornerRadius(radius)
    return d
}

/** 圆角小按钮（文字 + 底色）。 */
fun Context.pill(text: String, fg: Int, bg: Int, onClick: () -> Unit): TextView {
    val t = TextView(this)
    t.text = text
    t.setTextColor(fg)
    t.textSize = 13f
    t.gravity = Gravity.CENTER
    t.setPadding(dp(14), dp(6), dp(14), dp(6))
    t.background = roundRect(bg, dp(15).toFloat())
    t.setOnClickListener { onClick() }
    return t
}

/** 去掉文件名里的非法字符并限制长度。 */
fun safeName(s: String): String =
    s.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").trim().take(60).trim('.', ' ')

fun formatSize(b: Long): String {
    if (b < 0) return "未知大小"
    val k = 1024.0
    return when {
        b < 1024 -> "$b B"
        b < 1024L * 1024 -> String.format(Locale.US, "%.1f KB", b / k)
        b < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", b / k / k)
        else -> String.format(Locale.US, "%.2f GB", b / k / k / k)
    }
}

fun formatDuration(sec: Double): String {
    val s = sec.toLong()
    val h = s / 3600
    val m = s % 3600 / 60
    val ss = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, ss)
    else String.format(Locale.US, "%02d:%02d", m, ss)
}

/** 细进度条。fraction < 0 表示进度未知（画一条半透明满条）。 */
class ProgressLine(ctx: Context) : View(ctx) {
    var fraction: Float = 0f
    var color: Int = Ui.PRIMARY
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f
        paint.color = 0xFFE6E8EE.toInt()
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, r, r, paint)
        paint.color = color
        if (fraction < 0f) {
            paint.alpha = 90
            canvas.drawRoundRect(rect, r, r, paint)
            paint.alpha = 255
        } else if (fraction > 0f) {
            rect.set(0f, 0f, maxOf(h, w * minOf(fraction, 1f)), h)
            canvas.drawRoundRect(rect, r, r, paint)
        }
    }
}
