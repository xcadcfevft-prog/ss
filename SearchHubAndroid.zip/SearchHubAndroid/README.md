# SearchHub (Android)
极简多引擎搜索 + 网页视频嗅探。无第三方依赖，纯系统 WebView。
构建：GitHub Actions，`gradle :app:assembleDebug`（Gradle 8.9 / AGP 8.7.3 / JDK 17）。
