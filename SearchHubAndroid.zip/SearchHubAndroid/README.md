# SearchHub (Android)
极简多引擎搜索 + 网页视频嗅探。无第三方依赖，纯系统 WebView。
构建：GitHub Actions，`gradle :app:assembleDebug`（Gradle 8.9 / AGP 8.7.3 / JDK 17）。

## 嗅探（仿主流浏览器）
- 页面里发现媒体资源时，右下角出现悬浮提示「发现 N 个资源」，点击展开底部面板。
- 每个资源一张卡片：预览图、时长、类型 / 分辨率 / 大小（m3u8 为按码率估算）、「播放 / 下载 / 更多」。
  信息由 `MediaProbe` 后台探测（Range 取大小、MediaMetadataRetriever 抽帧；m3u8 解析列表并取首片段抽帧），失败只是少显示信息。
- 点卡片或「播放」：`PlayerActivity` 全屏播放（系统 VideoView，横屏沉浸式，竖屏视频自动转竖屏，自动带 UA / Referer / Cookie）。
  系统播放器不支持的格式（如 mpd / flv）会提示并可转外部播放器。

## 下载 / 查看下载
- 右上角「下载」进入下载管理页（有任务时显示进行中的数量）：进度条、速度、状态；
  点条目可 播放 / 用其他应用打开 / 取消 / 重试 / 删除 / 复制来源链接；「更多」可清理记录、打开系统下载目录。
- 任务记录持久化（SharedPreferences），重启应用后仍在。逻辑集中在 `DownloadCenter`。
- 直链（mp4 / webm / mp3 …）：系统 DownloadManager，通知栏也有进度，可在后台下载。
- m3u8：`HlsDownloader` 解析后顺序下载并拼接分片，存到「下载」目录（TS → `.ts`，fMP4 → `.mp4`）。
  支持主列表选最高码率、AES-128、重定向；不支持 SAMPLE-AES/DRM、BYTERANGE、独立音轨。
  应用被系统结束时下载会中断（记录会标记为失败，可重试），所以下载 m3u8 时请保持应用在前台。
- mpd(DASH)：暂不支持下载，请复制链接用其他应用。

## 网页内置播放器全屏
网页里 `<video>` 的全屏按钮可用：横屏沉浸式，返回键先退出全屏（`WebChromeClient.onShowCustomView`）。
