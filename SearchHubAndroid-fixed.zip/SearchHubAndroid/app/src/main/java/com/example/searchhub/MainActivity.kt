package com.example.searchhub

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.InputMethodManager
import android.webkit.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    companion object {
        private const val REQ_FILE = 11
        private const val REQ_LIB = 12
        private const val PAUSE_JS = "document.querySelectorAll('video,audio').forEach(function(m){m.pause()})"
    }

    private val engines = linkedMapOf(
        "百度" to "https://www.baidu.com/s?wd=",
        "Google" to "https://www.google.com/search?q=",
        "Bing" to "https://www.bing.com/search?q=",
        "DuckDuckGo" to "https://duckduckgo.com/?q=",
        "搜狗" to "https://www.sogou.com/web?query=",
        "360" to "https://www.so.com/s?q=",
        "Yandex" to "https://yandex.com/search/?text=",
        "Brave" to "https://search.brave.com/search?q=",
        "Yahoo" to "https://search.yahoo.com/search?p="
    )
    // 嗅探规则：按 URL 扩展名识别媒体（思路同猫抓 / MediaGo）
    private val mediaRe = Regex("\\.(m3u8|mpd|mp4|flv|webm|mkv|mov|mp3|m4a|aac|ogg|f4v)$", RegexOption.IGNORE_CASE)
    // 这类文件名没有信息量（index.m3u8 之类），改用网页标题命名
    private val genericNameRe = Regex("(?i)^(index|playlist|master|main|video|media|stream|chunklist|manifest|prog_index|\\d+)$")
    private val urlRe = Regex("^([\\p{L}\\p{N}_-]+\\.)+\\p{L}[\\p{L}\\p{N}-]*(:\\d+)?(/\\S*)?$")
    private val hostRe = Regex("^(localhost|\\d{1,3}(\\.\\d{1,3}){3})(:\\d+)?(/\\S*)?$")
    private val palette = listOf(
        0xFFE8F0FF.toInt() to 0xFF2F6BFF.toInt(),
        0xFFE3F5EA.toInt() to 0xFF1E9E57.toInt(),
        0xFFFDE8E7.toInt() to 0xFFD93025.toInt(),
        0xFFFFF1E0.toInt() to 0xFFF28B1C.toInt(),
        0xFFF0E8FF.toInt() to 0xFF7B4DFF.toInt(),
        0xFFE0F5F7.toInt() to 0xFF0E8CA0.toInt()
    )

    private val items = mutableListOf<SniffItem>()
    private val infoCache = HashMap<String, SniffItem>()
    private lateinit var finder: QualityFinder
    private val upgraded = HashMap<String, String>()   // 原始地址 -> 找到的更高画质地址
    private val finderTried = HashSet<String>()
    @Volatile private var pageUrl: String? = null
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            DownloadCenter.refresh()
            updateDownloadBtn()
            handler.postDelayed(this, 800)
        }
    }
    // 长按链接 / 图片时，WebView 通过它把链接地址回传
    private val hrefHandler = Handler(Looper.getMainLooper(), Handler.Callback { m ->
        val d = m.data
        showLinkMenu(d?.getString("url"), d?.getString("src"))
        true
    })

    private lateinit var web: WebView
    private lateinit var content: LinearLayout
    private lateinit var urlBar: EditText
    private lateinit var siteIcon: IconView
    private lateinit var actionBtn: FrameLayout
    private lateinit var progressBar: View
    private lateinit var bottomBar: LinearLayout
    private lateinit var backBtn: FrameLayout
    private lateinit var fwdBtn: FrameLayout
    private lateinit var dlBtn: FrameLayout
    private lateinit var dlBadge: TextView
    private lateinit var overlayPane: LinearLayout
    private lateinit var engineRow: LinearLayout
    private lateinit var homeScroll: ScrollView
    private lateinit var homeBody: LinearLayout
    private lateinit var suggestScroll: ScrollView
    private lateinit var suggestBox: LinearLayout
    private lateinit var findBar: LinearLayout
    private lateinit var findInput: EditText
    private lateinit var findCount: TextView
    private lateinit var homeBtn: FrameLayout
    private lateinit var menu: SheetLayer      // 「更多」菜单
    private lateinit var actions: SheetLayer   // 链接操作 / 确认框
    private lateinit var sniff: SheetLayer     // 嗅探到的资源列表
    private lateinit var toastView: TextView
    private lateinit var root: FrameLayout
    private lateinit var ball: FloatingBall
    private lateinit var dlSheet: DownloadSheet
    private lateinit var sheetTitle: TextView
    private lateinit var sniffAdapter: SniffAdapter
    private lateinit var prober: MediaProbe
    private lateinit var ua: String
    private lateinit var mobileUa: String
    private lateinit var desktopUa: String
    private val prefs by lazy { getSharedPreferences("browser_ui", Context.MODE_PRIVATE) }

    private var engine = "百度"
    private var onHome = true          // 正在显示起始页
    private var editing = false        // 地址栏正在输入
    private var loading = false
    private var desktop = false
    private var settingText = false    // 程序在改地址栏文字，TextWatcher 要忽略
    private var pending: String? = null // 刚发起、还没开始加载的网址，用于地址栏即时显示
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private val hideToast = Runnable {
        toastView.animate().alpha(0f).translationY(dp(8).toFloat()).setDuration(200)
            .withEndAction { toastView.visibility = View.GONE }.start()
    }
    // 网页内置播放器（<video>）的全屏画面
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(Ui.CHROME))   // 启动时不闪白
        DownloadCenter.init(this)
        Store.init(this)
        engine = prefs.getString("engine", null)?.takeIf { it in engines } ?: "百度"

        buildWeb()
        buildTopBar()
        buildOverlay()
        buildBottomBar()
        buildFindBar()

        val progressHolder = FrameLayout(this)
        progressBar = View(this).apply {
            // 靛青 → 紫的细渐变条，是整个界面里唯一"会动的色彩"
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xFF7C93FF.toInt(), Ui.PRIMARY, 0xFFB46CFF.toInt())
            )
            pivotX = 0f
            scaleX = 0f
            visibility = View.GONE
        }
        progressHolder.addView(progressBar, FrameLayout.LayoutParams(-1, dp(3)))
        val webArea = FrameLayout(this).apply {
            addView(web, FrameLayout.LayoutParams(-1, -1))
            addView(overlayPane, FrameLayout.LayoutParams(-1, -1))
            addView(progressHolder, FrameLayout.LayoutParams(-1, dp(3), Gravity.TOP))
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.CHROME)
            // 让它在启动时持有焦点，避免地址栏自动弹出键盘
            isFocusable = true
            isFocusableInTouchMode = true
            addView(topBarView())
            addView(webArea, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(findBar)
            addView(bottomBar)
        }

        buildSheets()
        buildSniffOverlay()
        // 外层 FrameLayout：悬浮球、底部面板、网页全屏画面都叠在网页之上
        root = FrameLayout(this).apply {
            addView(content, FrameLayout.LayoutParams(-1, -1))
            // 悬浮球的具体位置由它自己用 x / y 摆放（可拖动），这里只给尺寸并固定在左上角做原点
            addView(ball, FrameLayout.LayoutParams(ball.sizePx, ball.sizePx, Gravity.TOP or Gravity.LEFT))
            addView(sniff.layer, FrameLayout.LayoutParams(-1, -1))
            addView(menu.layer, FrameLayout.LayoutParams(-1, -1))
        }
        // 「下载此文件」面板叠在资源列表之上
        dlSheet = DownloadSheet(
            this, root, { ua }, { pageUrl }, { fileBase(it) }, { u -> play(u) }
        ) {
            hideSheet()
            updateDownloadBtn()
        }
        root.addView(dlSheet.layer, FrameLayout.LayoutParams(-1, -1))
        root.addView(actions.layer, FrameLayout.LayoutParams(-1, -1))
        toastView = TextView(this).apply {
            textSize = 13f
            typeface = Ui.MEDIUM
            setTextColor(Ui.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(11), dp(18), dp(11))
            background = roundRect(0xF2181B22.toInt(), dp(22).toFloat())
            elevation = dp(10).toFloat()
            visibility = View.GONE
        }
        root.addView(toastView, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(84)
        })
        setContentView(root)
        lightBars(Ui.CHROME)

        buildHome()
        applyOverlay("")
        updateChrome()
        refreshSniff()
        updateDownloadBtn()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action != Intent.ACTION_VIEW) return
        val u = i.dataString ?: return
        if (u.startsWith("http", true)) load(u)
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
        if (onHome) buildHome()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
        CookieManager.getInstance().flush()
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        web.destroy()
        super.onDestroy()
    }

    // ---------- WebView ----------

    private fun buildWeb() {
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            settings.useWideViewPort = true
            settings.setSupportZoom(true)
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            settings.mediaPlaybackRequiresUserGesture = true
            settings.userAgentString = settings.userAgentString.replace("; wv", "")
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    pageUrl = url
                    pending = null
                    loading = true
                    hideCustomView()
                    closeFind()
                    items.clear()
                    if (infoCache.size > 40) infoCache.clear()
                    refreshSniff()
                    updateChrome()
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    loading = false
                    if (url != null && url != "about:blank") Store.addHistory(view?.title ?: "", url)
                    updateChrome()
                }

                override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                    if (url != null) pageUrl = url
                    updateChrome()
                }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val u = request?.url ?: return false
                    val scheme = u.scheme?.lowercase() ?: return false
                    if (scheme == "http" || scheme == "https" || scheme == "about" || scheme == "data" || scheme == "blob") return false
                    // 电话 / 邮件 / 短信 / 地图交给系统；其它自定义协议（打开 App 的跳转）一律拦下，避免被网页拉起别的应用
                    if (scheme == "tel" || scheme == "mailto" || scheme == "sms" || scheme == "geo") {
                        try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (e: ActivityNotFoundException) { }
                    }
                    return true
                }

                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    val uri = request?.url ?: return null
                    if (mediaRe.containsMatchIn(uri.path ?: "")) {
                        val u = uri.toString()
                        runOnUiThread { addSniff(u) }
                    }
                    return null // 不拦截，正常加载
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    loading = newProgress < 100
                    showProgress(newProgress)
                    updateActionIcon()
                }

                // 没有这个回调时，网页播放器的全屏按钮点了没反应
                override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                    if (view == null || customView != null) { callback?.onCustomViewHidden(); return }
                    customView = view
                    customCallback = callback
                    view.setBackgroundColor(0xFF000000.toInt())
                    root.addView(view, FrameLayout.LayoutParams(-1, -1))
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    setImmersive(true)
                    updateBall()
                }

                override fun onHideCustomView() = hideCustomView()

                // 网页里的「选择文件」（上传头像 / 附件等）
                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: WebChromeClient.FileChooserParams?
                ): Boolean {
                    fileCb?.onReceiveValue(null)
                    fileCb = filePathCallback
                    val intent = fileChooserParams?.createIntent()
                    if (intent == null) { fileCb = null; return false }
                    return try {
                        startActivityForResult(intent, REQ_FILE)
                        true
                    } catch (e: Exception) {
                        fileCb?.onReceiveValue(null)
                        fileCb = null
                        false
                    }
                }
            }

            // 网页触发的下载（附件、安装包、压缩包等）
            setDownloadListener { url, _, contentDisposition, mime, _ ->
                askDownload(url, URLUtil.guessFileName(url, contentDisposition, mime))
            }

            // 长按链接 / 图片
            setOnLongClickListener {
                val r = hitTestResult
                when (r.type) {
                    WebView.HitTestResult.SRC_ANCHOR_TYPE, WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                        requestFocusNodeHref(hrefHandler.obtainMessage())
                        true
                    }
                    WebView.HitTestResult.IMAGE_TYPE -> { showLinkMenu(null, r.extra); true }
                    else -> false
                }
            }
        }
        mobileUa = web.settings.userAgentString
        desktopUa = mobileUa
            .replace(Regex("\\(Linux; Android[^)]*\\)"), "(X11; Linux x86_64)")
            .replace(" Mobile Safari", " Safari")
        ua = mobileUa
        prober = MediaProbe(cacheDir, { u -> headersFor(u) }) {
            runOnUiThread {
                sniffAdapter.notifyDataSetChanged()
                if (::dlSheet.isInitialized) dlSheet.refresh()
            }
        }
        finder = QualityFinder { u -> headersFor(u) }
    }

    // ---------- 地址栏 ----------

    private lateinit var topBar: LinearLayout
    private lateinit var pillBox: LinearLayout
    private fun topBarView(): View = topBar

    /** 地址栏胶囊的底：白色；输入时描一圈靛青细边，表示"正在输入"。 */
    private fun pillBg(focused: Boolean): GradientDrawable =
        roundRect(Ui.WHITE, dp(23).toFloat()).also { if (focused) it.setStroke(dp(1), Ui.PRIMARY) }

    private fun buildTopBar() {
        siteIcon = IconView(this, IconView.Kind.SEARCH, Ui.ICON_DIM)
        urlBar = EditText(this).apply {
            background = null
            hint = "搜索或输入网址"
            textSize = 15f
            setTextColor(Ui.TEXT)
            setHintTextColor(Ui.ICON_DIM)
            isSingleLine = true
            setPadding(0, 0, 0, 0)
            imeOptions = EditorInfo.IME_ACTION_GO
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSelectAllOnFocus(true)
            setOnFocusChangeListener { _, has -> if (has) enterEdit() else exitEdit() }
            setOnEditorActionListener { _, _, _ -> go(text.toString()); true }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    if (editing && !settingText) applyOverlay(s?.toString() ?: "")
                }
            })
        }
        actionBtn = iconButton(IconView.Kind.REFRESH, 40, 20) {
            when {
                editing -> urlBar.setText("")
                loading -> { web.stopLoading(); loading = false; hideProgress(); updateActionIcon() }
                else -> web.reload()
            }
        }
        // 白色胶囊悬浮在浅灰蓝的外框上，靠一点点投影而不是边框来区分层次
        pillBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = pillBg(false)
            elevation = dp(3).toFloat()
            setPadding(dp(16), 0, dp(4), 0)
            addView(siteIcon, LinearLayout.LayoutParams(dp(16), dp(16)).apply { rightMargin = dp(10) })
            addView(urlBar, LinearLayout.LayoutParams(0, -2, 1f))
            addView(actionBtn, LinearLayout.LayoutParams(dp(40), dp(40)))
        }
        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.CHROME)
            setPadding(dp(12), dp(8), dp(12), dp(10))
            addView(pillBox, LinearLayout.LayoutParams(-1, dp(46)))
        }
    }

    private fun enterEdit() {
        editing = true
        pillBox.background = pillBg(true)
        setBarText(if (onHome) "" else (web.url ?: ""))
        urlBar.post { urlBar.selectAll() }
        bottomBar.visibility = View.GONE
        siteIcon.kind = IconView.Kind.SEARCH
        siteIcon.tint = Ui.PRIMARY
        applyOverlay("")
        updateActionIcon()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(urlBar, 0)
    }

    private fun exitEdit() {
        editing = false
        pillBox.background = pillBg(false)
        hideKeyboard()
        bottomBar.visibility = View.VISIBLE
        applyOverlay("")
        updateChrome()
    }

    private fun stopEditing() {
        content.requestFocus()   // 焦点离开地址栏 → exitEdit()
    }

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(window.decorView.windowToken, 0)
    }

    private fun setBarText(t: String) {
        if (urlBar.text.toString() == t) return
        settingText = true
        urlBar.setText(t)
        settingText = false
    }

    private fun display(url: String?): String {
        if (url.isNullOrEmpty() || url == "about:blank") return ""
        return Uri.parse(url).host?.removePrefix("www.") ?: url
    }

    /** 加载进度：平滑地推进，完成时先走满再淡出，而不是"啪"地消失。 */
    private fun showProgress(p: Int) {
        if (p in 1..99) {
            val target = maxOf(p, 8) / 100f
            if (progressBar.visibility != View.VISIBLE || progressBar.alpha < 1f) {
                progressBar.animate().cancel()
                progressBar.alpha = 1f
                progressBar.scaleX = 0f
                progressBar.visibility = View.VISIBLE
            }
            progressBar.animate().scaleX(target).setDuration(240)
                .setInterpolator(DecelerateInterpolator()).start()
        } else {
            if (progressBar.visibility != View.VISIBLE) return
            progressBar.animate().cancel()
            progressBar.animate().scaleX(1f).setDuration(160).withEndAction {
                progressBar.animate().alpha(0f).setDuration(260).withEndAction {
                    progressBar.visibility = View.GONE
                    progressBar.scaleX = 0f
                    progressBar.alpha = 1f
                }.start()
            }.start()
        }
    }

    private fun hideProgress() {
        progressBar.animate().cancel()
        progressBar.visibility = View.GONE
        progressBar.scaleX = 0f
        progressBar.alpha = 1f
    }

    /** 网页状态变化后，统一刷新地址栏、图标、导航按钮。 */
    private fun updateChrome() {
        if (!::urlBar.isInitialized || !::backBtn.isInitialized || !::homeBtn.isInitialized) return
        val cur = pending ?: web.url
        if (!editing) {
            setBarText(if (onHome) "" else display(cur))
            val c = cur ?: ""
            siteIcon.kind = when {
                onHome || c.isEmpty() -> IconView.Kind.SEARCH
                c.startsWith("https") -> IconView.Kind.LOCK
                else -> IconView.Kind.GLOBE
            }
            siteIcon.tint = if (!onHome && c.startsWith("http:")) Ui.ORANGE else Ui.ICON_DIM
        }
        val canBack = !(onHome && web.url == null)
        backBtn.animate().alpha(if (canBack) 1f else 0.3f).setDuration(150).start()
        fwdBtn.animate().alpha(if (!onHome && web.canGoForward()) 1f else 0.3f).setDuration(150).start()
        homeBtn.iconView.tint = if (onHome) Ui.PRIMARY else Ui.ICON
        updateActionIcon()
    }

    private fun updateActionIcon() {
        if (!::actionBtn.isInitialized) return
        val k = when {
            editing -> IconView.Kind.CLEAR
            loading -> IconView.Kind.STOP
            else -> IconView.Kind.REFRESH
        }
        actionBtn.iconView.kind = k
        actionBtn.visibility = if (onHome && !editing) View.INVISIBLE else View.VISIBLE
    }

    // ---------- 导航 ----------

    private fun looksLikeUrl(v: String) =
        Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(v) || hostRe.matches(v) || urlRe.matches(v)

    private fun resolve(v: String): String = when {
        Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(v) -> v
        hostRe.matches(v) -> "http://$v"
        urlRe.matches(v) -> "https://$v"
        else -> engines.getValue(engine) + Uri.encode(v)
    }

    private fun go(raw: String) {
        val v = raw.trim()
        if (v.isEmpty()) return
        load(resolve(v))
    }

    private fun load(url: String) {
        onHome = false
        pending = url
        stopEditing()
        web.loadUrl(url)
        applyOverlay("")
        updateChrome()
    }

    private fun showHome() {
        web.evaluateJavascript(PAUSE_JS, null)
        onHome = true
        closeFind()
        buildHome()
        homeScroll.scrollTo(0, 0)
        stopEditing()
        applyOverlay("")
        updateChrome()
    }

    private fun showPage() {
        onHome = false
        stopEditing()
        applyOverlay("")
        updateChrome()
    }

    private fun goBack() {
        when {
            onHome && web.url != null -> showPage()
            !onHome && web.canGoBack() -> web.goBack()
            !onHome -> showHome()
        }
    }

    private fun goForward() {
        if (!onHome && web.canGoForward()) web.goForward()
    }

    // ---------- 起始页 / 搜索建议 ----------

    private fun buildOverlay() {
        engineRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(6), dp(16), dp(10))
        }
        val engineScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(engineRow, FrameLayout.LayoutParams(-2, -2))
        }
        homeBody = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(32))
        }
        homeScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(homeBody, FrameLayout.LayoutParams(-1, -2))
        }
        // 搜索建议收在一张白色圆角卡片里，行与行之间只有一条缩进的细线
        suggestBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundRect(Ui.WHITE, dp(20).toFloat())
            clipToOutline = true
        }
        suggestScroll = ScrollView(this).apply {
            visibility = View.GONE
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(suggestBox, FrameLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(2), dp(12), dp(16)) })
        }
        val switcher = FrameLayout(this).apply {
            addView(homeScroll, FrameLayout.LayoutParams(-1, -1))
            addView(suggestScroll, FrameLayout.LayoutParams(-1, -1))
        }
        overlayPane = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = homeBackdrop()
            isClickable = true   // 不让触摸穿透到下面的网页
            addView(engineScroll, LinearLayout.LayoutParams(-1, -2))
            addView(switcher, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        buildEngineChips()
    }

    /** 起始页底色：冷灰白打底，右上一团极淡的靛蓝、左侧一团极淡的珊瑚色光晕。 */
    private fun homeBackdrop(): LayerDrawable {
        fun glow(color: Int, cx: Float, cy: Float, radiusDp: Int): Drawable = GradientDrawable().apply {
            setGradientType(GradientDrawable.RADIAL_GRADIENT)
            setGradientRadius(dp(radiusDp).toFloat())
            setGradientCenter(cx, cy)
            setColors(intArrayOf(color, color and 0x00FFFFFF))
        }
        return LayerDrawable(arrayOf<Drawable>(
            ColorDrawable(Ui.CHROME),
            glow(0x2E5B73FF, 0.88f, 0.30f, 360),
            glow(0x26FF9A8B, 0.0f, 0.60f, 300)
        ))
    }

    private fun buildEngineChips() {
        engineRow.removeAllViews()
        for (name in engines.keys) {
            val on = name == engine
            val chip = TextView(this).apply {
                text = name
                textSize = 13f
                typeface = if (on) Ui.MEDIUM else Typeface.DEFAULT
                gravity = Gravity.CENTER
                setTextColor(if (on) Ui.WHITE else Ui.TEXT_SUB)
                // 选中的搜索引擎是墨色实心，其余是白色，不再用主色去抢视线
                background = rippleOf(roundRect(if (on) Ui.TEXT else Ui.WHITE, dp(16).toFloat()), dp(16).toFloat())
                setPadding(dp(14), 0, dp(14), 0)
                pressFeedback(0.95f)
                setOnClickListener {
                    engine = name
                    prefs.edit().putString("engine", name).apply()
                    buildEngineChips()
                    if (editing) applyOverlay(urlBar.text.toString())
                }
            }
            engineRow.addView(chip, LinearLayout.LayoutParams(-2, dp(32)).apply { rightMargin = dp(8) })
        }
    }

    /** 起始页只在没打开网页、或正在输入时显示；出现 / 消失时淡入淡出。 */
    private fun applyOverlay(q: String) {
        if (!::overlayPane.isInitialized) return
        val showSuggest = editing && q.isNotBlank()
        val show = onHome || editing
        if (show) {
            if (overlayPane.visibility != View.VISIBLE) {
                overlayPane.animate().cancel()
                overlayPane.alpha = 0f
                overlayPane.visibility = View.VISIBLE
                overlayPane.animate().alpha(1f).setDuration(160).start()
            } else if (overlayPane.alpha < 1f) {
                overlayPane.animate().cancel()
                overlayPane.animate().alpha(1f).setDuration(120).start()
            }
        } else if (overlayPane.visibility == View.VISIBLE) {
            overlayPane.animate().cancel()
            overlayPane.animate().alpha(0f).setDuration(140).withEndAction {
                if (!(onHome || editing)) overlayPane.visibility = View.GONE
                overlayPane.alpha = 1f
            }.start()
        }
        homeScroll.visibility = if (showSuggest) View.GONE else View.VISIBLE
        suggestScroll.visibility = if (showSuggest) View.VISIBLE else View.GONE
        if (showSuggest) buildSuggestions(q.trim())
        updateBall()
    }

    private fun buildSuggestions(q: String) {
        suggestBox.removeAllViews()
        val rows = ArrayList<View>()
        if (looksLikeUrl(q)) rows.add(suggestRow(IconView.Kind.GLOBE, "打开 $q", "直接访问", accent = true) { go(q) })
        else rows.add(suggestRow(IconView.Kind.SEARCH, q, "用 $engine 搜索", accent = true) { go(q) })
        for (e in Store.suggest(q)) {
            val host = Uri.parse(e.url).host ?: e.url
            rows.add(suggestRow(IconView.Kind.HISTORY, e.title.ifBlank { host }, host) { load(e.url) })
        }
        addRows(suggestBox, rows)
    }

    /** 把若干行放进容器，行与行之间画一条缩进的细分隔线。 */
    private fun addRows(box: LinearLayout, rows: List<View>) {
        rows.forEachIndexed { i, r ->
            if (i > 0) {
                box.addView(View(this).apply { setBackgroundColor(Ui.DIVIDER) },
                    LinearLayout.LayoutParams(-1, 1).apply { leftMargin = dp(54) })
            }
            box.addView(r)
        }
    }

    private fun suggestRow(kind: IconView.Kind, title: String, sub: String, accent: Boolean = false, onClick: () -> Unit): View {
        val t = TextView(this).apply {
            text = title
            textSize = 15f
            setTextColor(Ui.TEXT)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val s = TextView(this).apply {
            text = sub
            textSize = 12f
            setTextColor(Ui.TEXT_SUB)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(t)
            addView(s, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(1) })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(11), dp(16), dp(11))
            background = rippleOf(null)
            addView(IconView(this@MainActivity, kind, if (accent) Ui.PRIMARY else Ui.ICON_DIM), LinearLayout.LayoutParams(dp(20), dp(20)))
            addView(col, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(16) })
            setOnClickListener { onClick() }
        }
    }

    private fun greeting(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when {
            h < 5 -> "夜深了"
            h < 11 -> "早上好"
            h < 14 -> "中午好"
            h < 18 -> "下午好"
            else -> "晚上好"
        }
    }

    private fun buildHome() {
        homeBody.removeAllViews()
        val marks = Store.bookmarks()
        val hist = Store.history().take(6)

        // 起始页唯一的"装饰"：衬线体的问候语 + 一行小字日期
        homeBody.addView(TextView(this).apply {
            text = greeting()
            textSize = 30f
            typeface = Ui.DISPLAY
            setTextColor(Ui.TEXT)
            setPadding(dp(2), dp(14), 0, 0)
        })
        homeBody.addView(TextView(this).apply {
            text = SimpleDateFormat("M月d日 EEEE", Locale.CHINA).format(Date())
            textSize = 13f
            setTextColor(Ui.TEXT_SUB)
            setPadding(dp(2), dp(4), 0, dp(20))
        })

        if (marks.isNotEmpty()) {
            homeBody.addView(sectionTitle("常用网站", if (marks.size > 12) "全部" else null) { openLibrary(0) })
            val shown = marks.take(12)
            var i = 0
            while (i < shown.size) {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                for (k in 0 until 4) {
                    val e = shown.getOrNull(i + k)
                    row.addView(if (e != null) shortcut(e) else View(this), LinearLayout.LayoutParams(0, -2, 1f))
                }
                homeBody.addView(row)
                i += 4
            }
        }
        if (hist.isNotEmpty()) {
            homeBody.addView(sectionTitle("最近访问", "全部") { openLibrary(1) }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = roundRect(Ui.WHITE, dp(20).toFloat())
                clipToOutline = true
                elevation = dp(1).toFloat()
            }
            addRows(card, hist.map { e ->
                val host = Uri.parse(e.url).host ?: e.url
                suggestRow(IconView.Kind.HISTORY, e.title.ifBlank { host }, host) { load(e.url) }
            })
            homeBody.addView(card, LinearLayout.LayoutParams(-1, -2))
        }
        if (marks.isEmpty() && hist.isEmpty()) {
            homeBody.addView(TextView(this).apply {
                text = "输入网址或关键词开始浏览"
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(Ui.TEXT_SUB)
                setPadding(0, dp(60), 0, 0)
            })
        }
    }

    private fun sectionTitle(title: String, action: String?, onAction: () -> Unit = {}): View {
        val t = TextView(this).apply {
            text = title
            textSize = 13f
            setTextColor(Ui.TEXT_SUB)
            typeface = Ui.MEDIUM
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(8), 0, dp(8))
            addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        }
        if (action != null) {
            row.addView(TextView(this).apply {
                text = action
                textSize = 13f
                typeface = Ui.MEDIUM
                setTextColor(Ui.PRIMARY)
                setPadding(dp(8), dp(4), dp(2), dp(4))
                setOnClickListener { onAction() }
            })
        }
        return row
    }

    /** 常用网站：斜向渐变的圆角方块徽标 + 站名，长按弹出操作面板。 */
    private fun shortcut(e: Store.Entry): View {
        val host = Uri.parse(e.url).host ?: e.url
        val letter = TextView(this).apply {
            text = (e.title.firstOrNull { it.isLetterOrDigit() } ?: host.firstOrNull() ?: '#').uppercaseChar().toString()
            textSize = 20f
            typeface = Ui.MEDIUM
            gravity = Gravity.CENTER
            setTextColor(Ui.WHITE)
            background = badge(host.removePrefix("www."), 18)
            elevation = dp(2).toFloat()
        }
        val label = TextView(this).apply {
            text = e.title.ifBlank { host }
            textSize = 12f
            setTextColor(Ui.TEXT)
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(8), dp(4), dp(8))
            background = rippleOf(null, dp(16).toFloat())
            addView(letter, LinearLayout.LayoutParams(dp(54), dp(54)))
            addView(label, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
            pressFeedback(0.94f)
            setOnClickListener { load(e.url) }
            setOnLongClickListener {
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                actions.showActions(e.title.ifBlank { host }, e.url, listOf(
                    SheetLayer.Action(IconView.Kind.LINK, "复制链接") { copy(e.url); toast("已复制链接") },
                    SheetLayer.Action(IconView.Kind.TRASH, "从常用网站移除", danger = true) {
                        Store.removeBookmark(e.url)
                        buildHome()
                    }
                ))
                true
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun openLibrary(tab: Int) {
        startActivityForResult(Intent(this, LibraryActivity::class.java).putExtra(LibraryActivity.EXTRA_TAB, tab), REQ_LIB)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_FILE -> {
                fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
                fileCb = null
            }
            REQ_LIB -> if (resultCode == RESULT_OK) data?.getStringExtra(LibraryActivity.EXTRA_URL)?.let { load(it) }
        }
    }

    // ---------- 底部工具栏 / 菜单 ----------

    private class Tile(
        val kind: IconView.Kind,
        val label: String,
        val enabled: Boolean = true,
        val active: Boolean = false,
        val onClick: () -> Unit
    )

    private fun buildBottomBar() {
        backBtn = iconButton(IconView.Kind.BACK, 48) { goBack() }
        fwdBtn = iconButton(IconView.Kind.FORWARD, 48) { goForward() }
        // 已经在起始页时再点主页 = 直接开始输入
        homeBtn = iconButton(IconView.Kind.HOME, 48) { if (onHome && !editing) urlBar.requestFocus() else showHome() }
        dlBtn = iconButton(IconView.Kind.DOWNLOAD, 48) { startActivity(Intent(this, DownloadsActivity::class.java)) }
        val menuBtn = iconButton(IconView.Kind.MENU, 48) { showMenu() }
        dlBadge = TextView(this).apply {
            textSize = 10f
            setTextColor(Ui.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            minWidth = dp(16)
            setPadding(dp(4), 0, dp(4), 0)
            background = roundRect(Ui.RED, dp(8).toFloat())
            visibility = View.GONE
        }
        dlBtn.addView(dlBadge, FrameLayout.LayoutParams(-2, dp(16), Gravity.CENTER).apply {})
        dlBadge.translationX = dp(11).toFloat()
        dlBadge.translationY = -dp(10).toFloat()

        // 五个按钮各占一格，按钮本身是 48dp 的圆形点按区域，涟漪是圆的
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            for (b in listOf(backBtn, fwdBtn, homeBtn, dlBtn, menuBtn)) {
                val cell = FrameLayout(this@MainActivity)
                cell.addView(b, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER))
                addView(cell, LinearLayout.LayoutParams(0, -1, 1f))
            }
        }
        bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.CHROME)
            addView(View(this@MainActivity).apply { setBackgroundColor(0xFFE9EBF2.toInt()) }, LinearLayout.LayoutParams(-1, 1))
            addView(row, LinearLayout.LayoutParams(-1, dp(52)))
        }
    }

    private fun buildSheets() {
        menu = SheetLayer(this) { updateBall() }
        actions = SheetLayer(this) { updateBall() }
        sniff = SheetLayer(this) { updateBall() }
    }

    private fun showMenu() {
        if (customView != null || editing) return
        val url = web.url
        val hasPage = !onHome && !url.isNullOrEmpty()
        val marked = hasPage && Store.isBookmarked(url)
        val p = menu.panel
        p.removeAllViews()
        p.setPadding(dp(16), 0, dp(16), dp(20))
        p.addView(menu.grabber(), LinearLayout.LayoutParams(-1, dp(24)))
        if (hasPage) p.addView(menuHeader(web.title ?: "", display(url)))
        val tiles = listOf(
            Tile(if (marked) IconView.Kind.STAR_FILL else IconView.Kind.STAR, if (marked) "取消收藏" else "收藏", hasPage) {
                val added = Store.toggleBookmark(web.title ?: "", url ?: "")
                toast(if (added) "已收藏" else "已取消收藏")
            },
            Tile(IconView.Kind.BOOKMARK, "书签") { openLibrary(0) },
            Tile(IconView.Kind.HISTORY, "历史") { openLibrary(1) },
            Tile(IconView.Kind.DESKTOP, "电脑版", active = desktop) { toggleDesktop() },
            Tile(IconView.Kind.SHARE, "分享", hasPage) { share(url ?: "", web.title ?: "") },
            Tile(IconView.Kind.LINK, "复制链接", hasPage) { copy(url ?: ""); toast("已复制链接") },
            Tile(IconView.Kind.SEARCH, "页内查找", hasPage) { openFind() },
            Tile(IconView.Kind.TRASH, "清除数据") { confirmClearData() }
        )
        var i = 0
        while (i < tiles.size) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (k in 0 until 4) row.addView(menuTile(tiles[i + k]), LinearLayout.LayoutParams(0, -2, 1f))
            p.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = if (i == 0) dp(4) else dp(6) })
            i += 4
        }
        menu.show()
    }

    /** 菜单顶部：当前网页的标题和域名。 */
    private fun menuHeader(title: String, host: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(8), dp(2), dp(8), dp(12))
        addView(TextView(this@MainActivity).apply {
            text = title.ifBlank { host }
            textSize = 16f
            typeface = Ui.MEDIUM
            setTextColor(Ui.TEXT)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        addView(TextView(this@MainActivity).apply {
            text = host
            textSize = 12f
            setTextColor(Ui.TEXT_SUB)
            maxLines = 1
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
    }

    private fun menuTile(t: Tile): View {
        val circle = FrameLayout(this).apply {
            background = roundRect(if (t.active) Ui.PRIMARY_LIGHT else Ui.SURFACE, dp(24).toFloat())
            addView(
                IconView(this@MainActivity, t.kind, if (t.active) Ui.PRIMARY else Ui.ICON),
                FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER)
            )
        }
        val label = TextView(this).apply {
            text = t.label
            textSize = 12f
            setTextColor(if (t.active) Ui.PRIMARY else Ui.TEXT)
            gravity = Gravity.CENTER
            maxLines = 1
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(8), 0, dp(8))
            alpha = if (t.enabled) 1f else 0.35f
            background = rippleOf(null, dp(14).toFloat())
            addView(circle, LinearLayout.LayoutParams(dp(48), dp(48)))
            addView(label, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
            if (t.enabled) pressFeedback(0.94f)
            setOnClickListener {
                if (t.enabled) {
                    menu.hide()
                    t.onClick()
                }
            }
        }
    }

    private fun toggleDesktop() {
        desktop = !desktop
        web.settings.userAgentString = if (desktop) desktopUa else mobileUa
        web.settings.loadWithOverviewMode = desktop
        ua = web.settings.userAgentString
        toast(if (desktop) "已切换为电脑版网站" else "已切换为手机版网站")
        if (!onHome && web.url != null) web.reload()
    }

    private fun confirmClearData() {
        actions.showConfirm("清除浏览数据", "将清除历史记录、缓存、Cookie 和网站数据。书签和下载记录会保留。", "清除", true) {
            Store.clearHistory()
            web.clearCache(true)
            web.clearHistory()
            web.clearFormData()
            CookieManager.getInstance().removeAllCookies(null)
            WebStorage.getInstance().deleteAllData()
            toast("已清除")
            showHome()
        }
    }

    // ---------- 页内查找 ----------

    private fun buildFindBar() {
        findInput = EditText(this).apply {
            background = null
            hint = "在页面中查找"
            textSize = 15f
            setTextColor(Ui.TEXT)
            setHintTextColor(Ui.ICON_DIM)
            isSingleLine = true
            setPadding(0, 0, 0, 0)
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setOnEditorActionListener { _, _, _ -> web.findNext(true); hideKeyboard(); true }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    val q = s?.toString() ?: ""
                    if (q.isEmpty()) { web.clearMatches(); findCount.text = "" } else web.findAllAsync(q)
                }
            })
        }
        findCount = TextView(this).apply {
            textSize = 12f
            setTextColor(Ui.TEXT_SUB)
            setPadding(dp(4), 0, dp(4), 0)
        }
        web.setFindListener { active, total, _ ->
            findCount.text = if (findInput.text.isNullOrEmpty()) "" else if (total == 0) "无结果" else "${active + 1}/$total"
        }
        // 白色胶囊输入框 + 上一个 / 下一个，右边一个「完成」
        val field = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = roundRect(Ui.WHITE, dp(20).toFloat())
            setPadding(dp(16), 0, dp(2), 0)
            addView(findInput, LinearLayout.LayoutParams(0, dp(40), 1f))
            addView(findCount)
            addView(iconButton(IconView.Kind.UP, 36, 18) { web.findNext(false) })
            addView(iconButton(IconView.Kind.DOWN, 36, 18) { web.findNext(true) })
        }
        val done = TextView(this).apply {
            text = "完成"
            textSize = 14f
            typeface = Ui.MEDIUM
            setTextColor(Ui.PRIMARY)
            gravity = Gravity.CENTER
            setPadding(dp(14), 0, dp(14), 0)
            setOnClickListener { closeFind() }
        }
        findBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Ui.CHROME)
            visibility = View.GONE
            setPadding(dp(12), dp(6), 0, dp(6))
            addView(field, LinearLayout.LayoutParams(0, dp(40), 1f))
            addView(done, LinearLayout.LayoutParams(-2, dp(40)))
        }
    }

    private fun openFind() {
        findBar.visibility = View.VISIBLE
        findInput.requestFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(findInput, 0)
    }

    private fun closeFind() {
        if (!::findBar.isInitialized || findBar.visibility != View.VISIBLE) return
        web.clearMatches()
        findInput.setText("")
        findBar.visibility = View.GONE
        hideKeyboard()
        content.requestFocus()
    }

    // ---------- 分享 / 复制 / 下载 ----------

    private fun share(url: String, title: String) {
        val i = Intent(Intent.ACTION_SEND).setType("text/plain")
            .putExtra(Intent.EXTRA_TEXT, url)
            .putExtra(Intent.EXTRA_SUBJECT, title)
        startActivity(Intent.createChooser(i, null))
    }

    private fun copy(text: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("url", text))
    }

    private fun showLinkMenu(link: String?, img: String?) {
        val acts = ArrayList<SheetLayer.Action>()
        if (!link.isNullOrEmpty()) {
            acts.add(SheetLayer.Action(IconView.Kind.GLOBE, "打开链接") { load(link) })
            acts.add(SheetLayer.Action(IconView.Kind.LINK, "复制链接") { copy(link); toast("已复制链接") })
            acts.add(SheetLayer.Action(IconView.Kind.SHARE, "分享链接") { share(link, "") })
        }
        if (!img.isNullOrEmpty()) {
            acts.add(SheetLayer.Action(IconView.Kind.DOWNLOAD, "下载图片") { downloadNow(img, URLUtil.guessFileName(img, null, null)) })
            acts.add(SheetLayer.Action(IconView.Kind.LINK, "复制图片地址") { copy(img); toast("已复制") })
        }
        if (acts.isEmpty()) return
        web.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        val shown = if (!link.isNullOrEmpty()) link else img.orEmpty()
        actions.showActions(display(shown), shown, acts)
    }

    private fun askDownload(url: String, name: String) {
        if (!url.startsWith("http", true)) { toast("暂不支持这类链接的下载"); return }
        actions.showConfirm("下载文件", name, "下载", false) { downloadNow(url, name) }
    }

    private fun downloadNow(url: String, name: String) {
        if (!url.startsWith("http", true)) { toast("暂不支持这类链接的下载"); return }
        DownloadCenter.startDirect(url, safeName(name).ifEmpty { "download" }, ua, pageUrl)
        toast("已开始下载，可在「下载」中查看")
        updateDownloadBtn()
    }

    // ---------- 嗅探：数据 ----------

    private fun extOf(u: String) = (Uri.parse(u).path ?: "").substringAfterLast('.', "").uppercase()

    private fun addSniff(raw: String) {
        val u = upgraded[raw] ?: raw // 这个地址之前已经找到过更高画质，直接用高的
        if (items.any { it.url == u }) return
        val item = infoCache.getOrPut(u) { SniffItem(u, extOf(u)) }
        items.add(item)
        prober.probe(item)
        refreshSniff(bump = true)
        // 嗅探到的多半只是网页当前播放的那一档：后台去找同一视频的更高画质
        if (u == raw && finderTried.add(raw)) {
            finder.findAsync(raw, item.ext) { better -> runOnUiThread { applyUpgrade(item, better) } }
        }
    }

    /** 找到更高画质：用新地址替换列表里的旧条目（新地址已在列表里就直接去重）。 */
    private fun applyUpgrade(old: SniffItem, better: String) {
        upgraded[old.url] = better
        val idx = items.indexOf(old)
        if (idx < 0) return // 已经换了网页，列表被清空了
        if (items.any { it.url == better }) {
            items.removeAt(idx)
        } else {
            val n = infoCache.getOrPut(better) { SniffItem(better, extOf(better)) }
            items[idx] = n
            prober.probe(n)
        }
        refreshSniff()
    }

    private fun headersFor(u: String): Map<String, String> = DownloadCenter.headersFor(u, ua, pageUrl)

    /** 文件名：优先用 URL 里有意义的文件名，否则用网页标题。 */
    private fun fileBase(item: SniffItem): String {
        val seg = Uri.parse(item.url).lastPathSegment ?: ""
        val base = seg.substringBeforeLast('.', seg)
        val fromTitle = safeName(web.title ?: "")
        val name = if (base.length < 3 || genericNameRe.matches(base)) fromTitle else safeName(Uri.decode(base))
        return name.ifEmpty { fromTitle }.ifEmpty { Uri.parse(item.url).host ?: "video" }
    }

    // ---------- 嗅探：界面（悬浮提示 + 底部面板） ----------

    private fun buildSniffOverlay() {
        ball = FloatingBall(this).apply { onClick = { showSheet() } }

        sheetTitle = TextView(this).apply {
            textSize = 16f
            typeface = Ui.MEDIUM
            setTextColor(Ui.TEXT)
        }
        val closeBtn = TextView(this).apply {
            text = "关闭"
            textSize = 14f
            typeface = Ui.MEDIUM
            setTextColor(Ui.PRIMARY)
            setPadding(dp(12), dp(8), dp(4), dp(8))
            setOnClickListener { hideSheet() }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setGravity(Gravity.CENTER_VERTICAL)
            setPadding(dp(20), 0, dp(16), dp(6))
            addView(sheetTitle, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(closeBtn)
        }

        sniffAdapter = SniffAdapter()
        val list = ListView(this).apply {
            divider = ColorDrawable(Ui.DIVIDER)
            dividerHeight = dp(1)
            overScrollMode = View.OVER_SCROLL_NEVER
            setAdapter(sniffAdapter)
            setOnItemClickListener { _, _, i, _ -> if (i < items.size) dlSheet.show(items[i]) }
        }
        val empty = TextView(this).apply {
            text = "暂未发现资源\n播放网页里的视频后，会自动出现在这里"
            gravity = Gravity.CENTER
            textSize = 13f
            setLineSpacing(dp(3).toFloat(), 1f)
            setTextColor(Ui.TEXT_SUB)
        }
        list.emptyView = empty
        val body = FrameLayout(this).apply {
            addView(list, FrameLayout.LayoutParams(-1, -1))
            addView(empty, FrameLayout.LayoutParams(-1, -1))
        }
        sniff.panel.addView(sniff.grabber(), LinearLayout.LayoutParams(-1, dp(24)))
        sniff.panel.addView(header)
        sniff.panel.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun refreshSniff(bump: Boolean = false) {
        if (!::ball.isInitialized) return
        val n = items.size
        ball.count = n
        sheetTitle.text = "发现 $n 个资源"
        updateBall()
        sniffAdapter.notifyDataSetChanged()
        if (bump && ball.visibility == View.VISIBLE) ball.pulse()
    }

    /** 有资源、且没打开任何面板、没在全屏时，才显示悬浮球。 */
    private fun updateBall() {
        if (!::ball.isInitialized || !::menu.isInitialized || !::actions.isInitialized || !::sniff.isInitialized) return
        val show = items.isNotEmpty() && !onHome && !editing &&
            !menu.isShowing && !actions.isShowing && !sniff.isShowing && customView == null
        ball.showBall(show)
    }

    private fun showSheet() {
        if (customView != null) return
        sniff.show(maxOf((root.height * 0.62f).toInt(), dp(260)))
    }

    private fun hideSheet() = sniff.hide()

    private fun updateDownloadBtn() {
        if (!::dlBadge.isInitialized) return
        val n = DownloadCenter.activeCount()
        dlBadge.visibility = if (n > 0) View.VISIBLE else View.GONE
        dlBadge.text = if (n > 99) "99+" else n.toString()
    }

    private inner class SniffAdapter : BaseAdapter() {
        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView?.tag as? Row) ?: Row().also { it.root.tag = it }
            row.bind(items[position])
            return row.root
        }
    }

    /** 面板里的一张资源卡片：预览图 + 名称 + 类型/分辨率/大小 + 播放/下载/更多。 */
    private inner class Row {
        val ctx: Context = this@MainActivity
        var item: SniffItem? = null
        val thumb = ImageView(ctx).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        val ph = TextView(ctx).apply {
            gravity = Gravity.CENTER
            textSize = 15f
            setTextColor(Ui.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val dur = TextView(ctx).apply {
            textSize = 11f
            setTextColor(Ui.WHITE)
            setPadding(dp(4), dp(1), dp(4), dp(1))
            background = roundRect(0xAA000000.toInt(), dp(4).toFloat())
        }
        val title = TextView(ctx).apply {
            textSize = 14f
            setTextColor(Ui.TEXT)
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        val meta = TextView(ctx).apply {
            textSize = 12f
            setTextColor(Ui.TEXT_SUB)
        }
        val host = TextView(ctx).apply {
            textSize = 11f
            setTextColor(0xFFA0A5B3.toInt())
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val playBtn = ctx.pill("播放", Ui.PRIMARY, Ui.PRIMARY_LIGHT) { item?.let { play(it.url) } }
        val dlBtn = ctx.pill("下载", Ui.WHITE, Ui.PRIMARY) { item?.let { dlSheet.show(it) } }
        val root = LinearLayout(ctx)

        init {
            val thumbBox = FrameLayout(ctx).apply {
                background = roundRect(0xFF2A2F3A.toInt(), dp(8).toFloat())
                clipToOutline = true
                addView(thumb, FrameLayout.LayoutParams(-1, -1))
                addView(ph, FrameLayout.LayoutParams(-1, -1))
                addView(dur, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply {
                    setMargins(0, 0, dp(4), dp(4))
                })
            }
            val btns = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(playBtn)
                addView(dlBtn, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
            }
            val col = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                addView(title)
                addView(meta, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
                addView(host, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(1) })
                addView(btns, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
            }
            root.orientation = LinearLayout.HORIZONTAL
            root.setPadding(dp(12), dp(12), dp(12), dp(12))
            root.addView(thumbBox, LinearLayout.LayoutParams(dp(112), dp(64)))
            root.addView(col, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(12) })
        }

        fun bind(s: SniffItem) {
            item = s
            title.text = fileBase(s)
            val parts = ArrayList<String>()
            parts.add(s.ext)
            s.resolution?.let { parts.add(it) }
            if (s.live) parts.add("直播")
            if (s.size > 0) parts.add((if (s.sizeEstimated) "约 " else "") + formatSize(s.size))
            else if (s.segments > 0) parts.add("${s.segments} 个分片")
            if (s.encrypted) parts.add("已加密")
            if (s.state != 2) parts.add("读取信息中…")
            meta.text = parts.joinToString(" · ")
            host.text = Uri.parse(s.url).host ?: ""

            val bmp = s.thumb
            thumb.setImageBitmap(bmp)
            ph.visibility = if (bmp == null) View.VISIBLE else View.GONE
            ph.text = s.ext
            if (s.duration > 0 && !s.live) {
                dur.visibility = View.VISIBLE
                dur.text = formatDuration(s.duration)
            } else {
                dur.visibility = View.GONE
            }
        }
    }

    // ---------- 嗅探：操作 ----------

    /** 全屏播放：交给 PlayerActivity，并带上网页的 UA / Referer / Cookie 以通过防盗链。 */
    private fun play(u: String) {
        // 先暂停网页自己的音视频，避免和全屏播放器同时出声
        web.evaluateJavascript("document.querySelectorAll('video,audio').forEach(function(m){m.pause()})", null)
        startActivity(Intent(this, PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_URL, u)
            putExtra(PlayerActivity.EXTRA_UA, ua)
            pageUrl?.let { putExtra(PlayerActivity.EXTRA_REFERER, it) }
            CookieManager.getInstance().getCookie(u)?.let { putExtra(PlayerActivity.EXTRA_COOKIE, it) }
        })
    }

    // ---------- 网页内置播放器全屏 ----------

    /** 退出网页内置播放器的全屏，恢复界面与屏幕方向。 */
    private fun hideCustomView() {
        val v = customView ?: return
        root.removeView(v)
        customView = null
        customCallback?.onCustomViewHidden()
        customCallback = null
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        setImmersive(false)
        lightBars(Ui.CHROME)
        updateBall()
    }

    /** 应用内的轻提示：墨色圆角胶囊，从下方淡入，1.8 秒后淡出。 */
    private fun toast(s: String) {
        toastView.text = s
        handler.removeCallbacks(hideToast)
        toastView.animate().cancel()
        toastView.visibility = View.VISIBLE
        toastView.alpha = 0f
        toastView.translationY = dp(8).toFloat()
        toastView.animate().alpha(1f).translationY(0f).setDuration(180).start()
        handler.postDelayed(hideToast, 1800)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when {
            customView != null -> hideCustomView() // 先退出全屏，再谈网页后退
            actions.isShowing -> actions.hide()
            dlSheet.isShowing -> dlSheet.hide()
            menu.isShowing -> menu.hide()
            sniff.isShowing -> sniff.hide()
            editing -> stopEditing()
            findBar.visibility == View.VISIBLE -> closeFind()
            onHome -> super.onBackPressed()
            web.canGoBack() -> web.goBack()
            else -> showHome()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // 全屏中系统栏被临时唤出后失去焦点再回来时，重新隐藏
        if (hasFocus && customView != null) setImmersive(true)
    }
}
