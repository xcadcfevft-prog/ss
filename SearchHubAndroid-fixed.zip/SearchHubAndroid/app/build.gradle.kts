plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.searchhub"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.searchhub"
        minSdk = 29
        targetSdk = 34
        versionCode = 4
        versionName = "1.3"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // 内置播放器：Media3 ExoPlayer（Google 官方）。只引入核心 + HLS + DASH，播放界面是自己用代码写的，不需要 media3-ui。
    val media3 = "1.5.1"
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-exoplayer-hls:$media3")
    implementation("androidx.media3:media3-exoplayer-dash:$media3")
    implementation("androidx.annotation:annotation-experimental:1.4.1")
}
